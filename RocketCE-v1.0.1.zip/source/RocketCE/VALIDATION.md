# v1.0.1 — jump tuning

The previous build raised the underside of a level, unboosted car 64.89 units on a one-tick tap and 97.23 on a six-tick hold. The ball is 48 units in diameter. New peaks are 21.40 and 49.41 units respectively; airtime changes from 1.40/1.73 seconds to 0.80/1.23 seconds.

Initial and neutral second-jump impulses are now 3.25 units/tick rather than 6. The six-tick hold bonus is 112 Q8 velocity units/tick rather than 80, preserving a useful gap between tap and hold. Gravity, directional dodge impulse, boost, collision bounds, renderer and USB startup are unchanged. No packet fields or simulation state were added.

Regression checks assert a low tap height, higher held jump, capped hold, independent second press and a moving tap-jump striking a resting ball. The full sanitizer-backed host suite passed, including movement, momentum, physics, USB/game synchronization, native descriptors and the native target-helper regression. Native CEdev build succeeded at 39,907 compressed program bytes. Physical calculator feel and FPS are not measured here.

Reference: RLBot's jump physics documentation describes an initial impulse, the same impulse for a neutral second jump, and up to 0.2 seconds of extra lift while held: https://wiki.rlbot.org/v5/botmaking/jumping-physics/ . Values here are tuned to RocketCE's smaller car/ball geometry and existing gravity.

## Earlier validation

# v1.0.0 release validation

Promotes the working v0.3.13 build to the first public release. The only code change is the version label shown for mismatched peers; protocol key remains RocketCE-20. The user confirmed successful startup after the grace-period fix and previously confirmed independent controls and synchronized motion on two physical calculators.

Prior native and simulated regression results follow. They describe their original test versions.

# Validation — v0.3.13

Native release build (39,874 compressed program bytes) and simulated link tests pass. Added a delayed-enable regression: a guest can take four seconds to become enabled without another host reset. A stalled guest retries after five seconds; explicit reset failure retains the one-second error retry. Tests exercise the actual linklib scheduler with mocked USB APIs, not real electrical USB timing.

User hardware result for v0.3.12: a restart allowed both calculators into gameplay, with independent controls and visible remote motion. This establishes that linking and gameplay can work; initial startup remains intermittent. v0.3.13 hardware startup reliability is not yet verified.

The official usbdrvce assembly separates usb_ResetDevice from the asynchronous port-enable, descriptor and address sequence. The release extends its scheduler grace period instead of repeatedly resetting every second. Rendering, physics, network packets and player assignment are unchanged.

## Prior validation

# Validation — v0.3.12

Native CEdev release build succeeds: 39,773 compressed program bytes. dist program matches bin output. Protocol/key remains 20. Native USB descriptor byte checks pass.

## Generated-code regression

The previous `_target` helper's emitted assembly computed the pointer test, then executed `or a,a; sbc hl,hl` to prepare a default NULL result before `call nz,_usb_RefDevice`. Those instructions set Z for the zero result, preventing the reference call, after which HL=0 was stored as the target. This matches the user's host INIT/attempt #0 photograph but is not a USB hardware trace.

The rewritten helper makes the reference calls unconditional, then stores the original argument. usbdrvce's reference routines accept NULL (confirmed against implementation and the packaged runtime's reference entry). Tests' API mocks now match NULL handling and unref's NULL return.

`tests/test_native_target.py` interprets the limited instruction/flag operations used by this emitted helper. The archived previous helper fixture reproduces the lost pointer; the current generated helper preserves target pointers and balances reference calls across 15 cases. It is not a full eZ80 emulator and does not execute the physical USB driver. It checks native-generated helper behavior that host C tests alone cannot cover.

The full sanitizer-backed host suite passes, including descriptor/API tests, two real linklib/net instances plus gameplay under simulated USB controllers, both cable orientations, timeout/restart/reconnect, goals/results/rematch, packet/role/CRC tests, physics and UI/assets. The native descriptor layout and helper instruction checks both pass after the native build. A real-cable match and hardware FPS remain unverified.

The user supplied photo was examined directly. Official reference sources consulted: https://github.com/CE-Programming/toolchain/blob/master/examples/library_examples/usbdrvce/link_library/src/linklib.c and https://github.com/CE-Programming/toolchain/blob/master/src/usbdrvce/usbdrvce.asm . No external messages were sent.

## Prior reports

# Validation — v0.3.11

Native CEdev release build succeeds: 39,793 compressed program bytes. dist/ROCKETCE.8xp matches bin/ROCKETCE.8xp. Wire protocol/key remains 20 and the 223-byte frame/256-byte receive layout is unchanged.

New startup regressions exercise a pre-attached disabled peer without a CONNECTED callback, CONNECTED arriving before the host role event, preservation of queued reset work, the host attempt count, and retry scheduling across uint32 clock wrap. Scheduling is tested against an injected 32768-Hz game clock; native code uses clock()/timer 1, already configured by main. The scheduler no longer relies on USB timer-2 cycle-counter reads.

The full sanitizer-backed suite passes: low-level USB state tests, the two-instance linklib/net/game integration test in both cable orientations (including detection timeout, gameplay, goals/results/rematch, unplug/replug and peer restart), packet/movement/physics/UI/render/asset regressions, and exact native descriptor-byte checks. Gameplay, net.c/net.h, controls and renderer source are unchanged from v0.3.10 except that the included link status structure gains an attempt field; this status field is not on the wire.

The user's physical v0.3.10 result is host DETECTING with guest WAITING and zero packet counters. That establishes a pre-data-exchange stall, but no hardware trace identifies its exact cause. This release removes dependencies on particular event ordering and USB-cycle scheduling and makes host attempts visible. Successful physical pairing and hardware FPS remain unverified.

## Prior reports

# Validation — v0.3.10

Native CEdev build succeeds: 39,653 compressed program bytes. Transfer program matches build output. Protocol/key is 20. Native ELF bytes verify the packed 32-byte configuration tree with OUT 0x01, IN 0x82, 64-byte endpoint packet sizes, required attributes bit, and the four-byte language descriptor.

The full sanitizer-backed suite passes. Low-level link tests verify host reads on 0x82/writes on 0x01 and guest reads on 0x01/writes on 0x82. The two-controller integration test requires distinct device FIFO numbers for concurrently active directions and transmits 223-byte frames into 256-byte receive requests. Both cable orientations, delayed launch, ID timeout, session acknowledgement, gameplay, equal snapshots, goals/results/rematch, unplug/replug and peer restart pass. Existing packet CRC, short jump taps, role conflict and 900 gameplay-tick tests pass.

UI/asset/physics/controls/render checks pass. Waiting-screen diagnostics now distinguish queued TX, completed OUT, raw IN, accepted RX and last receive BYTES. game.c/game.h, controls.c/controls.h and render.c are unchanged from v0.3.9. Images/runtime libraries are unchanged.

The user's real v0.3.9 test confirmed peer detection but RX stayed zero and the match did not start. Source inspection of usbdrvce shows device FIFO mapping selected by endpoint number, motivating the separate-number change. This is a software-level correction and improved diagnosis; no successful physical match or hardware FPS has been observed in this environment. Mocks do not model all controller behavior or electrical timing.

## Prior reports

# Validation — v0.3.9

Native CEdev build succeeds: 39,468 compressed program bytes. dist/ROCKETCE.8xp matches bin/ROCKETCE.8xp. Protocol/key is 19; both calculators must update. Packet size is still 223 bytes, with space asserted for the current Game, session ID, echoed session ID and CRC.

## Native USB layout regression

Native compile-time checks exposed 10-byte usb_configuration_descriptor_t and 8-byte usb_endpoint_descriptor_t layouts under this ABI. Those padded structs must not be serialized as USB descriptors. New explicitly packed wire structs assert to 9 and 7 bytes, and the entire configuration asserts to 32. The mandatory bit 7 is set in configuration attributes. tests/test_native_usb.py reads the actual CE ELF object's data sections, verifies all 32 configuration bytes, checks the 4-byte language descriptor, and verifies the device descriptor. This catches a native-layout failure that the previous high-level mocks did not expose.

## Connection and assignment

The real linklib is tested with mocked USB calls: deferred event work, host/guest roles, standard guest configuration, both endpoint directions, exact descriptor tree, version mismatch, one-second retry delay, reset/ID/config timeouts, unplug during identification, transfer cancellation, reference ownership, init failures, recoverable poll errors and fatal system-error cleanup. Device work retains references while blocking calls can dispatch disconnect events.

An additional integration test compiles two actual linklib instances and two actual net instances with game.c, joined by simulated USB controllers. Both host orientations pass delayed second launch, injected ID timeout, standard configuration, bidirectional current-session acknowledgement, roughly 600 authoritative gameplay ticks, identical final snapshots, goal/celebration state, results, rematch reset, cable unplug/replug and a peer restart. These tests model controller behavior; they do not run the hardware USB driver assembly or prove real electrical/transfer timing.

Network regressions additionally reject same-role packets, prevent readiness after only the first unacknowledged exchange, recover after correct roles resume, preserve a jump tap's direction/boost, restart sequence numbers safely, and synchronize 900 gameplay ticks. Existing CRC, stale-input, snapshot, rematch, disconnect and in-flight-buffer checks pass.

## Gameplay and UI

The full sanitizer-backed physics/controls/render/UI/assets suite passes. Physics, arena, renderer and control timeline source are byte-identical to v0.3.8. The link screen shows cable role, counters, error number/operation and explicit conflict text. Startup failures remain on this screen with ENTER retry instead of an uninformative exit-only message. USB events are polled while releasing keys after entry; waiting UI updates at 4 Hz.

Successful physical two-calculator play and hardware FPS remain unverified. The user's previous physical attempts failed; this release fixes a demonstrated native descriptor issue and strengthens recovery/handshake coverage, but still requires a real-cable test.

## Prior validation reports

# Validation — v0.3.8

Native CEdev release build succeeds: 39,098 compressed program bytes. dist/ROCKETCE.8xp matches bin/ROCKETCE.8xp. Protocol/key is 18 and packet length remains 223 bytes. The Game payload size assertion includes the session footer. Both calculators must update.

The sanitizer-backed suite passes. New low-level coverage compiles the actual src/linklib.c with the shipped USB API header and mocked USB calls (UTF-16 wchar width): four-byte language descriptor, key length, host enumeration/key exchange, guest vendor setup, host/guest role selection without relying on a SET_ADDRESS callback, read/write endpoint directions in both roles, mismatch rejection, disconnect, pending-transfer cancellation, init cleanup and fatal USB errors.

Network tests additionally cover a completed jump tap between packets (including its direction and boost), guest session restart with reset sequence numbers, and 900 authoritative gameplay ticks while transmitting player inputs and snapshots. The final guest state matches the host byte-for-byte. Prior CRC, timeouts, rematches, score/goal celebration, disconnect and buffer-ownership checks pass. Physical enumeration, cable timing and successful hardware play are still unverified.

All physics, steering, momentum, aerial/flip, bot/goal and explosion checks pass. game.c, game.h, controls.c, controls.h and render.c are unchanged from v0.3.7. No physics/render-speed claim is made. The new waiting UI has sanitizer previews and a visual inspection at 320 × 240; it updates at 4 Hz rather than the match render rate.

## Prior reports

# Validation — v0.3.7

Native CEdev build succeeds: 37,983 compressed program bytes. The transfer program matches the build. Sanitizer-backed UI preview checks pass, and the single controls page was visually inspected at 320 × 240. Four sequential help screens are replaced by one static page, closed with ENTER or CLEAR.

Gameplay, renderer, controls sampling, USB implementation and image AppVars are byte-identical to v0.3.6; its prior gameplay/transport validation is retained below. Physical link and hardware FPS remain unverified.

## Prior validation — v0.3.6

Native CEdev release build succeeds: 37,780 compressed program bytes. The transfer program matches build output. Both image AppVars are byte-identical to v0.3.5.

The full sanitizer-backed host suite passes: randomized physics/match simulation, exact square roots, momentum and steering, jumps/eight directional dodges, aerial controls and recovery, capped walls, goal explosions, timestamped inputs, renderer/UI bounds, ticker behavior, asset integrity and mock USB.

New goal regression checks cover both ends, exact whole-ball crossing with zero forward speed, pushing a resting ball over the line, car entry through the opening, goal-pocket car side/roof bounds, approaching a post before the sphere's cross-section reaches it, glancing shots that deflect into either goal from either post, and side/roof pocket contacts that preserve forward ball velocity. Existing shots outside the opening and above the crossbar still bounce. The former invisible car wall and extra integer-unit scoring threshold are removed.

Bot tests start either team stationary and facing outward in all four corners. Every case reverses and leaves the corner area within the test window. A clear centerline goal approach must keep pursuing rather than triggering wall recovery. Eight bot matches were also simulated: seven reached a winner and one remained in overtime at the cutoff. Scores and wins here are not a claim of competitive balance; the bot remains basic.

The ball radius is 24 versus 23. Goal half-width is still 120 and height 90, and rendering derives the ball silhouette from the same radius used for contacts. Field half-extents remain 544 × 816, height 240. Jump/boost tuning and the 30 Hz simulation frequency are unchanged. Post/header calculations run near end walls, not across the field.

Two uint8_t recovery counters are added per car. The packet size remains 223 bytes and its layout assertion passes. Mock USB tests replicate the bot counters, celebration state, launches, inputs and rematches, with CRC/timeout/disconnect coverage. Protocol/link identity is 17; both calculators must update. Physical cable play is still unverified.

Hardware FPS and real-device behavior remain unverified. Host previews illustrate appearance and mechanics, not calculator timings.
