#ifndef GAME_H
#define GAME_H
#include <stdint.h>
#define Q 256
#define HZ 30
#define BALL_RADIUS 24
#define FIELD_X 544
#define FIELD_Z 816
#define FIELD_HEIGHT 240
#define GOAL_WIDTH 120
#define GOAL_HEIGHT 90
#define GOAL_DEPTH 60
#define KICKOFF_Z 544
#define MAX_BALL_SPEED 48
#define CAR_WALL_REBOUND (2*Q)
#define GOAL_CELEBRATION 75
#define BLAST_DURATION 45
#define BLAST_RADIUS 360
#define CAR_HALF_WIDTH 16
#define CAR_HALF_LENGTH 25
#define CAR_HEIGHT 26
#define UP 1
#define DOWN 2
#define LEFT 4
#define RIGHT 8
#define JUMP 16
#define BOOST 32
#define BRAKE 64
#define SLIDE 128
#define JUMP_IMPULSE (13*Q/4)
#define JUMP_HOLD_BONUS 112
#define JUMP_HOLD_EXTRA 128
#define DODGE_WINDOW 45
#define DODGE_DURATION 12
#define PH_KICKOFF 0
#define PH_PLAY 1
#define PH_GOAL 2
#define PH_END 3
typedef struct { int32_t x,y,z,vx,vy,vz; } Body;
typedef struct { Body b; uint8_t angle,boost,previous,jumps,yawFraction; int16_t yawVelocity;
 uint8_t pitch,roll,jumpHeld,jumpAge,dodgeTicks,resetLock,flipUnlimited,restTicks;
 int8_t pitchVelocity,rollVelocity,flipPitch,flipRoll;
 uint8_t botIdle,botEscape;
} Car;
typedef struct {int16_t rx,ry,rz,ux,uy,uz,fx,fy,fz;} CarBasis;
void car_basis(const Car *c,CarBasis *m);
typedef struct { Car car[2]; Body ball; uint32_t tick; uint16_t remaining,phaseTicks; uint8_t score[2],phase,overtime,freeplay,lastGoal; uint16_t pads[6]; uint8_t blastMask; } Game;
extern const int16_t sine[256];
#define sn(a) sine[(uint8_t)(a)]
#define cs(a) sine[(uint8_t)((a)+64)]
int32_t root32(uint32_t n);
uint8_t heading(int dx,int dz);
void game_init(Game *g,int freeplay);
void game_step(Game *g,uint8_t a,uint8_t b);
uint8_t bot_input(Game *g,int who,int difficulty);
#endif
