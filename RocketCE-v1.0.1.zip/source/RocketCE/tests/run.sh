#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
CC=${CC:-cc}
TMPDIR_ROCKET=$(mktemp -d)
trap 'rm -rf "$TMPDIR_ROCKET"' EXIT
FLAGS='-std=c11 -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined -g -Isrc'
export ASAN_OPTIONS=detect_leaks=0
$CC $FLAGS tests/test_math.c src/game.c -o "$TMPDIR_ROCKET/math"
"$TMPDIR_ROCKET/math"
$CC $FLAGS tests/test_game.c src/game.c -o "$TMPDIR_ROCKET/game"
"$TMPDIR_ROCKET/game"
$CC $FLAGS tests/test_moves.c src/game.c -o "$TMPDIR_ROCKET/moves"
"$TMPDIR_ROCKET/moves"
$CC $FLAGS tests/test_jump_height.c src/game.c -o "$TMPDIR_ROCKET/jump-height"
"$TMPDIR_ROCKET/jump-height"
$CC $FLAGS tests/test_controls.c src/controls.c -o "$TMPDIR_ROCKET/controls"
"$TMPDIR_ROCKET/controls"
$CC $FLAGS tests/test_momentum.c src/game.c -o "$TMPDIR_ROCKET/momentum"
"$TMPDIR_ROCKET/momentum"
$CC $FLAGS tests/test_box.c src/game.c -o "$TMPDIR_ROCKET/box"
"$TMPDIR_ROCKET/box"
$CC $FLAGS tests/test_explosion.c src/game.c -o "$TMPDIR_ROCKET/explosion"
"$TMPDIR_ROCKET/explosion"
$CC $FLAGS tests/test_goal_bot.c src/game.c -o "$TMPDIR_ROCKET/goal-bot"
"$TMPDIR_ROCKET/goal-bot"
sh tests/run_link.sh
$CC $FLAGS -DROCKET_RENDER_TEST -Itests/host tests/preview.c tests/host/graphx.c src/game.c src/render.c -o "$TMPDIR_ROCKET/preview"
"$TMPDIR_ROCKET/preview"
$CC $FLAGS -DROCKET_UI_HOST -Itests/host tests/preview_ui.c tests/host/graphx.c src/game.c src/render.c src/ui.c -o "$TMPDIR_ROCKET/ui"
"$TMPDIR_ROCKET/ui"

python3 tests/test_assets.py
$CC $FLAGS -Itests/host tests/preview_goal.c tests/host/graphx.c src/game.c src/render.c -o "$TMPDIR_ROCKET/goal-preview"
"$TMPDIR_ROCKET/goal-preview"

if [ -f obj/ROCKETCE.o ]; then python3 tests/test_native_usb.py; fi
if [ -f obj/lto.s ]; then python3 tests/test_native_target.py; fi
