#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Game start(void){Game g;game_init(&g,1);g.phase=PH_PLAY;return g;}
static int jump_peak(int hold){Game g=start();int peak=0;for(int i=0;i<100;i++){game_step(&g,i<(hold?6:1)?JUMP:0,0);if(g.car[0].b.y>peak)peak=g.car[0].b.y;}return peak;}
int main(void){
 assert(jump_peak(1)>jump_peak(0));
 Game g=start();game_step(&g,JUMP,0);game_step(&g,0,0);int vy=g.car[0].b.vy;game_step(&g,JUMP,0);assert(g.car[0].b.vy>vy&&g.car[0].jumps==2&&!g.car[0].dodgeTicks);
 const unsigned dirs[8]={UP,DOWN,LEFT,RIGHT,UP|LEFT,UP|RIGHT,DOWN|LEFT,DOWN|RIGHT};
 /* A second press immediately after a tap must finish a full flip
  * before touching down, including diagonals, without boosting. */
 for(int d=0;d<8;d++){
  g=start();game_step(&g,JUMP,0);game_step(&g,0,0);
  int pitchTurn=0,rollTurn=0;
  for(int t=0;t<DODGE_DURATION;t++){
   int p=g.car[0].pitch,r=g.car[0].roll;
   game_step(&g,t==0?(JUMP|dirs[d]):0,0);
   pitchTurn+=(int8_t)(g.car[0].pitch-p);rollTurn+=(int8_t)(g.car[0].roll-r);
   assert(g.car[0].b.y>0);
  }
  assert(!g.car[0].dodgeTicks);
  if(dirs[d]&(UP|DOWN))assert(abs(pitchTurn)>=255&&abs(pitchTurn)<=258);
  if(dirs[d]&(LEFT|RIGHT))assert(abs(rollTurn)==256);
  assert(abs((int8_t)g.car[0].pitch)<=1&&g.car[0].roll==0);
  assert(!g.car[0].pitchVelocity&&!g.car[0].rollVelocity);
 }
 for(int i=0;i<8;i++){g=start();g.car[0].b.y=100*Q;g.car[0].jumps=1;game_step(&g,JUMP|dirs[i],0);Car *c=&g.car[0];assert(c->dodgeTicks&&c->jumps==2);if(dirs[i]&UP)assert(c->b.vz>0);if(dirs[i]&DOWN)assert(c->b.vz<0);if(dirs[i]&LEFT)assert(c->b.vx<0);if(dirs[i]&RIGHT)assert(c->b.vx>0);}
 g=start();g.car[0].b.y=120*Q;g.car[0].jumps=1;g.car[0].jumpAge=DODGE_WINDOW;game_step(&g,JUMP|UP,0);assert(g.car[0].jumps==1&&!g.car[0].dodgeTicks);
 g=start();g.car[0].b.y=100*Q;g.car[0].pitch=64;game_step(&g,BOOST,0);assert(g.car[0].b.vy>0&&g.car[0].boost==100);
 g=start();g.car[0].b.y=100*Q;for(int i=0;i<8;i++)game_step(&g,SLIDE|RIGHT,0);assert(g.car[0].roll>0&&g.car[0].angle==0);
 Game grip=start(),slide=grip;grip.car[0].b.vx=slide.car[0].b.vx=6*Q;game_step(&grip,0,0);game_step(&slide,SLIDE,0);assert(slide.car[0].b.vx>grip.car[0].b.vx);
 g=start();g.car[0].b.y=Q;g.car[0].b.vy=-Q;g.car[0].pitch=4;g.car[0].jumps=1;game_step(&g,JUMP|UP,0);assert(g.car[0].b.y==0&&g.car[0].b.vz>4*Q&&!g.car[0].dodgeTicks);
 g=start();g.car[0].b.y=120*Q;g.car[0].jumps=1;game_step(&g,JUMP|DOWN,0);for(int i=0;i<4;i++)game_step(&g,UP,0);assert(!g.car[0].flipPitch&&g.car[0].dodgeTicks);
 g=start();g.car[0].b.y=80*Q;g.car[0].roll=128;g.car[0].jumps=2;g.car[0].jumpAge=90;g.ball.z=g.car[0].b.z;g.ball.y=117*Q;game_step(&g,0,0);assert(g.car[0].jumps==1&&g.car[0].flipUnlimited&&g.car[0].resetLock);
 g=start();g.car[0].roll=128;game_step(&g,JUMP,0);assert(!g.car[0].roll&&g.car[0].b.vy>0);
 g=start();g.car[0].pitch=128;g.car[0].roll=128;g.car[0].b.y=Q;g.car[0].b.vy=-2*Q;game_step(&g,0,0);assert(g.car[0].angle==128&&!g.car[0].pitch&&!g.car[0].roll);
 Game plain=start();plain.car[0].b.y=120*Q;plain.car[0].jumps=1;game_step(&plain,JUMP|DOWN,0);Game cancelled=plain,boosted=plain;
 for(int n=0;n<10;n++){game_step(&plain,0,0);game_step(&cancelled,UP,0);game_step(&boosted,BOOST,0);}assert(plain.car[0].pitch!=cancelled.car[0].pitch);assert(plain.car[0].b.y!=boosted.car[0].b.y||plain.car[0].b.z!=boosted.car[0].b.z);
 g=start();g.ball.vx=24*Q;g.ball.vy=20*Q;g.ball.vz=24*Q;game_step(&g,0,0);int sx=g.ball.vx/Q,sy=g.ball.vy/Q,sz=g.ball.vz/Q;assert(sx*sx+sy*sy+sz*sz<=(MAX_BALL_SPEED+1)*(MAX_BALL_SPEED+1));
 for(int p=0;p<256;p+=17)for(int r=0;r<256;r+=17){g=start();g.car[0].pitch=p;g.car[0].roll=r;g.car[0].angle=37;CarBasis m;car_basis(&g.car[0],&m);int norm=m.fx*m.fx+m.fy*m.fy+m.fz*m.fz;assert(abs(norm-Q*Q)<1800);}
 for(int i=0;i<8;i++){g=start();game_step(&g,JUMP,0);game_step(&g,0,0);game_step(&g,JUMP|dirs[i],0);for(int n=0;n<240;n++)game_step(&g,0,0);assert(!g.car[0].pitch&&!g.car[0].roll&&!g.car[0].jumps);}
 g=start();g.freeplay=0;g.car[1].roll=128;int recovered=0;for(int n=0;n<300;n++){game_step(&g,0,bot_input(&g,1,1));if(!g.car[1].pitch&&!g.car[1].roll&&g.car[1].b.y==0)recovered=1;}assert(recovered);
 puts("Movement: hold jump, double jump, 8 dodges, expiry, aerial boost/roll, powerslide, wavedash, cancel, wheel reset and recovery passed.");
}
