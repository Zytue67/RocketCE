#include "game.h"
#include <assert.h>
#include <stdio.h>
static int peak(int hold,int twice){
 Game g;game_init(&g,1);g.phase=PH_PLAY;int height=0;
 for(int i=0;i<120;i++){
  unsigned input=i<hold?JUMP:0;if(twice&&i==8)input=JUMP;
  game_step(&g,input,0);if(g.car[0].b.y>height)height=g.car[0].b.y;
 }
 return height;
}
int main(void){
 int tap=peak(1,0),held=peak(6,0);
 /* A tap keeps the underside below the resting ball's centre; holding
  * intentionally allows clearance, rather than making every jump low. */
 assert(tap>=16*Q&&tap<=BALL_RADIUS*Q);
 assert(held>=46*Q&&held<=54*Q&&held>2*tap);
 assert(peak(30,0)==held); /* Holding cannot trigger a second jump. */
 assert(peak(1,1)>held);
 Game g;game_init(&g,1);g.phase=PH_PLAY;
 g.car[0].b.vz=6*Q;g.ball.z=g.car[0].b.z+80*Q;
 int contacted=0;
 for(int i=0;i<20;i++){game_step(&g,i==0?JUMP:0,0);if(g.ball.vz>Q)contacted=1;}
 assert(contacted); /* A rolling tap-jump can actually strike a ground ball. */
 printf("Jump tuning: tap %.2f, held %.2f units; hold cap, double jump and ground-ball contact passed.\n",tap/(double)Q,held/(double)Q);
}
