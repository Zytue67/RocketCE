# Movement guide — v0.3.12

## Ground

Use arrows to accelerate, reverse and steer. GRAPH brakes. Hold MODE while steering for powerslide: lateral tire grip and coasting drag are reduced, so the car carries its momentum while its nose turns. Release MODE to regain grip. ALPHA boosts.

Velocity persists when throttle is released, with light rolling resistance and drag. Steering follows residual speed: coasting turns still work, and reverse motion reverses steering. Steering fades smoothly near a stop; a stationary car cannot spin its tires to rotate. Opposite throttle brakes before reversing. Engine force tapers at cruising speed without cutting off extra boost/dodge momentum. Tire grip redirects lateral velocity over time; MODE reduces this grip.

Jumping carries horizontal velocity into the air; rotating the car alone does not rotate its airborne trajectory. Dodge impulse and nose-directed boost add to velocity. Landing retains horizontal velocity before tire grip acts. Ball rebound strength follows relative normal impact speed rather than a fixed contact bonus. Arena collisions still bounce/dampen momentum in the simplified collision model.

## Jumping and dodging

Press 2nd to jump. Holding it for about 0.2 seconds adds height. Release it before pressing again. A second neutral press double-jumps along the car's up axis. Add arrows to that second press for front/back/left/right or any diagonal dodge. The original project had only a fixed forward shove; this release gives directional momentum and angular momentum you can cancel or redirect. A first-jump second-action window of 45 simulation ticks (about 1.5 seconds) prevents late unlimited jumps. A released-and-repressed key is required, so holding Jump never automatically consumes both actions.

Short presses are retained while the frame draws, with arrow direction captured at the second jump press. Input timing is applied at fixed-step timestamps.

## Flying and spinning

In the air, Up pitches the nose down and Down pitches up. Left/Right yaws. Hold MODE with Left/Right to air-roll instead of yawing; pitch remains available. ALPHA thrust follows the nose in all three dimensions. Hold Jump with Boost for takeoff, then pitch up to climb. The camera stays level while the vehicle rotates. Boost, gravity, orientation and contact are all part of simulation state and replicate through link mode.

## Recovery and combinations

- Opposite pitch during a front/back dodge cancels its pitch rotation; roll can still be controlled. This supplies the ingredients for half-flip-style recoveries.
- A dodge close to the ground can end on the wheels while keeping its directional impulse (arcade wavedash).
- A landing that is sufficiently wheels-down aligns the car to the ground while retaining the horizontal direction of its actual forward axis.
- Completed flips automatically recover when resting tilted after a landing; MODE keeps manual roll control available. Press 2nd to self-right immediately.
- Three wheel contact patches against the ball restore a second action. A small contact tolerance adapts the wheel footprint to the simplified car/ball proportions; a debounce prevents repeated resets every tick. FLIP RESET appears briefly. Wheel-side ball rebounds are softer than body-side rebounds.



## Compact box

Flat walls rebound velocity and do not attach the wheels. Cars can enter the rectangular goal pockets. The ball passes through goal openings to score. Ceiling impacts rebound downward without resetting jumps. Ball impulse follows relative impact velocity; alignment and closing speed determine the transfer, with a 48-unit-per-tick safety speed limit. This is a simplified contact model.


## Wall rebounds — v0.3.12

Horizontal car rebounds are capped at 2 units per tick, with gentle hits retaining a softer half-speed response. Only the velocity into the wall reflects; momentum along it remains. Ball contacts keep their existing velocity-based response. The field is slightly larger, with no change to jump or boost tuning.


## Goal explosion — v0.3.12

Goals trigger a distance-based launch within 360 world units. Nearby cars move away and upward and tumble while gravity and collision bounds continue. Celebration lasts 2.5 seconds with the match clock paused; blast graphics last 1.5 seconds. Controls are paused during this interval. The winning goal also celebrates before the result screen. Kickoff resets blast flags and car state.


## Goal entry and bot recovery — v0.3.12

Ball size is slightly larger, radius 24. Posts and the header use contact normals rather than an invisible reduced-opening plane. Goal-pocket side and roof contacts preserve the ball's forward component. Cars can drive into the pocket. A trapped bot reverses and turns toward the interior before pursuing the ball again.

Linked input in v0.3.12: guest jump press counters preserve a complete tap between packets along with arrows/boost from that press. Host simulation remains authoritative.
