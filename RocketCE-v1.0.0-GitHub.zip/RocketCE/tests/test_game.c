#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static void live(Game *g){game_init(g,0);g->phase=PH_PLAY;}
static void valid(Game *g){for(int i=0;i<2;i++){assert(abs(g->car[i].b.x/Q)<FIELD_X+40);assert(abs(g->car[i].b.z/Q)<FIELD_Z+GOAL_DEPTH+40);assert(g->car[i].b.y>=0);assert(g->car[i].boost<=100);}assert(g->ball.y>=BALL_RADIUS*Q);assert(abs(g->ball.x/Q)<FIELD_X+40);assert(abs(g->ball.z/Q)<FIELD_Z+GOAL_DEPTH+40);}
int main(void){
 assert(heading(0,0)==0);assert(heading(0,10)==0);assert(heading(10,0)==64);assert(heading(0,-10)==128);assert(heading(-10,0)==192);
 for(int dx=-1000;dx<=1000;dx+=53)for(int dz=-1000;dz<=1000;dz+=53){int32_t dot=-1000000;for(int a=0;a<256;a++){int32_t v=dx*sn(a)+dz*cs(a);if(v>dot){dot=v;}}int a=heading(dx,dz);int32_t actual=dx*sn(a)+dz*cs(a);assert(actual*100>=dot*98);}
Game steering;live(&steering);for(int i=0;i<30;i++)game_step(&steering,UP,0);
 unsigned startAngle=steering.car[0].angle;for(int i=0;i<30;i++)game_step(&steering,UP|RIGHT,0);
 unsigned turned=(uint8_t)(steering.car[0].angle-startAngle);assert(turned>0&&turned<=60);
 /* Gradual steering, lower rate, and a settled release. */
 Game smooth;live(&smooth);for(int i=0;i<30;i++)game_step(&smooth,UP,0);
 game_step(&smooth,UP|RIGHT,0);assert(smooth.car[0].yawVelocity==48);
 for(int i=0;i<29;i++)game_step(&smooth,UP|RIGHT,0);
 assert(smooth.car[0].angle<=27);assert(smooth.car[0].yawVelocity<=224);
 for(int i=0;i<8;i++)game_step(&smooth,UP,0);assert(smooth.car[0].yawVelocity==0);
 Game g;game_init(&g,0);for(int i=0;i<90;i++)game_step(&g,UP,UP);assert(g.phase==PH_PLAY&&g.remaining==180*HZ);assert(g.car[0].b.z==-KICKOFF_Z*Q);
 game_step(&g,JUMP,0);assert(g.car[0].b.y>0);assert(g.car[0].jumps==1);game_step(&g,0,0);game_step(&g,JUMP,0);assert(g.car[0].jumps==2);game_step(&g,0,0);int32_t vy=g.car[0].b.vy;game_step(&g,JUMP,0);assert(g.car[0].b.vy<vy);for(int i=0;i<200;i++)game_step(&g,0,0);assert(g.car[0].b.y==0&&g.car[0].jumps==0);
 live(&g);g.ball.z=(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=4*Q;game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.score[0]==1);for(int i=0;i<75;i++)game_step(&g,0,0);assert(g.phase==PH_KICKOFF&&g.score[0]==1&&g.ball.z==0);
 live(&g);g.ball.z=-(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=-4*Q;game_step(&g,0,0);assert(g.score[1]==1&&g.phase==PH_GOAL);
 live(&g);g.ball.x=(GOAL_WIDTH+50)*Q;g.ball.z=(FIELD_Z-BALL_RADIUS+4)*Q;g.ball.vz=5*Q;game_step(&g,0,0);assert(g.ball.vz<0&&g.score[0]==0);
 live(&g);g.ball.y=(GOAL_HEIGHT+30)*Q;g.ball.z=(FIELD_Z-BALL_RADIUS+4)*Q;g.ball.vz=5*Q;game_step(&g,0,0);assert(g.ball.vz<0);
 live(&g);g.remaining=1;game_step(&g,0,0);assert(g.overtime&&g.phase==PH_PLAY);g.ball.z=(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=4*Q;game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.score[0]==1);for(int n=0;n<GOAL_CELEBRATION;n++)game_step(&g,0,0);assert(g.phase==PH_END);
 live(&g);g.score[1]=1;g.remaining=1;game_step(&g,0,0);assert(g.phase==PH_END);uint16_t t=g.remaining;game_step(&g,UP,UP);assert(g.remaining==t);
 live(&g);g.car[0].b.x=-375*Q;g.car[0].b.z=-575*Q;g.car[0].boost=0;game_step(&g,0,0);assert(g.car[0].boost==100&&g.pads[0]>0);
 live(&g);g.car[0].boost=0;for(int i=0;i<100;i++)game_step(&g,BOOST,0);assert(g.car[0].boost==0);
 live(&g);g.car[0].b.z=-40*Q;g.car[0].b.vz=12*Q;game_step(&g,UP|BOOST,0);assert(g.ball.vz>0);
 game_init(&g,1);for(int i=0;i<6000;i++)game_step(&g,UP|BOOST,0);assert(g.remaining==180*HZ&&g.car[0].boost==100);
 /* Oriented car-box contacts and the enlarged ball's wall/goal clearance. */
 game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=0;g.ball.z=42*Q;
 game_step(&g,0,0);assert(g.ball.z>=(CAR_HALF_LENGTH+BALL_RADIUS)*Q);
 game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=0;g.ball.x=33*Q;
 game_step(&g,0,0);assert(g.ball.x>=(CAR_HALF_WIDTH+BALL_RADIUS)*Q);
 game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=0;g.car[0].angle=64;g.ball.x=42*Q;
 game_step(&g,0,0);assert(g.ball.x>=(CAR_HALF_LENGTH+BALL_RADIUS)*Q);
 game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=0;g.ball.x=40*Q;g.ball.z=49*Q;
 game_step(&g,0,0);assert(g.ball.x==40*Q&&g.ball.z==49*Q);
 game_init(&g,1);g.phase=PH_PLAY;g.ball.x=(FIELD_X-BALL_RADIUS+1)*Q;
 game_step(&g,0,0);assert(g.ball.x<=(FIELD_X-BALL_RADIUS)*Q&&g.ball.vx<=0);
 live(&g);g.ball.z=(FIELD_Z+BALL_RADIUS-1)*Q;game_step(&g,0,0);assert(g.phase==PH_PLAY);
 live(&g);g.ball.z=(FIELD_Z+BALL_RADIUS+1)*Q;game_step(&g,0,0);assert(g.phase==PH_GOAL);
 /* Long random-input games exercise bounds and arithmetic under sanitizers. */
 srand(67);for(int m=0;m<80;m++){live(&g);for(int i=0;i<6000;i++){game_step(&g,rand()&127,rand()&127);valid(&g);if(g.phase==PH_END)break;}}
 /* Run full bot-v-bot matches and report whether it can turn play into goals. */
 unsigned goals=0;for(int m=0;m<8;m++){game_init(&g,0);g.car[0].b.x=(m-4)*8*Q;for(int i=0;i<18000&&g.phase!=PH_END;i++){game_step(&g,bot_input(&g,0,1),bot_input(&g,1,1));valid(&g);}goals+=g.score[0]+g.score[1];printf("bot match %d: %u-%u phase=%u\n",m,g.score[0],g.score[1],g.phase);}assert(goals>0);puts("All physics/match checks passed.");}
