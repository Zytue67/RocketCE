/* Two copies of the actual linklib + net + game, joined by a USB-controller
 * simulator. This verifies application integration, not electrical timing. */
#include <stdint.h>
typedef uint32_t uint24_t;
#define usb_transfer_data_t size_t
#include "usbdrvce.h"
#include "net.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#define DECL(P) bool P##_start(void);void P##_stop(void);void P##_poll(Game*,uint8_t,uint32_t);bool P##_ready(uint32_t);int P##_player(void);uint8_t P##_input(uint32_t);net_status_t P##_status(uint32_t);bool P##_transport_Start(void);void P##_transport_Stop(void);const link_devices_t *P##_transport_Devices(void);link_status_t P##_transport_Status(void);bool P##_transport_Read(uint8_t,void*,size_t*);bool P##_transport_Write(uint8_t,const void*,size_t*);
DECL(a) DECL(b)
static int current,hostSide;
static bool plugged=true,active[2];
static uint32_t cycles;
static const usb_standard_descriptors_t *desc[2];
static usb_event_callback_t event[2];
static void *peerData[2];
static int refs[2];
static struct Device {int owner;} devices[2]={{0},{1}};
static struct Endpoint {int owner;uint8_t address;} endpoints[2][2]={{{0,1},{0,0x82}},{{1,1},{1,0x82}}};
static struct Transfer {void *buffer;size_t n;usb_transfer_callback_t cb;size_t *data;} pending[2][2];
static bool connectedEvent[2],enabledEvent[2];
static usb_error_t nextIDError;
static void dispatch(int side,usb_event_t type,void *data){int saved=current;current=side;assert(event[side](type,data,NULL)==USB_SUCCESS);current=saved;}
static void cancel(void){for(int i=0;i<2;i++)for(int j=0;j<2;j++)if(pending[i][j].cb){struct Transfer t=pending[i][j];pending[i][j].cb=NULL;t.cb((usb_endpoint_t)&endpoints[i][j],USB_TRANSFER_ERROR,0,t.data);}}
#define ADAPT(P,I) bool P##_link_Start(void){current=I;return P##_transport_Start();}void P##_link_Stop(void){current=I;P##_transport_Stop();}const link_devices_t *P##_link_Devices(void){current=I;return P##_transport_Devices();}link_status_t P##_link_Status(void){current=I;return P##_transport_Status();}bool P##_link_QueueRead(uint8_t d,void*b,size_t*n){current=I;return P##_transport_Read(d,b,n);}bool P##_link_QueueWrite(uint8_t d,const void*b,size_t*n){current=I;return P##_transport_Write(d,b,n);}
ADAPT(a,0) ADAPT(b,1)
usb_error_t usb_Init(usb_event_callback_t h,void *data,const usb_standard_descriptors_t *d,usb_init_flags_t f){(void)data;(void)f;event[current]=h;desc[current]=d;active[current]=true;if(active[1-current]&&plugged)connectedEvent[0]=connectedEvent[1]=true;return USB_SUCCESS;}
void usb_Cleanup(void){cancel();peerData[0]=peerData[1]=NULL;active[current]=false;connectedEvent[current]=enabledEvent[current]=false;if(active[1-current])dispatch(1-current,USB_DEVICE_DISCONNECTED_EVENT,&devices[1-current]);}
usb_error_t usb_HandleEvents(void){if(connectedEvent[current]){connectedEvent[current]=false;dispatch(current,USB_DEVICE_CONNECTED_EVENT,&devices[current]);}if(enabledEvent[current]){enabledEvent[current]=false;dispatch(current,USB_DEVICE_ENABLED_EVENT,&devices[current]);}return USB_SUCCESS;}
usb_role_t usb_GetRole(void){return current==hostSide?USB_ROLE_HOST:USB_ROLE_DEVICE;}
uint32_t link_test_clock(void){return (uint32_t)((uint64_t)cycles*32768/48000000);}
usb_device_flags_t usb_GetDeviceFlags(usb_device_t d){(void)d;return USB_IS_DEVICE|USB_IS_DISABLED;}
usb_device_t usb_RefDevice(usb_device_t d){if(d)refs[((struct Device*)d)->owner]++;return d;}
usb_device_t usb_UnrefDevice(usb_device_t d){if(d){int i=((struct Device*)d)->owner;assert(refs[i]>0);refs[i]--;}return NULL;}
usb_device_t usb_FindDevice(usb_device_t root,usb_device_t from,usb_find_device_flags_t f){(void)root;(void)f;return !from&&plugged&&active[current]&&active[1-current]?(usb_device_t)&devices[current]:NULL;}
uint8_t usb_GetDeviceAddress(usb_device_t d){return ((struct Device*)d)->owner==hostSide?1:0;}
void usb_SetDeviceData(usb_device_t d,void *p){peerData[((struct Device*)d)->owner]=p;}
void *usb_GetDeviceData(usb_device_t d){return peerData[((struct Device*)d)->owner];}
usb_error_t usb_ResetDevice(usb_device_t d){dispatch(current,USB_DEVICE_DISABLED_EVENT,d);enabledEvent[current]=true;return USB_SUCCESS;}
size_t usb_GetConfigurationDescriptorTotalLength(usb_device_t d,uint8_t index){(void)d;assert(index==0);return desc[1-current]->configurations[0]->wTotalLength;}
usb_error_t usb_GetDescriptor(usb_device_t d,usb_descriptor_type_t type,uint8_t i,void *b,size_t n,size_t *done){(void)d;assert(type==USB_CONFIGURATION_DESCRIPTOR&&i==0);memcpy(b,desc[1-current]->configurations[0],n);*done=n;return USB_SUCCESS;}
usb_error_t usb_GetStringDescriptor(usb_device_t d,uint8_t index,uint16_t lang,usb_string_descriptor_t *b,size_t n,size_t *done){(void)d;if(nextIDError){usb_error_t e=nextIDError;nextIDError=0;return e;}assert(index==1&&lang==0x409);assert(desc[1-current]->langids->bLength==4);const usb_string_descriptor_t *key=desc[1-current]->strings[0];assert(n==key->bLength);memcpy(b,key,n);*done=n;return USB_SUCCESS;}
usb_error_t usb_SetConfiguration(usb_device_t d,const usb_configuration_descriptor_t *config,size_t n){(void)d;assert(n==config->wTotalLength&&config->bConfigurationValue==1);
 const uint8_t *wire=(const uint8_t *)config;
 assert(n==32&&wire[7]==0x80&&wire[0]==9&&wire[9]==9&&wire[18]==7&&wire[25]==7);
 assert(wire[20]==1&&wire[27]==0x82&&(wire[20]&15)!=(wire[27]&15)&&wire[22]==64&&wire[29]==64);dispatch(1-current,USB_HOST_CONFIGURE_EVENT,(void*)desc[1-current]->configurations[0]);return USB_SUCCESS;}
usb_endpoint_t usb_GetDeviceEndpoint(usb_device_t d,uint8_t address){(void)d;assert(address==1||address==0x82);return (usb_endpoint_t)&endpoints[current][address==0x82];}
usb_error_t usb_ScheduleTransfer(usb_endpoint_t e,void*b,size_t n,usb_transfer_callback_t cb,size_t *data){struct Endpoint *ep=(struct Endpoint*)e;struct Transfer *p=&pending[ep->owner][ep->address==0x82];
 /* A device FIFO cannot service two directions at the same endpoint number. */
 if(current!=hostSide)for(int j=0;j<2;j++)if(pending[current][j].cb)
  assert((endpoints[current][j].address&15)!=(ep->address&15));
 assert(!p->cb&&(n==223||n==256));*p=(struct Transfer){b,n,cb,data};return USB_SUCCESS;}
static void pump(void){if(!plugged)return;for(int address=0;address<2;address++){int sender=address?1-hostSide:hostSide,receiver=1-sender;struct Transfer a=pending[sender][address],b=pending[receiver][address];if(a.cb&&b.cb){assert(a.n==223&&b.n==256);memcpy(b.buffer,a.buffer,a.n);pending[sender][address].cb=pending[receiver][address].cb=NULL;a.cb((usb_endpoint_t)&endpoints[sender][address],USB_TRANSFER_COMPLETED,a.n,a.data);b.cb((usb_endpoint_t)&endpoints[receiver][address],USB_TRANSFER_COMPLETED,a.n,b.data);}}}
static void poll(Game *a,Game *b,uint32_t t){cycles=(uint32_t)((uint64_t)t*48000000/32768);a_poll(a,UP,t);b_poll(b,UP|BOOST,t);pump();}
int main(void){
 for(int swap=0;swap<2;swap++){
  hostSide=swap;Game g[2];game_init(&g[0],0);game_init(&g[1],0);assert(a_start());
  poll(&g[0],&g[1],1100);assert(!a_ready(1100)&&a_player()==-1);assert(b_start());nextIDError=USB_ERROR_TIMEOUT;
  for(uint32_t t=2200;t<110000;t+=1100)poll(&g[0],&g[1],t);
  assert(a_ready(110000)&&b_ready(110000));assert(a_player()==(swap?1:0)&&b_player()==(swap?0:1));
  for(uint32_t t=111100;t<770000;t+=1100){poll(&g[0],&g[1],t);if(swap){if(b_ready(t))game_step(&g[1],UP|BOOST,b_input(t));}else if(a_ready(t))game_step(&g[0],UP,a_input(t));}
  for(uint32_t t=771100;t<782000;t+=1100)poll(&g[0],&g[1],t);
  assert(memcmp(&g[0],&g[1],sizeof(Game))==0&&g[hostSide].tick>500);
  Game *host=&g[hostSide],*guest=&g[1-hostSide];game_init(host,0);host->phase=PH_PLAY;host->remaining=1;
  host->ball.x=0;host->ball.y=BALL_RADIUS*Q;host->ball.z=(FIELD_Z+BALL_RADIUS)*Q;host->ball.vx=host->ball.vz=0;game_step(host,0,0);assert(host->phase==PH_GOAL&&host->score[0]==1);
  for(uint32_t t=783100;t<794000;t+=1100)poll(&g[0],&g[1],t);assert(guest->phase==PH_GOAL&&guest->score[0]==1);
  host->phase=PH_END;host->phaseTicks=0;for(uint32_t t=795100;t<806000;t+=1100)poll(&g[0],&g[1],t);assert(guest->phase==PH_END);
  game_init(host,0);for(uint32_t t=807100;t<818000;t+=1100)poll(&g[0],&g[1],t);assert(guest->phase==PH_KICKOFF&&guest->score[0]==0);
  plugged=false;cancel();peerData[0]=peerData[1]=NULL;dispatch(0,USB_DEVICE_DISCONNECTED_EVENT,&devices[0]);dispatch(1,USB_DEVICE_DISCONNECTED_EVENT,&devices[1]);poll(&g[0],&g[1],819100);assert(!a_ready(819100)&&!b_ready(819100));
  plugged=true;connectedEvent[0]=connectedEvent[1]=true;
  for(uint32_t t=820200;t<846000;t+=1100)poll(&g[0],&g[1],t);assert(a_ready(846000)&&b_ready(846000));
  b_stop();assert(b_start());for(uint32_t t=847100;t<876000;t+=1100)poll(&g[0],&g[1],t);assert(a_ready(876000)&&b_ready(876000));
  a_stop();b_stop();assert(!refs[0]&&!refs[1]);
 }
 puts("Integrated actual linklib + net + game: staggered launch, timeout recovery, both cable orientations, two-sided session ACK, 600 gameplay ticks, equal snapshots, goals/results/rematch, unplug/replug and peer restart passed (simulated USB controllers).");
}
