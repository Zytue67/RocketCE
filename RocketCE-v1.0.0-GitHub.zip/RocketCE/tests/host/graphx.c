#include "graphx.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
static FILE *out;static unsigned palette[256],color,fg,sx=1,sy=1;
void host_open(const char *path){out=fopen(path,"w");fprintf(out,"<svg xmlns='http://www.w3.org/2000/svg' width='320' height='240' viewBox='0 0 320 240' shape-rendering='crispEdges'>\n");}
void host_close(void){fprintf(out,"</svg>\n");fclose(out);}
void gfx_SetPalette(const void *p,unsigned n,unsigned off){const uint16_t *v=p;for(unsigned i=0;i<n/2;i++){unsigned a=v[i];palette[off+i]=(((a>>10)&31)*255/31<<16)|(((a>>5)&31)*255/31<<8)|((a&31)*255/31);}}
void gfx_SetTextFGColor(uint8_t c){fg=c;}
void gfx_SetTextBGColor(uint8_t c){(void)c;}
void gfx_SetTextTransparentColor(uint8_t c){(void)c;}
void gfx_SetColor(uint8_t c){color=c;}
void gfx_FillRectangle(int x,int y,int w,int h){fprintf(out,"<rect x='%d' y='%d' width='%d' height='%d' fill='#%06x'/>\n",x,y,w,h,palette[color]);}
void gfx_FillRectangle_NoClip(int x,int y,int w,int h){assert(x>=0&&x<320&&y>=27&&y<=211&&w>0&&h>0&&x+w<=320&&y+h<=212);gfx_FillRectangle(x,y,w,h);}
void gfx_FillScreen(uint8_t c){color=c;gfx_FillRectangle(0,0,320,240);}
void gfx_Rectangle(int x,int y,int w,int h){fprintf(out,"<rect x='%d' y='%d' width='%d' height='%d' fill='none' stroke='#%06x' stroke-width='1'/>\n",x,y,w,h,palette[color]);}
void gfx_HorizLine(int x,int y,int w){assert(x>=0&&x<320&&y>=0&&y<240&&w>0&&x+w<=320);gfx_FillRectangle(x,y,w,1);}
void gfx_HorizLine_NoClip(int x,int y,int w){gfx_HorizLine(x,y,w);}
void gfx_FillCircle(int x,int y,int r){fprintf(out,"<circle cx='%d' cy='%d' r='%d' fill='#%06x'/>\n",x,y,r,palette[color]);}
void gfx_FillTriangle(int x,int y,int a,int b,int c,int d){assert(x>=0&&x<=319&&a>=0&&a<=319&&c>=0&&c<=319);assert(y>=27&&y<=211&&b>=27&&b<=211&&d>=27&&d<=211);fprintf(out,"<path d='M%d %dL%d %dL%d %dZ' fill='#%06x'/>\n",x,y,a,b,c,d,palette[color]);}
void gfx_SetTextScale(uint8_t a,uint8_t b){sx=a;sy=b;}
int gfx_GetStringWidth(const char *s){return strlen(s)*6*sx;}
void gfx_PrintStringXY(const char *s,int x,int y){if(y==229){assert(x>=0&&x+(int)strlen(s)*6<=320);}fprintf(out,"<text x='%d' y='%d' fill='#%06x' font-family='monospace' font-size='%u' font-weight='bold'>",x,y+7*sy,palette[fg],8*sy);for(;*s;s++){if(*s=='&')fputs("&amp;",out);else if(*s=='<')fputs("&lt;",out);else fputc(*s,out);}fputs("</text>\n",out);}
void gfx_SwapDraw(void){}

void host_bitmap(const char *p){
 static const char b64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 FILE *f=fopen(p+3,"rb");assert(f);fprintf(out,"<image xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"data:image/png;base64,");
 unsigned char buf[3];size_t n;while((n=fread(buf,1,3,f))){unsigned v=(unsigned)buf[0]<<16;if(n>1)v|=(unsigned)buf[1]<<8;if(n>2)v|=buf[2];fputc(b64[v>>18],out);fputc(b64[(v>>12)&63],out);fputc(n>1?b64[(v>>6)&63]:'=',out);fputc(n>2?b64[v&63]:'=',out);}
 fclose(f);fprintf(out,"\" width=\"320\" height=\"240\"/>\n");
}

void gfx_Line(int x,int y,int a,int b){assert(x>-1000&&x<1320&&a>-1000&&a<1320&&y>-1000&&y<1240&&b>-1000&&b<1240);fprintf(out,"<path d=\"M%d %dL%d %d\" fill=\"none\" stroke=\"#%06x\"/>\n",x,y,a,b,palette[color]);}
