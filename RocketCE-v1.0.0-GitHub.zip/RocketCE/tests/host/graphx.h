#ifndef HOST_GFX_H
#define HOST_GFX_H
#include <stdint.h>
#include <stddef.h>
void gfx_SetPalette(const void*,unsigned,unsigned);
void gfx_SetTextFGColor(uint8_t);
void gfx_SetTextBGColor(uint8_t);
void gfx_SetTextTransparentColor(uint8_t);
void gfx_SetColor(uint8_t);
void gfx_FillScreen(uint8_t);
void gfx_FillRectangle(int,int,int,int);
void gfx_FillRectangle_NoClip(int,int,int,int);
void gfx_Rectangle(int,int,int,int);
void gfx_HorizLine(int,int,int);
void gfx_HorizLine_NoClip(int,int,int);
void gfx_FillCircle(int,int,int);
void gfx_Line(int,int,int,int);
void gfx_FillTriangle(int,int,int,int,int,int);
void gfx_SetTextScale(uint8_t,uint8_t);
int gfx_GetStringWidth(const char*);
void gfx_PrintStringXY(const char*,int,int);
void gfx_SwapDraw(void);
void host_open(const char*);
void host_close(void);
void host_bitmap(const char*);
#endif
