#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Game start(void){Game g;game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=-400*Q;return g;}
int main(void){
 Game g=start();g.car[0].angle=64;g.car[0].b.x=(FIELD_X-30)*Q;g.car[0].b.z=0;g.car[0].b.vx=10*Q;
 game_step(&g,UP|BOOST,0);assert(g.car[0].b.y==0&&g.car[0].b.vx<0&&g.car[0].b.vx>=-CAR_WALL_REBOUND);assert(!g.car[0].pitch&&!g.car[0].roll);
 for(int n=0;n<180;n++)game_step(&g,UP|BOOST,0);assert(g.car[0].b.y==0);
 g=start();g.car[0].b.x=(FIELD_X-20)*Q;g.car[0].b.z=(FIELD_Z-20)*Q;g.car[0].b.vx=g.car[0].b.vz=8*Q;game_step(&g,0,0);assert(g.car[0].b.x<=FIELD_X*Q&&g.car[0].b.z<=FIELD_Z*Q);assert(g.car[0].b.vx<0&&g.car[0].b.vz<0);
 g=start();g.car[0].b.y=(FIELD_HEIGHT-CAR_HEIGHT)*Q;g.car[0].b.vy=8*Q;g.car[0].jumps=2;game_step(&g,0,0);assert(g.car[0].b.vy<0&&g.car[0].jumps==2);
 g=start();g.ball.x=(FIELD_X-BALL_RADIUS-1)*Q;g.ball.y=100*Q;g.ball.vx=40*Q;game_step(&g,0,0);assert(g.ball.x<=(FIELD_X-BALL_RADIUS)*Q&&g.ball.vx<0);
 g=start();g.ball.z=(FIELD_Z-BALL_RADIUS-1)*Q;g.ball.x=(GOAL_WIDTH+50)*Q;g.ball.vz=40*Q;game_step(&g,0,0);assert(g.phase==PH_PLAY&&g.ball.vz<0);
 g=start();g.ball.z=(FIELD_Z-BALL_RADIUS-1)*Q;g.ball.vz=40*Q;for(int i=0;i<3&&g.phase==PH_PLAY;i++)game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.score[0]==1);
 g=start();g.car[0].b.z=-70*Q;g.car[0].b.vz=18*Q;g.ball.vz=-32*Q;game_step(&g,BOOST,0);assert(g.ball.vz>0);
 /* Both signs and axes, with boost, must stay below the rebound cap. */
 for(int axis=0;axis<2;axis++)for(int side=-1;side<=1;side+=2){
  g=start();Car *c=&g.car[0];c->b.z=0;c->angle=axis?(side>0?0:128):(side>0?64:192);
  if(axis){c->b.x=(GOAL_WIDTH+80)*Q;c->b.z=side*(FIELD_Z-CAR_HALF_LENGTH-1)*Q;c->b.vz=side*18*Q;}else{c->b.x=side*(FIELD_X-CAR_HALF_LENGTH-1)*Q;c->b.vx=side*18*Q;}
  game_step(&g,BOOST,0);int v=axis?c->b.vz:c->b.vx;assert(v*side<0&&abs(v)<=CAR_WALL_REBOUND);
 }
 /* Gentle contacts still rebound gently instead of always applying the cap. */
 g=start();g.car[0].angle=64;g.car[0].b.x=(FIELD_X-CAR_HALF_LENGTH)*Q-Q/4;g.car[0].b.vx=Q;game_step(&g,0,0);assert(g.car[0].b.vx<0&&g.car[0].b.vx>-Q);
 /* A side hit must retain the velocity parallel to that wall. */
 g=start();g.car[0].b.z=0;g.car[0].angle=64;g.car[0].b.x=(FIELD_X-26)*Q;g.car[0].b.vx=16*Q;g.car[0].b.vz=3*Q;Game parallel=g;parallel.car[0].b.x=0;
 game_step(&g,SLIDE|BOOST,0);game_step(&parallel,SLIDE|BOOST,0);assert(g.car[0].b.vz==parallel.car[0].b.vz&&abs((int)g.car[0].b.vx)<=CAR_WALL_REBOUND);
 /* Position correction must not reverse a car already moving inward. */
 g=start();g.car[0].angle=64;g.car[0].b.x=(FIELD_X-24)*Q;g.car[0].b.vx=-Q/4;game_step(&g,0,0);assert(g.car[0].b.vx<0);
 puts("Box arena: flat wall bounce, no wall climb, corner, ceiling, fast ball rebound, opposing-speed car contact and goal opening passed.");
}
