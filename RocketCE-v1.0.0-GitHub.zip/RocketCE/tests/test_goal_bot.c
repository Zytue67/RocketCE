#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Game setup(void){Game g;game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=0;return g;}
int main(void){
 /* Whole-ball line uses fixed-point equality, without requiring an extra unit. */
 for(int side=-1;side<=1;side+=2){Game g=setup();g.ball.z=side*(FIELD_Z+BALL_RADIUS)*Q;g.ball.vz=0;game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.score[side>0?0:1]==1);
  g=setup();g.car[0].angle=side>0?0:128;g.car[0].b.z=side*(FIELD_Z-25)*Q;g.ball.z=side*(FIELD_Z+BALL_RADIUS-1)*Q;
  for(int n=0;n<100&&g.phase==PH_PLAY;n++)game_step(&g,UP|BOOST,0);assert(g.phase==PH_GOAL);
  g=setup();g.car[0].angle=side>0?0:128;g.car[0].b.z=side*(FIELD_Z-45)*Q;g.ball.x=300*Q;
  int entered=0;for(int n=0;n<60;n++){game_step(&g,UP,0);if(g.car[0].b.z*side>FIELD_Z*Q)entered=1;}assert(entered&&abs((int)g.car[0].b.z)<=(FIELD_Z+GOAL_DEPTH)*Q);
 }
 /* A sphere may approach a post before its cross-section reaches the post. */
 Game g=setup();g.ball.x=(GOAL_WIDTH-BALL_RADIUS+3)*Q;g.ball.z=(FIELD_Z-BALL_RADIUS+1)*Q;g.ball.vz=Q;game_step(&g,0,0);assert(g.ball.vz>0);
 /* Post-grazing shots can deflect into either goal, rather than reversing at an invisible plane. */
 for(int side=-1;side<=1;side+=2)for(int edge=-1;edge<=1;edge+=2){g=setup();g.ball.x=edge*(GOAL_WIDTH-BALL_RADIUS+3)*Q;g.ball.z=side*(FIELD_Z-BALL_RADIUS-2)*Q;g.ball.vz=side*6*Q;for(int n=0;n<90&&g.phase==PH_PLAY;n++)game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.score[side>0?0:1]==1);}
 /* Pocket side/roof contacts redirect their own component, not the forward one. */
 g=setup();g.ball.x=(GOAL_WIDTH-BALL_RADIUS+2)*Q;g.ball.z=(FIELD_Z+5)*Q;g.ball.vz=2*Q;g.ball.vx=Q;game_step(&g,0,0);assert(g.ball.vz>0&&g.ball.vx<0);
 g=setup();g.ball.z=(FIELD_Z+5)*Q;g.ball.y=(GOAL_HEIGHT-BALL_RADIUS+2)*Q;g.ball.vy=2*Q;g.ball.vz=Q;game_step(&g,0,0);assert(g.ball.vy<0&&g.ball.vz>0);
 /* A clear goal mouth must not trigger the wall-escape maneuver. */
 game_init(&g,0);g.phase=PH_PLAY;g.car[0].b.z=(FIELD_Z-60)*Q;g.ball.z=(FIELD_Z-2)*Q;uint8_t approach=bot_input(&g,0,1);assert((approach&UP)&&!(approach&DOWN)&&!g.car[0].botEscape);
 /* Entered goal pockets have actual side, roof and back bounds. */
 g=setup();g.car[0].b.z=(FIELD_Z+30)*Q;g.car[0].b.x=(GOAL_WIDTH-20)*Q;g.car[0].b.vx=8*Q;g.ball.x=300*Q;game_step(&g,0,0);assert(g.car[0].b.x<=(GOAL_WIDTH-CAR_HALF_WIDTH)*Q&&g.car[0].b.z>FIELD_Z*Q);
 g=setup();g.car[0].b.z=(FIELD_Z+30)*Q;g.car[0].b.y=(GOAL_HEIGHT-CAR_HEIGHT-1)*Q;g.car[0].b.vy=5*Q;g.ball.x=300*Q;game_step(&g,0,0);assert(g.car[0].b.y<=(GOAL_HEIGHT-CAR_HEIGHT)*Q&&g.car[0].b.vy<0);
 for(int sx=-1;sx<=1;sx+=2)for(int sz=-1;sz<=1;sz+=2)for(int who=0;who<2;who++){
  game_init(&g,0);g.phase=PH_PLAY;g.car[who].b.x=sx*(FIELD_X-31)*Q;g.car[who].b.z=sz*(FIELD_Z-31)*Q;g.car[who].angle=sx>0?(sz>0?32:96):(sz>0?224:160);g.car[1-who].b.z=-250*Q;
  int escaped=0,reversed=0;for(int n=0;n<240;n++){uint8_t keys=bot_input(&g,who,1);if(keys&DOWN)reversed=1;game_step(&g,who==0?keys:0,who==1?keys:0);if(abs((int)g.car[who].b.x)<(FIELD_X-100)*Q&&abs((int)g.car[who].b.z)<(FIELD_Z-100)*Q)escaped=1;}
  assert(reversed&&escaped);
 }
 puts("Goal/bot regressions: whole-ball line, push-through goals, car entry, post approach, pocket roof/sides and recovery from all four corners for either bot passed.");
}
