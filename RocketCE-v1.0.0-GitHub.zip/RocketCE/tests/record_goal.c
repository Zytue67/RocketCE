/* Host-only 10 Hz goal-celebration preview. Not calculator timing evidence. */
#include "game.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
int main(void){Game g;char path[100];game_init(&g,0);g.phase=PH_PLAY;g.car[0].b.z=(FIELD_Z-100)*Q;g.car[1].b.z=(FIELD_Z-80)*Q;g.car[1].b.x=100*Q;g.ball.z=(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=4*Q;game_step(&g,0,0);render_init();render_reset();for(unsigned i=0;i<30;i++){snprintf(path,sizeof(path),"preview-frames/goal/%03u.svg",i);host_open(path);render_game(&g,0,0,NULL);host_close();for(int j=0;j<3;j++)game_step(&g,0,0);}return 0;}
