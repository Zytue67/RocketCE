#include "controls.h"
#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){ControlTimeline t;int released;controls_init(&t,0);
controls_sample(&t,1000,UP);controls_sample(&t,1200,JUMP|RIGHT);controls_sample(&t,1210,BOOST);
assert(controls_step(&t,1100,&released)==UP&&!released);
assert(controls_step(&t,1300,&released)==(JUMP|RIGHT|BOOST)&&released);
assert(controls_step(&t,1400,&released)==BOOST&&!released);
controls_init(&t,0);controls_sample(&t,0xfffffff0u,JUMP);controls_sample(&t,8,0);
assert(controls_step(&t,0xfffffff5u,&released)==JUMP);assert(controls_step(&t,10,&released)==0&&released);
puts("Timestamped controls: short taps, jump direction, release and timer wrap passed.");}
