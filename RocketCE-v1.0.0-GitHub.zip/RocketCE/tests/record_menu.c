/* Host-only menu animation preview. */
#include "ui.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
int main(void){char p[100];render_init();ui_init();host_open("/dev/null");ui_menu(0);host_close();for(unsigned i=0;i<32;i++){snprintf(p,sizeof(p),"preview-frames/menu/%03u.svg",i);host_open(p);ui_menu_tick(i*8192UL);host_close();}return 0;}
