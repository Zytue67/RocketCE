#include "ui.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
static void open(const char *name){char p[100];snprintf(p,sizeof(p),"tests/%s.svg",name);host_open(p);}
int main(void){Game g;open("opening");render_init();ui_init();ui_intro(12);host_close();open("title");ui_title(24);host_close();open("menu");ui_menu(0);host_close();open("menu-link");ui_menu(2);host_close();open("menu-tips");ui_menu_tick(1365UL*500);host_close();net_status_t ns={.usb={LINK_WAIT,0,0,0,0}};open("link-wait");ui_link(ns,1);host_close();ns.usb.stage=LINK_PEER;ns.usb.guest=1;ns.sent=4;open("link-sync");ui_link(ns,2);host_close();ns.usb.stage=LINK_MISMATCH;open("link-error");ui_link(ns,3);host_close();ns.usb=(link_status_t){LINK_ERROR,2,2,LINK_INIT,0};open("link-init-error");ui_link(ns,0);host_close();ns.roleConflict=true;open("link-role-error");ui_link(ns,1);host_close();open("controls");ui_controls();host_close();game_init(&g,0);g.phase=PH_END;g.score[0]=3;g.score[1]=1;open("victory");ui_result(&g,0,0,0,4);host_close();open("defeat");ui_result(&g,1,0,1,8);host_close();open("link-result");ui_result(&g,1,1,0,20);host_close();
 for(unsigned i=0;i<64;i++){host_open("/dev/null");ui_intro(i);ui_title(i);ui_menu(i%5);ui_menu_tick((uint32_t)i*1365*137);ui_result(&g,i%2,i%2,i%2,i);host_close();}host_open("/dev/null");ui_menu_tick(UINT32_MAX);host_close();return 0;}
