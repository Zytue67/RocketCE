"""Focused instruction/flag interpreter for the generated _target helper.
This does not emulate USB or the entire CPU/game. It exercises the actual
native helper's pointer store and conditional calls, which host C tests miss.
"""
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parents[1]
def execute(text,old,new,a=0):
 text=text.split('_target:',1)[1].split('.Lfunc_end',1)[0]
 lines=[];labels={}
 for raw in text.splitlines():
  line=raw.split(';',1)[0].strip()
  if not line or line.startswith(('.local','.size','.section')):continue
  if line.endswith(':'):labels[line[:-1]]=len(lines)
  else:lines.append(line)
 r=dict(hl=0x12345,de=0x34567,bc=0x23456,ix=0x2000,iy=0,a=a)
 mem={0x2006:new,0x1004:old,0x100c:0};stack=[];z=False;carry=False;refs=[];unrefs=[]
 def value(s):
  s=s.strip()
  if s in r:return r[s]
  if s in ('l','h','c','b','e','d'):return (r[{'l':'hl','h':'hl','c':'bc','b':'bc','e':'de','d':'de'}[s]]>>(8 if s in ('h','b','d') else 0))&255
  if s.startswith('('):return mem.get(address(s[1:-1]),0)
  if s.startswith('_storage'):return 0x1000+int(s.partition('+')[2] or 0)
  return int(s)
 def address(s):
  parts=s.replace(' ','').split('+');return value(parts[0])+(int(parts[1]) if len(parts)>1 else 0)
 def store(s,v):
  s=s.strip()
  if s.startswith('('):mem[address(s[1:-1])]=v
  elif s in r:r[s]=v&0xffffff
  else:
   pair={'l':'hl','h':'hl','c':'bc','b':'bc','e':'de','d':'de'}[s];shift=8 if s in ('h','b','d') else 0
   r[pair]=(r[pair]&~(255<<shift))|((v&255)<<shift)
 pc=0
 for _ in range(150):
  if pc>=len(lines):break
  line=lines[pc];pc+=1;op,_,args=line.partition('\t');
  if not args:op,_,args=line.partition(' ')
  op=op.strip();parts=[x.strip() for x in args.split(',')]
  if op=='ld':store(parts[0],value(parts[1]))
  elif op=='push':stack.append(value(parts[0]))
  elif op=='pop':store(parts[0],stack.pop())
  elif op=='or':r['a']=(r['a']|value(parts[-1]))&255;z=r['a']==0;carry=False
  elif op in ('sbc','adc','add'):
   x=value(parts[0]);y=value(parts[1]);n=x-y-int(carry) if op=='sbc' else x+y+(int(carry) if op=='adc' else 0)
   carry=n<0 or n>0xffffff;store(parts[0],n)
   if op!='add':z=value(parts[0])==0
  elif op.startswith('inc'):store(parts[0],value(parts[0])+1)
  elif op=='jr':
   if len(parts)==1 or (parts[0]=='z' and z) or (parts[0]=='nz' and not z):pc=labels[parts[-1]]
  elif op=='call':
   if len(parts)>1 and ((parts[0]=='z' and not z) or (parts[0]=='nz' and z)):continue
   name=parts[-1]
   if name=='__frameset0':stack.append(r['ix'])
   elif name=='_usb_RefDevice':
    ptr=stack[-1]
    if ptr:refs.append(ptr)
    r['hl']=ptr
   elif name=='_usb_UnrefDevice':
    ptr=stack[-1]
    if ptr:unrefs.append(ptr)
    r['hl']=0;z=True;carry=False
   else:raise AssertionError('Unsupported call '+name)
  elif op=='ret':break
  else:raise AssertionError('Unsupported generated instruction '+line)
 else:raise AssertionError('Helper did not terminate')
 return mem[0x1004],refs,unrefs
bad=(ROOT/'tests/fixtures/target-before-v0312.s').read_text()
assert execute(bad,0,0xd14020)[0]==0,'Known failing fixture must expose the lost pointer'
text=(Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'obj/lto.s').read_text()
for old,new in [(0,0xd14020),(0xd14020,0xd14060),(0xd14020,0),(0,0),(0xd14020,0xd14020)]:
 for a in (0,1,255):
  got,refs,unrefs=execute(text,old,new,a)
  assert got==new,(hex(old),hex(new),hex(got))
  assert refs==([new] if new and old!=new else [])
  assert unrefs==([old] if old and old!=new else [])
print('Native helper instructions: previous lost-pointer regression reproduced; current emitted helper preserves device pointers and balances reference calls across 15 cases.')
