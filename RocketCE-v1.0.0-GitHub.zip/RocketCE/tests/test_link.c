/* Exercise the real linklib against USB calls, not a replacement linklib.
 * -fshort-wchar matches CE's UTF-16 descriptor strings. */
#include <stdint.h>
typedef uint32_t uint24_t;
#define ROCKET_LINK_HOST
#define LINKLIB_KEY "RocketCE-20"
#include "../src/linklib.c"
#include <assert.h>
#include <stdio.h>
static usb_role_t role=USB_ROLE_HOST;
static const usb_standard_descriptors_t *descriptors;
static void *deviceData;
static int fakeDevice,endpoint,resetCount,cleanupCount,refs;
static bool wrongKey,inEvent,disconnectDuringID,attached,enabled,delayEnable;
static usb_error_t initError,pollError,idError,configError,resetError;
static uint32_t cycles;
static usb_transfer_callback_t callback;
static size_t *callbackData;
static uint8_t lastEndpoint;
static void dispatch(usb_event_t event,void *data){
 if(event==USB_DEVICE_CONNECTED_EVENT)attached=true;
 if(event==USB_DEVICE_ENABLED_EVENT||event==USB_HOST_CONFIGURE_EVENT)attached=enabled=true;
 if(event==USB_DEVICE_DISABLED_EVENT)enabled=false;
 if(event==USB_DEVICE_DISCONNECTED_EVENT)attached=enabled=false;
 inEvent=true;assert(event_handler(event,data,NULL)==USB_SUCCESS);inEvent=false;}
usb_error_t usb_Init(usb_event_callback_t h,void *data,const usb_standard_descriptors_t *d,usb_init_flags_t flags){(void)h;(void)data;(void)flags;descriptors=d;return initError;}
void usb_Cleanup(void){cleanupCount++;deviceData=NULL;if(callback){callback(NULL,USB_TRANSFER_ERROR,0,callbackData);callback=NULL;}}
usb_error_t usb_HandleEvents(void){return pollError;}
usb_role_t usb_GetRole(void){return role;}
uint32_t link_test_clock(void){return cycles;}
usb_device_t usb_RefDevice(usb_device_t d){if(d)refs++;return d;}
usb_device_t usb_UnrefDevice(usb_device_t d){if(d){assert(refs>0);refs--;}return NULL;}
usb_device_t usb_FindDevice(usb_device_t root,usb_device_t from,usb_find_device_flags_t flags){(void)root;return from||!attached||((flags&USB_SKIP_DISABLED)&&!enabled)?NULL:(usb_device_t)&fakeDevice;}
usb_device_flags_t usb_GetDeviceFlags(usb_device_t d){(void)d;return USB_IS_DEVICE|(enabled?USB_IS_ENABLED:USB_IS_DISABLED);}
uint8_t usb_GetDeviceAddress(usb_device_t d){(void)d;return role==USB_ROLE_HOST?1:0;}
void usb_SetDeviceData(usb_device_t d,void *v){(void)d;deviceData=v;}
void *usb_GetDeviceData(usb_device_t d){(void)d;return deviceData;}
usb_error_t usb_ResetDevice(usb_device_t d){assert(!inEvent);resetCount++;dispatch(USB_DEVICE_DISABLED_EVENT,d);if(resetError)return resetError;if(!delayEnable)dispatch(USB_DEVICE_ENABLED_EVENT,d);return USB_SUCCESS;}
size_t usb_GetConfigurationDescriptorTotalLength(usb_device_t d,uint8_t i){(void)d;(void)i;return 32;}
usb_error_t usb_GetDescriptor(usb_device_t d,usb_descriptor_type_t t,uint8_t i,void *b,size_t n,size_t *done){(void)d;(void)t;(void)i;assert(!inEvent);memset(b,0,n);*done=n;return USB_SUCCESS;}
usb_error_t usb_SetConfiguration(usb_device_t d,const usb_configuration_descriptor_t *c,size_t n){(void)d;(void)c;assert(!inEvent&&n==32);return configError;}
usb_error_t usb_GetStringDescriptor(usb_device_t d,uint8_t i,uint16_t lang,usb_string_descriptor_t *b,size_t n,size_t *done){assert(!inEvent);assert(i==1&&lang==0x409);if(idError)return idError;memcpy(b,&key,n);if(wrongKey)b->bString[0]^=1;*done=n;if(disconnectDuringID)dispatch(USB_DEVICE_DISCONNECTED_EVENT,d);return USB_SUCCESS;}
usb_endpoint_t usb_GetDeviceEndpoint(usb_device_t d,uint8_t e){assert(d);lastEndpoint=e;return (usb_endpoint_t)&endpoint;}
usb_error_t usb_ScheduleTransfer(usb_endpoint_t e,void *b,size_t n,usb_transfer_callback_t cb,size_t *data){(void)e;(void)b;assert(n==223);assert(!callback);callback=cb;callbackData=data;return USB_SUCCESS;}
static void complete(void){callback(NULL,USB_TRANSFER_COMPLETED,223,callbackData);callback=NULL;}
int main(void){
 assert(link_Start());assert(descriptors->langids->bLength==4);assert(descriptors->langids->bString[0]==0x409);
 assert(key.bLength==2+sizeof(uint16_t)*(sizeof(LINKLIB_KEY)-1));
 const uint8_t *wire=(const uint8_t *)descriptors->configurations[0];
 assert(wire[0]==9&&wire[1]==USB_CONFIGURATION_DESCRIPTOR&&wire[2]==32&&wire[3]==0&&wire[7]==0x80);
 assert(wire[9]==9&&wire[10]==USB_INTERFACE_DESCRIPTOR&&wire[13]==2);
 assert(wire[18]==7&&wire[19]==USB_ENDPOINT_DESCRIPTOR&&wire[20]==1&&wire[22]==64);
 assert(wire[25]==7&&wire[26]==USB_ENDPOINT_DESCRIPTOR&&wire[27]==0x82&&wire[29]==64);
 assert(!link_Devices()->count);
 dispatch(USB_DEVICE_CONNECTED_EVENT,&fakeDevice);assert(resetCount==0);link_Poll();assert(resetCount==1&&link_Status().attempts==1); // Deferred, even with nested disable/enable events.
 wrongKey=true;link_Poll();assert(link_Status().stage==LINK_MISMATCH&&!link_Devices()->count);
 wrongKey=false;link_Poll();assert(!link_Devices()->count); // One-second backoff.
 cycles+=32768;link_Poll();assert(link_Status().stage==LINK_PEER&&link_Devices()->count==1&&link_Devices()->self==0);
 uint8_t buf[223];size_t n=223;assert(link_QueueRead(1,buf,&n)&&n==LINK_PENDING&&lastEndpoint==0x82);complete();assert(n==223);
 n=223;assert(link_QueueWrite(1,buf,&n)&&lastEndpoint==1);complete();
 dispatch(USB_DEVICE_DISABLED_EVENT,&fakeDevice);assert(!link_Devices()->count&&link_Status().stage==LINK_WAIT);link_Stop();assert(refs==0);
 role=USB_ROLE_DEVICE;assert(link_Start());assert(link_Devices()->self==1);assert(!link_Devices()->count);
 usb_configuration_descriptor_t config={.bConfigurationValue=1};dispatch(USB_HOST_CONFIGURE_EVENT,&config);assert(link_Devices()->count==1);
 n=223;assert(link_QueueRead(0,buf,&n)&&lastEndpoint==1);complete();
 n=223;assert(link_QueueWrite(0,buf,&n)&&lastEndpoint==0x82);link_Stop();assert(n==0&&refs==0);
 role=USB_ROLE_HOST;assert(link_Start());dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);
 idError=USB_ERROR_TIMEOUT;link_Poll();assert(link_Status().stage==LINK_ERROR&&link_Status().step==LINK_ID);assert(state); // Recoverable, not shutdown.
 idError=USB_SUCCESS;cycles+=32768;link_Poll();assert(link_Devices()->count==1);link_Stop();assert(refs==0);
 assert(link_Start());dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);configError=USB_ERROR_TIMEOUT;link_Poll();assert(state&&link_Status().step==LINK_CONFIG);
 configError=USB_SUCCESS;cycles+=32768;link_Poll();assert(link_Devices()->count==1);link_Stop();assert(refs==0);
 assert(link_Start());dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);disconnectDuringID=true;link_Poll();assert(!link_Devices()->count&&refs==0);disconnectDuringID=false;link_Stop();
 assert(link_Start());dispatch(USB_DEVICE_CONNECTED_EVENT,&fakeDevice);resetError=USB_ERROR_TIMEOUT;link_Poll();assert(state&&link_Status().step==LINK_RESET);
 resetError=USB_SUCCESS;cycles+=32768;link_Poll();link_Poll();assert(link_Devices()->count==1);link_Stop();assert(refs==0);
  /* No CONNECTED callback: enumerate an already-attached disabled peer. */
 attached=true;enabled=false;assert(link_Start());link_Poll();link_Poll();assert(link_Devices()->count==1);link_Stop();
 /* CONNECTED before ROLE_CHANGED must not discard the queued host reset. */
 assert(link_Start());dispatch(USB_DEVICE_CONNECTED_EVENT,&fakeDevice);usb_role_t host=USB_ROLE_HOST;dispatch(USB_ROLE_CHANGED_EVENT,&host);link_Poll();link_Poll();assert(link_Devices()->count==1);link_Stop();
 /* Real resets complete asynchronously: no repeated reset while the guest
  * is entering USB mode, then recover automatically if it never enables. */
 attached=true;enabled=false;delayEnable=true;assert(link_Start());
 dispatch(USB_DEVICE_CONNECTED_EVENT,&fakeDevice);int resetsBefore=resetCount;
 link_Poll();assert(resetCount==resetsBefore+1);
 for(int second=1;second<=4;second++){cycles+=32768;link_Poll();assert(resetCount==resetsBefore+1);}
 dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);link_Poll();assert(link_Devices()->count==1);link_Stop();
 attached=true;enabled=false;assert(link_Start());link_Poll();resetsBefore=resetCount;
 cycles+=5UL*32768;link_Poll();assert(resetCount==resetsBefore+1);
 delayEnable=false;dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);link_Poll();assert(link_Devices()->count==1);link_Stop();assert(refs==0);
  cycles=UINT32_MAX-100;assert(link_Start());dispatch(USB_DEVICE_ENABLED_EVENT,&fakeDevice);idError=USB_ERROR_TIMEOUT;link_Poll();
 idError=USB_SUCCESS;cycles=32500;link_Poll();assert(!deviceData);cycles=32668;link_Poll();assert(link_Devices()->count==1);link_Stop();
  initError=USB_ERROR_FAILED;int before=cleanupCount;assert(!link_Start()&&cleanupCount==before+1&&link_Status().stage==LINK_ERROR);
 initError=USB_SUCCESS;assert(link_Start());pollError=USB_ERROR_TIMEOUT;link_Poll();assert(state&&link_Status().step==LINK_EVENTS);
 pollError=USB_ERROR_SYSTEM;assert(!link_Poll()&&link_Status().stage==LINK_ERROR&&!state);link_Stop();assert(refs==0);
 puts("Real linklib: deferred USB work, both cable roles, standard configuration, endpoint directions, mismatch/backoff, ID/config timeouts, disconnect during transfer, cancellation and init/fatal error recovery passed (mock USB).");
}
