#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Game setup(int side){Game g;game_init(&g,0);g.phase=PH_PLAY;g.car[0].b.z=side*(FIELD_Z-80)*Q;g.car[1].b.z=side*(FIELD_Z-270)*Q;g.ball.z=side*(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=side*4*Q;return g;}
int main(void){for(int side=-1;side<=1;side+=2){Game g=setup(side);game_step(&g,0,0);assert(g.phase==PH_GOAL&&g.phaseTicks==GOAL_CELEBRATION&&g.blastMask==3);assert(g.score[side>0?0:1]==1);assert(g.car[0].b.vz*side<0&&g.car[1].b.vz*side<0);assert(abs((int)g.car[0].b.vz)>abs((int)g.car[1].b.vz));assert(g.car[0].b.vy>g.car[1].b.vy&&g.car[1].b.vy>0);
 uint16_t clock=g.remaining;int32_t vy=g.car[0].b.vy,z=g.car[0].b.z,bz=g.ball.z;game_step(&g,UP|BOOST,UP|BOOST);assert(g.car[0].b.y>0&&g.car[0].b.z!=z&&g.car[0].b.vy==vy-75);assert(g.ball.z==bz&&g.remaining==clock&&g.score[side>0?0:1]==1);assert(g.car[0].pitch||g.car[0].roll);
 for(int i=1;i<GOAL_CELEBRATION;i++)game_step(&g,0,0);assert(g.phase==PH_KICKOFF&&g.blastMask==0&&g.ball.z==0&&g.remaining==clock);assert(g.car[0].b.y==0&&!g.car[0].pitch&&!g.car[0].roll);}
 Game g=setup(1);g.car[1].b.z=0;game_step(&g,0,0);assert(g.blastMask==1&&g.car[1].b.vz==0&&g.car[1].b.vy==0);
 g=setup(1);g.overtime=1;g.remaining=0;game_step(&g,0,0);assert(g.phase==PH_GOAL);for(int i=0;i<GOAL_CELEBRATION;i++)game_step(&g,0,0);assert(g.phase==PH_END&&g.score[0]==1);
 g=setup(1);g.remaining=1;game_step(&g,0,0);assert(g.remaining==0&&g.phase==PH_GOAL);for(int i=0;i<GOAL_CELEBRATION;i++)game_step(&g,0,0);assert(g.phase==PH_END);
 puts("Goal explosion: distance falloff, both goal directions, one-shot impulse, airborne motion/spin, frozen clock/ball, radius, kickoff reset and final-goal celebration passed.");}
