"""Verify CE compiler output, catching ABI padding that host mocks cannot.
Run after make. Reads named sections from the ELF32 native object, not C text.
"""
from pathlib import Path
import struct
p=Path(__file__).resolve().parents[1]/'obj/ROCKETCE.o'
data=p.read_bytes()
h=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
assert h[0][:6]==b'\x7fELF\x01\x01','Expected little-endian ELF32'
sections=[struct.unpack_from('<10I',data,h[6]+i*h[11]) for i in range(h[12])]
def contents(s):return data[s[4]:s[4]+s[5]]
names=contents(sections[h[13]])
def section(name):
 for s in sections:
  if names[s[0]:].split(b'\0',1)[0].decode()==name:return contents(s)
 raise AssertionError('Missing native section '+name)
wire=section('.data._link_Start.configuration1')
expected=bytes([9,2,32,0,1,1,0,0x80,250,9,4,0,0,2,255,0,0,0,7,5,1,2,64,0,0,7,5,130,2,64,0,0])
assert wire==expected,('Malformed native USB configuration tree',wire.hex())
assert section('.rodata._link_Start.langids')==bytes([4,3,9,4])
device=section('.rodata._link_Start.device')
assert len(device)==18 and device[0:2]==bytes([18,1]) and device[7]==64 and device[17]==1
print('Native ELF USB bytes: exact 32-byte configuration, 9/9/7/7 descriptor lengths, mandatory power flag, endpoints and UTF-16 language ID passed.')
