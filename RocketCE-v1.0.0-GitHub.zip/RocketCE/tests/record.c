/* Host-only animation recorder. Run from the project directory. */
#include "game.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
int main(void){Game g;char path[100];game_init(&g,0);g.car[0].b.x=-30*Q;render_init();render_reset();for(int i=0;i<420;i++){game_step(&g,bot_input(&g,0,1),bot_input(&g,1,1));if(i%6==0)snprintf(path,sizeof(path),"preview-frames/%03d.svg",i/6);else snprintf(path,sizeof(path),"/dev/null");host_open(path);render_game(&g,0,1,NULL);host_close();}return 0;}
