#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Game start(void){Game g;game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.z=-300*Q;return g;}
static int speed2(const Car *c){int x=c->b.vx/Q,z=c->b.vz/Q;return x*x+z*z;}
int main(void){
 Game coast=start();coast.car[0].b.vz=5*Q;Game brake=coast,reverse=coast,turn=coast;
 for(int n=0;n<30;n++){game_step(&coast,0,0);game_step(&brake,BRAKE,0);game_step(&reverse,DOWN,0);game_step(&turn,RIGHT,0);}
 assert(coast.car[0].b.vz>3*Q);assert(brake.car[0].b.vz<coast.car[0].b.vz/4);assert(reverse.car[0].b.vz<0);
 assert(turn.car[0].angle>0&&turn.car[0].b.x>0&&turn.car[0].b.vx>0);assert(speed2(&turn.car[0])<=25);
 Game slow=start();slow.car[0].b.vz=Q/2;for(int n=0;n<15;n++)game_step(&slow,RIGHT,0);assert(slow.car[0].angle>0);
 Game back=start();back.car[0].b.vz=-3*Q;for(int n=0;n<10;n++)game_step(&back,RIGHT,0);assert(back.car[0].yawVelocity<0);
 Game stopped=start();for(int n=0;n<30;n++)game_step(&stopped,RIGHT,0);assert(stopped.car[0].angle==0);
 Game air=start();air.car[0].b.vx=2*Q;air.car[0].b.vz=4*Q;game_step(&air,JUMP,0);assert(air.car[0].b.vx==2*Q&&air.car[0].b.vz==4*Q);
 air=start();air.car[0].b.y=100*Q;air.car[0].jumps=1;air.car[0].b.vz=3*Q;game_step(&air,JUMP|UP,0);assert(air.car[0].b.vz==9*Q);
 Game slide=start();slide.car[0].b.vx=3*Q;Game grip=slide;game_step(&slide,SLIDE,0);game_step(&grip,0,0);assert(slide.car[0].b.vx>grip.car[0].b.vx);
 /* Identical contact geometry, different approach speeds: harder impact
  * transfers more momentum without a fixed extra shove. */
 Game soft=start();soft.car[0].b.z=0;soft.ball.z=43*Q;soft.car[0].b.vz=Q;Game hard=soft;hard.car[0].b.vz=3*Q;
 game_step(&soft,0,0);game_step(&hard,0,0);assert(soft.ball.vz>0&&hard.ball.vz>soft.ball.vz*2);
 Game drive=start();for(int n=0;n<120;n++)game_step(&drive,UP,0);assert(drive.car[0].b.vz<6*Q&&drive.car[0].b.vz>4*Q);
 puts("Momentum: coasting, braking/reverse, residual-speed steering, reverse steering, takeoff/dodge carry, grip and impact strength passed.");
}
