"""Check the exact packed AppVar payload and bounded ZX7 output, without a CE."""
from pathlib import Path
import struct,json
root=Path(__file__).resolve().parents[1]
def unpack(data):
 pos=0;bits=0;mask=0
 def byte():
  nonlocal pos
  assert pos<len(data);v=data[pos];pos+=1;return v
 def bit():
  nonlocal bits,mask
  if not mask:bits=byte();mask=128
  v=bool(bits&mask);mask>>=1;return v
 out=bytearray([byte()])
 while True:
  if not bit():out.append(byte())
  else:
   n=0
   while not bit():n+=1;assert n<=16
   if n==16:break
   length=1
   for _ in range(n):length=(length<<1)|bit()
   length+=1;offset=byte()
   if offset&128:
    high=0
    for _ in range(4):high=(high<<1)|bit()
    offset=(offset&127)+((high+1)<<7)
   offset+=1
   assert offset<=len(out) and len(out)+length<=76800
   for _ in range(length):out.append(out[-offset])
  assert len(out)<=76800
 return bytes(out)
for name,meta in json.loads((root/'assets/manifest.json').read_text()).items():
 payload=(root/'assets'/f'{name}.dat').read_bytes();packed=payload[8:]
 assert payload[:4]==b'RCE1' and len(payload)==meta['appvar_payload_bytes']
 assert struct.unpack('<HH',payload[4:8])==(len(packed),sum(packed)&65535)
 raw=unpack(packed);assert raw==(root/'assets'/f'{name}.raw').read_bytes() and len(raw)==76800
 assert min(raw)>=64 and max(raw)<192
 var=(root/'dist'/f'{meta["appvar"]}.8xv').read_bytes();assert var[69]&128 and var[74:-2]==payload
 assert struct.unpack('<H',var[-2:])[0]==sum(var[55:-2])&65535
 print(name,': archived AppVar, header/checksum, exact 76800-byte ZX7 round trip and palette bounds passed')
