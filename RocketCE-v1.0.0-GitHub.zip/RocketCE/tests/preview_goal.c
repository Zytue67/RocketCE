#include "game.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
static Game setup(int side){Game g;game_init(&g,0);g.phase=PH_PLAY;g.car[0].b.z=side*(FIELD_Z-100)*Q;g.car[1].b.z=side*(FIELD_Z-80)*Q;g.car[1].b.x=100*Q;g.ball.z=side*(FIELD_Z+BALL_RADIUS-1)*Q;g.ball.vz=side*4*Q;game_step(&g,0,0);return g;}
int main(void){char path[100];render_init();for(int side=-1;side<=1;side+=2){Game g=setup(side);render_reset();for(int age=0;age<GOAL_CELEBRATION;age++){if(age==0||age==8||age==18||age==35){snprintf(path,sizeof(path),"tests/goal-%s-%02d.svg",side>0?"blue":"orange",age);host_open(path);}else host_open("/dev/null");render_game(&g,0,0,NULL);host_close();game_step(&g,0,0);}}return 0;}
