#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
CC=${CC:-cc}
TMPDIR_ROCKET=$(mktemp -d)
trap 'rm -rf "$TMPDIR_ROCKET"' EXIT
FLAGS='-std=c11 -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined -g -Isrc'
export ASAN_OPTIONS=detect_leaks=0
$CC $FLAGS -fshort-wchar -Itests/usb tests/test_link.c -o "$TMPDIR_ROCKET/link"
"$TMPDIR_ROCKET/link"
for side in a b; do
 $CC $FLAGS -Dnet_status=${side}_status -Dnet_sample_input=${side}_sample -Dlink_Status=${side}_link_Status -Dnet_start=${side}_start -Dnet_stop=${side}_stop -Dnet_poll=${side}_poll -Dnet_ready=${side}_ready -Dnet_player=${side}_player -Dnet_input=${side}_input -Dlink_Start=${side}_link_Start -Dlink_Stop=${side}_link_Stop -Dlink_Devices=${side}_link_Devices -Dlink_QueueRead=${side}_link_QueueRead -Dlink_QueueWrite=${side}_link_QueueWrite -c src/net.c -o "$TMPDIR_ROCKET/$side.o"
done
for side in a b; do
 $CC $FLAGS -fshort-wchar -DROCKET_LINK_HOST -Duint24_t=uint32_t -DLINKLIB_KEY='"RocketCE-20"' -Itests/usb -Dlink_Start=${side}_transport_Start -Dlink_Stop=${side}_transport_Stop -Dlink_Devices=${side}_transport_Devices -Dlink_Status=${side}_transport_Status -Dlink_Poll=${side}_transport_Poll -Dlink_QueueRead=${side}_transport_Read -Dlink_QueueWrite=${side}_transport_Write -c src/linklib.c -o "$TMPDIR_ROCKET/usb-$side.o"
done
$CC $FLAGS -fshort-wchar -Itests/usb tests/test_link_game.c src/game.c "$TMPDIR_ROCKET/a.o" "$TMPDIR_ROCKET/b.o" "$TMPDIR_ROCKET/usb-a.o" "$TMPDIR_ROCKET/usb-b.o" -o "$TMPDIR_ROCKET/link-game"
"$TMPDIR_ROCKET/link-game"
$CC $FLAGS tests/test_net.c src/game.c "$TMPDIR_ROCKET/a.o" "$TMPDIR_ROCKET/b.o" -o "$TMPDIR_ROCKET/net"
"$TMPDIR_ROCKET/net"
