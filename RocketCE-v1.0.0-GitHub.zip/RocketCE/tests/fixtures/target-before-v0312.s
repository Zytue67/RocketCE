_target:                                ; @target
; %bb.0:
	call	__frameset0
	ld	bc, (ix + 6)
	ld	de, (_storage+4)
	push	de
	pop	hl
	or	a, a
	sbc	hl, bc
	jr	z, .LBB14_2
; %bb.1:
	sbc	hl, hl
	adc	hl, de
	push	de
	call	nz, _usb_UnrefDevice
	pop	hl
	ld	de, (ix + 6)
	sbc	hl, hl
	adc	hl, de
	or	a, a
	sbc	hl, hl
	push	de
	call	nz, _usb_RefDevice
	pop	de
	ld	(_storage+4), hl
	ld	iy, _storage+12
	ld	hl, (iy)
	inc.sis	hl
	ld	(iy), l
	ld	(iy + 1), h
	.local	.LBB14_2
.LBB14_2:
	pop	ix
	ret
	.local	