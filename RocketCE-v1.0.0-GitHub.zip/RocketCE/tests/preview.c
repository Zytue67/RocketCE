#include "game.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
static void shot(Game *g,int p,int cam,const char *name){char path[128];snprintf(path,sizeof(path),"tests/%s.svg",name);host_open(path);render_init();render_reset();render_game(g,p,cam,NULL);host_close();}
int main(void){Game g;
 game_init(&g,0);host_open("/dev/null");render_init();render_reset();render_game(&g,0,0,NULL);
 for(int z=16;z<4096;z+=7)for(int v=-1800;v<=1800;v+=37)assert(abs(render_test_project(v,z)-v*180/z)<=2);
 g.tick=30;g.car[0].angle=60;render_game(&g,0,0,NULL);assert(render_camera_heading()==60);
 g.tick=60;g.car[0].angle=250;render_game(&g,0,0,NULL);assert(render_camera_heading()==250);
 host_close();
game_init(&g,0);g.phase=PH_PLAY;shot(&g,0,0,"kickoff");g.car[0].b.z=180*Q;g.car[0].b.x=90*Q;g.car[0].angle=249;g.ball.z=330*Q;g.ball.x=10*Q;g.ball.y=50*Q;g.car[1].b.z=440*Q;shot(&g,0,1,"attack");shot(&g,1,0,"orange");g.car[0].b.z=530*Q;g.car[0].b.x=330*Q;g.car[0].angle=24;shot(&g,0,0,"corner");game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.y=100*Q;g.car[0].angle=64;shot(&g,0,0,"air");game_init(&g,1);g.car[0].b.z=0;g.ball.z=-125*Q;g.ball.y=90*Q;shot(&g,0,0,"near-ball");
game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.x=339*Q;g.car[0].b.z=530*Q;g.car[0].angle=160;shot(&g,0,0,"wall-camera");
game_init(&g,1);g.phase=PH_PLAY;g.car[0].b.y=70*Q;g.car[0].pitch=37;g.car[0].roll=28;g.car[0].previous=BOOST;shot(&g,0,0,"aerial-tilt");
 g.car[0].pitch=0;g.car[0].roll=128;shot(&g,0,0,"inverted");
for(int i=0;i<2048;i++){g.car[0].angle=i;g.car[0].pitch=i&255;g.car[0].roll=(i*71)&255;g.car[0].b.x=((i*71)%(FIELD_X*2-40)-FIELD_X+20)*Q;g.car[0].b.z=((i*97)%(FIELD_Z*2-40)-FIELD_Z+20)*Q;g.car[0].b.y=(i%(FIELD_HEIGHT-30))*Q;host_open("/dev/null");render_detail((i/2)%2);render_reset();render_game(&g,0,i%2,NULL);assert(render_camera_x()>=-(FIELD_X-12)&&render_camera_x()<=FIELD_X-12);assert(render_camera_z()>=-(FIELD_Z+GOAL_DEPTH-12)&&render_camera_z()<=FIELD_Z+GOAL_DEPTH-12);host_close();}
return 0;}
