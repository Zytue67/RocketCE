#include "net.h"
#include "linklib.h"
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#define DECL(P) bool P##_start(void);void P##_stop(void);void P##_poll(Game*,uint8_t,uint32_t);bool P##_ready(uint32_t);uint8_t P##_input(uint32_t);int P##_player(void);void P##_sample(uint8_t);net_status_t P##_status(uint32_t);
DECL(a) DECL(b)
typedef struct {uint8_t *read;const uint8_t *write;size_t *rn,*wn,n;uint8_t saved[223];bool on;} Pipe;
static Pipe p[2];static bool plugged=true;
static struct {uint8_t self,count,id;} dev[2]={{0,1,1},{1,1,0}};
static bool start(int i){p[i].on=true;return true;}
static void stop(int i){p[i]=(Pipe){0};}
static const link_devices_t *devices(int i){dev[i].count=plugged&&p[0].on&&p[1].on;return (const link_devices_t*)&dev[i];}
static bool readq(int i,void *data,size_t *n){assert(!p[i].read);p[i].read=data;p[i].rn=n;p[i].n=*n;*n=LINK_PENDING;return true;}
static bool writeq(int i,const void *data,size_t *n){assert(!p[i].write);assert(*n==223);p[i].write=data;p[i].wn=n;memcpy(p[i].saved,data,223);*n=LINK_PENDING;return true;}
#define IMPL(P,I) link_status_t P##_link_Status(void){return (link_status_t){LINK_PEER,I,0,0,0};}bool P##_link_Start(void){return start(I);}void P##_link_Stop(void){stop(I);}const link_devices_t *P##_link_Devices(void){return devices(I);}bool P##_link_QueueRead(uint8_t id,void *b,size_t *n){(void)id;return readq(I,b,n);}bool P##_link_QueueWrite(uint8_t id,const void *b,size_t *n){(void)id;return writeq(I,b,n);}
IMPL(a,0) IMPL(b,1)
static void pump(int corrupt){for(int i=0;i<2;i++){int j=1-i;if(p[i].write&&p[j].read&&plugged){assert(memcmp(p[i].write,p[i].saved,223)==0);memcpy(p[j].read,p[i].write,223);if(corrupt)p[j].read[19]^=1;*p[i].wn=223;*p[j].rn=223;p[i].write=NULL;p[j].read=NULL;}}}
int main(void){Game host,guest;game_init(&host,0);memset(&guest,0,sizeof(guest));assert(a_start()&&b_start());assert(!a_ready(0));a_poll(&host,UP,1100);b_poll(&guest,BOOST,1100);pump(0);a_poll(&host,UP,2200);b_poll(&guest,BOOST,2200);assert(!a_ready(2200)&&!b_ready(2200));pump(0);for(uint32_t t=3300;t<11000;t+=1100){a_poll(&host,UP,t);b_poll(&guest,BOOST,t);pump(0);}a_poll(&host,UP,11000);b_poll(&guest,BOOST,11000);assert(a_ready(11000)&&b_ready(11000));assert(a_player()==0&&b_player()==1);assert(a_input(11000)==BOOST);assert(guest.remaining==host.remaining);
 host.phase=PH_GOAL;host.phaseTicks=58;host.blastMask=3;host.car[1].botEscape=33;host.car[1].botIdle=7;host.car[0].b.vy=6*Q;host.car[1].pitch=27;
 for(uint32_t t=12100;t<22000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}a_poll(&host,0,22000);b_poll(&guest,0,22000);
 assert(guest.phase==PH_GOAL&&guest.phaseTicks==58&&guest.blastMask==3&&guest.car[0].b.vy==6*Q&&guest.car[1].pitch==27&&guest.car[1].botEscape==33&&guest.car[1].botIdle==7);
 host.score[0]=5;host.phase=PH_END;host.car[0].pitch=37;host.car[1].roll=123;host.car[1].dodgeTicks=9;host.car[0].flipUnlimited=1;for(uint32_t t=23100;t<33000;t+=1100){a_poll(&host,0,t);b_poll(&guest,JUMP,t);pump(0);}a_poll(&host,0,33000);b_poll(&guest,JUMP,33000);assert(guest.score[0]==5&&guest.phase==PH_END);assert(a_input(33000)&JUMP);assert(guest.car[0].pitch==37&&guest.car[1].roll==123&&guest.car[1].dodgeTicks==9&&guest.car[0].flipUnlimited==1);
 game_init(&host,0);for(uint32_t t=34100;t<43000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}a_poll(&host,0,43000);b_poll(&guest,0,43000);assert(guest.phase==PH_KICKOFF&&guest.score[0]==0&&guest.remaining==180*HZ);
 assert(!a_ready(111000));assert(a_input(111000)==0);pump(0);for(uint32_t t=112100;t<121000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}a_poll(&host,0,121000);b_poll(&guest,0,121000);assert(a_ready(121000));
 host.score[0]=9;for(uint32_t t=122100;t<131000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(1);}b_poll(&guest,0,131000);assert(guest.score[0]==0);plugged=false;a_poll(&host,0,131000);b_poll(&guest,0,131000);assert(!a_ready(131000)&&!b_ready(131000));a_stop();b_stop();assert(!a_ready(131000));/* Restarted peers must not get stuck behind the old sequence number. */
 plugged=true;game_init(&host,0);game_init(&guest,0);assert(a_start()&&b_start());
 for(uint32_t t=200000;t<211000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}
 a_poll(&host,0,211000);b_poll(&guest,0,211000);pump(0);
 /* A complete tap between packet sends survives via its edge counter. */
 b_sample(JUMP|LEFT|BOOST);b_sample(0);host.car[1].previous=JUMP;
 b_poll(&guest,0,212100);pump(0);a_poll(&host,0,213200);pump(0);a_poll(&host,0,214300);
 assert(a_input(214300)==(JUMP|LEFT|BOOST));assert(!(host.car[1].previous&JUMP));assert(!(a_input(214300)&JUMP));
 b_stop();assert(b_start());
 for(uint32_t t=215400;t<227000;t+=1100){a_poll(&host,0,t);b_poll(&guest,BOOST|RIGHT,t);pump(0);}
 a_poll(&host,0,227000);b_poll(&guest,BOOST|RIGHT,227000);assert(a_ready(227000)&&b_ready(227000));assert(a_input(227000)==(BOOST|RIGHT));
 /* Run authoritative gameplay while shipping snapshots and player inputs. */
 host.phase=PH_PLAY;host.phaseTicks=0;
 for(uint32_t i=0,t=228100;i<900;i++,t+=1092){
  uint8_t guestKeys=UP|((i%120<50)?RIGHT:LEFT)|((i%90<20)?BOOST:0)|((i%80==0)?JUMP:0);
  b_poll(&guest,guestKeys,t);a_poll(&host,UP|((i%100<30)?LEFT:0),t);pump(0);
  if(a_ready(t))game_step(&host,UP|((i%100<30)?LEFT:0),a_input(t));
 }
 for(uint32_t t=1211000;t<1222000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}
 a_poll(&host,0,1222000);b_poll(&guest,0,1222000);assert(memcmp(&host,&guest,sizeof(host))==0);assert(host.tick>500);
 a_stop();b_stop();
 /* A same-role peer must never start a match. */
 game_init(&host,0);game_init(&guest,0);dev[1].self=0;assert(a_start()&&b_start());
 for(uint32_t t=1300000;t<1311000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}
 assert(!a_ready(1311000)&&!b_ready(1311000));assert(a_status(1311000).roleConflict&&b_status(1311000).roleConflict);
 dev[1].self=1;
 for(uint32_t t=1312100;t<1325000;t+=1100){a_poll(&host,0,t);b_poll(&guest,0,t);pump(0);}
 assert(a_ready(1325000)&&b_ready(1325000)&&a_player()==0&&b_player()==1);
 a_stop();b_stop();
  puts("USB protocol: snapshots, quick jump taps, peer restart, 900 gameplay ticks, CRC, timeout, ownership and disconnect checks passed (mock transport).");}
