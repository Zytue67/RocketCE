#include "game.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static void check(uint32_t n){uint64_t r=root32(n);assert(r*r<=n&&(r+1)*(r+1)>n);}
int main(void){uint32_t n=1;for(unsigned i=0;i<50000;i++){n=n*1664525UL+1013904223UL;check(n);check(n&0xffffffUL);}for(uint32_t i=1;i<65536;i+=31){check(i*i-1);check(i*i);check(i*i+1);}check(0);check(0xffffffUL);check(0x1000000UL);check(UINT32_MAX);puts("Integer square roots: exact floor bounds, native-width cutoff and full uint32 range passed.");}
