/* Host-only opening/title animation preview; not calculator timing evidence. */
#include "ui.h"
#include "render.h"
#include "graphx.h"
#include <stdio.h>
int main(void){char p[100];render_init();ui_init();for(unsigned i=0;i<48;i++){snprintf(p,sizeof(p),"preview-frames/ui/%03u.svg",i);host_open(p);ui_title(i*2);host_close();}return 0;}
