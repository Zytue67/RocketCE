controls.png: v0.3.7 single-page controls, rendered at 320 x 240 with the host graphics adapter. Previews do not represent calculator FPS.

link-wait.png and link-sync.png: v0.3.8 USB waiting/synchronization screen. Host-rendered appearance previews, not physical USB or performance tests.

Version 0.3.9 updates link-wait.png and link-sync.png and adds link-init-error.png with readable operation/error diagnostics. These are software-rendered previews.

v0.3.10 link screenshots include separate queued, completed, raw and accepted packet counters.

v0.3.11 link screens add an enumeration attempt counter to the operation row.
