Host appearance previews for v0.3.6, with radius-24 ball and updated goal/bot behavior. Goal-explosion.gif and Gameplay.gif are host animations, not calculator timing measurements.
