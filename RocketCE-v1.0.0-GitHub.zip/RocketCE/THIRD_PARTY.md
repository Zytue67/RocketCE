# Attribution and source

RocketCE's gameplay, renderer, meshes, tests, and UI were authored for this project with AI coding assistance. No Rocket League game files, logos, sounds, or extracted assets are included.

The calculator-to-calculator adapter in src/linklib.c and src/linklib.h is derived from the CE-Programming toolchain's link_library example. Changes include explicit initialization/shutdown, a fixed application key, allocation failure handling, and endpoint checks. Original source and history:
https://github.com/CE-Programming/toolchain/tree/master/examples/library_examples/usbdrvce/link_library

The program dynamically uses graphx, keypadc, usbdrvce, and the CE library loader from CE-Programming. The unmodified v15.0 runtime group is included for installation convenience. CE library source, copyright notices, licensing, and build instructions are available in the upstream toolchain repository:
https://github.com/CE-Programming/toolchain/tree/v15.0
https://github.com/CE-Programming/toolchain/tree/master/license

Runtime distribution:
https://github.com/CE-Programming/libraries/releases/tag/v15.0

GNU GPL v3 and LGPL v3 texts are included under licenses/ for reference; upstream component-specific license notices govern third-party components. All RocketCE source is supplied so users can rebuild and modify this release.

The menu wordmark uses bundled Nimbus Sans Bold Italic from URW Base35. Its copyright and licensing notice is included at assets/wordmark-font-license.txt.
