# Reference artwork — v0.3.12

`title-source.png` is the user's supplied logo screenshot. `menu-source.png` is a clean showroom backdrop produced with the built-in image-generation tool, using the supplied menu screenshot as its reference. The title preserves the supplied image; this remains the independent RocketCE project.

The latest replacement uses `car-reference.png`, the user's red hatchback reference. The built-in image tool edited the previous showroom backdrop with this prompt:

> Replace the yellow/green/black car in the existing clean showroom scene with the red boxier hatchback from the new reference. Preserve the glossy red angular hood, squared hatchback cabin, black windows, big silver-gray wheel arch flares and lower trim, black wheels, icy blue circular headlights and small rear spoiler. No antenna flag. Keep the stadium, grass and lighting composition and empty left 40% for menu text. Place the car on the right 60%, three-quarter front view facing lower left, about the previous car's size, with wheels and bumper inside the frame. No text, logos, badges, HUD or buttons. Clear silhouette for downscaling to 320x240; landscape 4:3.

`build_assets.py` resizes the assets, bakes the menu's dark strips, reduces both to a shared 128-color palette, and produces compressed archived AppVars plus the native palette/size/checksum include. `title.png` and `menu.png` are the actual calculator-resolution backgrounds. Menu text and the selected row are drawn by ui.c.

Install `dist/RCETITLE.8xv` and `dist/RCEMENU.8xv` alongside the program. Keep them archived. To reproduce assets, install Pillow and run the script from any directory; CEdev convbin must be present at the toolchain path used by this project. Then rebuild the program with make clean / make.

## v0.3.12 layout

The supplied title image is resized directly to 320 × 240 for edge-to-edge coverage. The attempted generative expansion did not produce an asset. The new menu wordmark is rendered at build time with the bundled Nimbus Sans Bold Italic font (`wordmark.otf`); see `wordmark-font-license.txt`. It has a dark outline, white ROCKET, cyan CE and a cyan/orange underline. Runtime ticker text replaces the old footer instructions.
