#ifndef LINKLIB_H
#define LINKLIB_H

#include <limits.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define LINK_PENDING SIZE_MAX

typedef struct link_devices {
    uint8_t self, count, ids[];
} link_devices_t;

enum {LINK_OFF,LINK_WAIT,LINK_ENUMERATE,LINK_CHECK,LINK_PEER,LINK_MISMATCH,LINK_ERROR};
enum {LINK_INIT,LINK_RESET,LINK_ID,LINK_CONFIG,LINK_EVENTS,LINK_READ,LINK_WRITE};
typedef struct {uint8_t stage,guest;int error;uint8_t step;uint16_t attempts;} link_status_t;
link_status_t link_Status(void);
bool link_Start(void);
void link_Stop(void);
const link_devices_t *link_Devices(void);

bool link_QueueRead(uint8_t id, void *buffer, size_t *length);

bool link_QueueWrite(uint8_t id, const void *buffer, size_t *length);

bool link_Poll(void);

#ifdef __cplusplus
}
#endif

#endif
