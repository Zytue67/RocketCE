#include "net.h"
#include "linklib.h"
#include <string.h>
/* Fixed-size messages below 4 USB packets; padding initialized before CRC.
 * Never mutate buffers or length variables while USB owns them. Both CE
 * peers must run this same protocol/build (raw Game layout is CE specific). */
#define N 223
/* Receive a multiple of the 64-byte USB packet size; 223-byte frames
 * terminate with a short packet. Transmit framing stays unchanged. */
#define RX_CAPACITY 256
static uint8_t rx[RX_CAPACITY],tx[N],remote,jumpLatch,sampled,jumpSerial,remoteJump,jumpKeys;
static uint16_t sessionCounter,session,remoteSession;
static uint32_t sent,received,rawReceived,completedSent,rejected;
static unsigned lastRead;
static bool txOutstanding;
static size_t rn,tn;
static uint32_t lastRx,lastTx,sequence,remoteSequence;
static int player;
static bool seen,connected,started,acknowledged,roleConflict;
_Static_assert(sizeof(Game)<=N-14,"Game exceeds USB packet");
static uint16_t crc(const uint8_t *b){uint16_t c=0xffff;for(int i=0;i<N-2;i++){c^=(uint16_t)b[i]<<8;for(int j=0;j<8;j++)c=(c&0x8000)?(c<<1)^0x1021:c<<1;}return c;}
static void put32(uint8_t *p,uint32_t v){for(int i=0;i<4;i++){p[i]=v;v>>=8;}}
static uint32_t get32(const uint8_t *p){uint32_t v=0;for(int i=3;i>=0;i--)v=(v<<8)|p[i];return v;}
bool net_start(void){net_stop();rn=tn=0;player=-1;seen=connected=acknowledged=roleConflict=false;lastRx=lastTx=sequence=remoteSequence=0;remote=jumpLatch=sampled=jumpSerial=remoteJump=jumpKeys=0;remoteSession=0;session=++sessionCounter;if(!session)session=++sessionCounter;sent=received=rawReceived=completedSent=rejected=0;lastRead=0;txOutstanding=false;started=link_Start();return started;}
void net_stop(void){link_Stop();started=false;seen=connected=acknowledged=roleConflict=false;player=-1;rn=tn=0;}
int net_player(void){return player;}
bool net_ready(uint32_t now){return started&&connected&&seen&&acknowledged&&!roleConflict&&(uint32_t)(now-lastRx)<65536;}
uint8_t net_input(uint32_t now){if((uint32_t)(now-lastRx)>=10923)jumpLatch=0;uint8_t v=(uint32_t)(now-lastRx)<10923?remote:0;if(jumpLatch)v=jumpLatch;jumpLatch=0;return v;}
void net_sample_input(uint8_t input){if((input&JUMP)&&!(sampled&JUMP)){jumpSerial++;jumpKeys=input;}sampled=input;}
net_status_t net_status(uint32_t now){net_status_t s={0};s.usb=link_Status();s.sent=sent;s.received=received;s.synced=net_ready(now);s.roleConflict=roleConflict;s.rawReceived=rawReceived;s.completedSent=completedSent;s.rejected=rejected;s.lastRead=lastRead;return s;}
void net_poll(Game *g,uint8_t input,uint32_t now){net_sample_input(input);if(!started)return;const link_devices_t *d=link_Devices();connected=d->count!=0;if(!connected){seen=acknowledged=roleConflict=false;player=-1;remote=jumpLatch=0;remoteSession=0;return;}player=d->self?1:0;
 if(tn!=LINK_PENDING&&txOutstanding){if(tn==N)completedSent++;txOutstanding=false;}
 if(rn!=LINK_PENDING){uint32_t before=received;if(rn){rawReceived++;lastRead=rn;}if(rn==N&&rx[0]=='R'&&rx[1]=='C'&&rx[2]==20){uint16_t check=crc(rx);uint32_t seq=get32(rx+4);uint16_t peer=(uint16_t)rx[N-4]|(uint16_t)rx[N-3]<<8;if(rx[N-2]==(uint8_t)check&&rx[N-1]==(uint8_t)(check>>8)&&(peer!=remoteSession||!seen||seq>remoteSequence)){if(rx[3]==player){roleConflict=true;acknowledged=false;}else if(rx[3]==(player?0:1)){
 roleConflict=false;if(remoteSession!=peer)remoteJump=0;remoteSession=peer;remoteSequence=seq;seen=true;
 acknowledged=((uint16_t)rx[N-6]|(uint16_t)rx[N-5]<<8)==session;
 lastRx=now;received++;if(player)memcpy(g,rx+8,sizeof(*g));else{if(rx[9]!=remoteJump){jumpLatch=rx[10]|JUMP;g->car[1].previous&=~JUMP;}remoteJump=rx[9];remote=rx[8];}
 }}}if(rn&&received==before)rejected++;rn=RX_CAPACITY;link_QueueRead(d->ids[0],rx,&rn);}
 if(tn!=LINK_PENDING&&(uint32_t)(now-lastTx)>=1092){memset(tx,0,N);tx[0]='R';tx[1]='C';tx[2]=20;tx[3]=player;put32(tx+4,++sequence);if(player){tx[8]=input;tx[9]=jumpSerial;tx[10]=jumpKeys;}else memcpy(tx+8,g,sizeof(*g));tx[N-6]=remoteSession;tx[N-5]=remoteSession>>8;tx[N-4]=session;tx[N-3]=session>>8;uint16_t c=crc(tx);tx[N-2]=c;tx[N-1]=c>>8;tn=N;if(link_QueueWrite(d->ids[0],tx,&tn)){sent++;txOutstanding=true;}lastTx=now;}}
