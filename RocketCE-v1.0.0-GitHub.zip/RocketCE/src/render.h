#ifndef RENDER_H
#define RENDER_H
#include "game.h"
void render_init(void);
void render_set_poll(void (*callback)(void));
void render_detail(int detail);
void render_fps(unsigned fps);
void render_cost(unsigned draw,unsigned sim);
void render_reset(void);
#ifdef ROCKET_RENDER_TEST
unsigned render_camera_heading(void);
int render_test_project(int value,int depth);
int render_camera_x(void);
int render_camera_z(void);
#endif
void render_game(const Game *g,int player,int ballcam,const char *status);
void screen_message(const char *title,const char *sub,const char *foot);
#endif
