#include <graphx.h>
#include <keypadc.h>
#include <sys/timers.h>
#include <stdbool.h>
#include "game.h"
#include "render.h"
#include "net.h"
#include "controls.h"
#include "ui.h"
#include "linklib.h"
static Game game;
static bool linkActive;
static uint8_t input(void){uint8_t v=0;if(kb_IsDown(kb_KeyUp))v|=UP;if(kb_IsDown(kb_KeyDown))v|=DOWN;if(kb_IsDown(kb_KeyLeft))v|=LEFT;if(kb_IsDown(kb_KeyRight))v|=RIGHT;if(kb_IsDown(kb_Key2nd))v|=JUMP;if(kb_IsDown(kb_KeyAlpha))v|=BOOST;if(kb_IsDown(kb_KeyGraph))v|=BRAKE;if(kb_IsDown(kb_KeyMode))v|=SLIDE;return v;}
static ControlTimeline timeline;
static uint32_t lastInputPoll;static bool quitPending,cameraPending,detailPending,traceHeld,zoomHeld;
/* Sampling while drawing preserves short presses without running physics in
 * the middle of a frame. Events are consumed at their fixed-step timestamps. */
static void poll_controls(void){
 uint32_t now=timer_Get(1);if((uint32_t)(now-lastInputPoll)<262)return;lastInputPoll=now;
 if(linkActive)link_Poll();
 kb_Scan();uint8_t sampled=input();controls_sample(&timeline,now,sampled);if(linkActive)net_sample_input(sampled);if(kb_IsDown(kb_KeyClear))quitPending=true;
 bool trace=kb_IsDown(kb_KeyTrace),zoom=kb_IsDown(kb_KeyZoom);
 if(trace&&!traceHeld)cameraPending=!cameraPending;if(zoom&&!zoomHeld)detailPending=!detailPending;
 traceHeld=trace;zoomHeld=zoom;
}
static void release(void){do {if(linkActive)link_Poll();kb_Scan();delay(10);}while(kb_AnyKey());}
static void help(void){ui_controls();release();while(1){kb_Scan();if(kb_IsDown(kb_KeyEnter)||kb_IsDown(kb_KeyClear))break;delay(10);}release();}
static void match(int mode){bool linked=mode==2;int camera=0,resultChoice=0;bool wasEnter=false,wasUp=false,wasDown=false,detail=false;uint32_t resultStart=0;bool resultOpen=false;render_detail(0);game_init(&game,mode==1);render_reset();if(linked)net_start();
 linkActive=linked;release();uint32_t previous=timer_Get(1),acc=0,lastFrame=previous,fpsStart=previous,simTime=previous;
 unsigned frames=0,drawMs=0;controls_init(&timeline,0);lastInputPoll=previous-262;
 quitPending=cameraPending=detailPending=traceHeld=zoomHeld=false;render_set_poll(poll_controls);
 while(1){poll_controls();if(quitPending)break;
 uint32_t now=timer_Get(1),elapsed=now-previous;previous=now;uint8_t keys=timeline.last;
 bool enter=kb_IsDown(kb_KeyEnter);
 if(cameraPending){camera=!camera;cameraPending=false;}if(detailPending){detail=!detail;render_detail(detail);detailPending=false;}
 if(linked&&enter&&!wasEnter&&!net_ready(now))net_start();
 if(linked)net_poll(&game,keys,now);int player=linked?net_player():0;bool ready=!linked||net_ready(now);
 if(ready&&(!linked||!player)){
  acc+=elapsed;
  while(acc>=1092){simTime+=1092;int released;uint8_t timed=controls_step(&timeline,simTime,&released);
   if(released)game.car[0].previous&=~JUMP;
   game_step(&game,timed,linked?net_input(now):(game.phase==PH_PLAY&&!game.freeplay?bot_input(&game,1,1):0));acc-=1092;
  }
 }else {acc=0;simTime=now;int released;controls_step(&timeline,now,&released);}
 if(game.phase==PH_END){
  if(!resultOpen){resultOpen=true;resultStart=now;resultChoice=0;wasEnter=enter;wasUp=kb_IsDown(kb_KeyUp);wasDown=kb_IsDown(kb_KeyDown);}
  bool up=kb_IsDown(kb_KeyUp),down=kb_IsDown(kb_KeyDown);
  if((up&&!wasUp)||(down&&!wasDown))resultChoice^=1;
  if(enter&&!wasEnter){
   if(resultChoice)break;
   if(!linked||!player){game_init(&game,0);render_reset();acc=0;simTime=now;resultOpen=false;frames=0;fpsStart=now;drawMs=0;}
  }
  wasUp=up;wasDown=down;
 }else {if(resultOpen){render_reset();frames=0;fpsStart=now;drawMs=0;}resultOpen=false;wasUp=wasDown=false;}
 wasEnter=enter;
 if((uint32_t)(now-lastFrame)>=(linked&&!ready?8192:1092)){uint32_t drawStart=timer_Get(1);render_cost(drawMs,(drawStart-now)*1000/32768);if(game.phase==PH_END){ui_result(&game,player,linked,resultChoice,(now-resultStart)/3276);}else if(linked&&!ready){ui_link(net_status(now),now/8192);}else render_game(&game,player,camera,linked?(player?"YOU: ORANGE  |  BLUE HOSTS":"YOU: BLUE  |  HOST"):NULL);lastFrame=now;frames++;uint32_t end=timer_Get(1);drawMs=(end-drawStart)*1000/32768;if(end-fpsStart>=32768){render_fps((uint32_t)frames*327680/(end-fpsStart));frames=0;fpsStart=end;}}
 }
 render_set_poll(NULL);linkActive=false;if(linked)net_stop();release();}
/* Opening and menu screens redraw at 10 Hz, independent of match rendering. */
static bool opening(void){uint32_t start=timer_Get(1),last=start-1638;
 while(1){kb_Scan();if(kb_IsDown(kb_KeyClear))return false;if(kb_IsDown(kb_KeyEnter)){release();return true;}uint32_t now=timer_Get(1);if((uint32_t)(now-last)>=1638){ui_title((now-start)/1638);last=now;}delay(5);}
}
int main(void){gfx_Begin();gfx_SetDrawBuffer();render_init();ui_init();timer_Disable(1);timer_Set(1,0);timer_Enable(1,TIMER_32K,TIMER_NOINT,TIMER_UP);
 if(opening()){unsigned selected=0;bool dirty=true,heldUp=false,heldDown=false;uint32_t menuStart=timer_Get(1),lastTicker=menuStart;
  while(1){uint32_t now=timer_Get(1);if(dirty){ui_menu(selected);dirty=false;lastTicker=now;}else if((uint32_t)(now-lastTicker)>=1638){ui_menu_tick(now-menuStart);lastTicker=now;}kb_Scan();if(kb_IsDown(kb_KeyClear))break;
   bool up=kb_IsDown(kb_KeyUp),down=kb_IsDown(kb_KeyDown);if(up&&!heldUp){selected=(selected+4)%5;dirty=true;}if(down&&!heldDown){selected=(selected+1)%5;dirty=true;}heldUp=up;heldDown=down;
   int action=-1;if(kb_IsDown(kb_Key1))action=0;else if(kb_IsDown(kb_Key2))action=1;else if(kb_IsDown(kb_Key3))action=2;else if(kb_IsDown(kb_Key4))action=3;else if(kb_IsDown(kb_KeyEnter))action=selected;
   if(action>=0){release();if(action==4)break;if(action==3)help();else match(action);dirty=true;heldUp=heldDown=false;}delay(10);
  }
 }
 timer_Disable(1);gfx_End();return 0;}
