#include "controls.h"
#include "game.h"
#include <string.h>
void controls_init(ControlTimeline *t,uint8_t keys){memset(t,0,sizeof(*t));t->held=t->last=keys;}
void controls_sample(ControlTimeline *t,uint32_t time,uint8_t keys){
 if(keys==t->last)return;t->last=keys;
 if(t->count==CONTROL_SAMPLES){t->held=t->samples[t->head].keys;t->head=(t->head+1)%CONTROL_SAMPLES;t->count--;}
 unsigned pos=(t->head+t->count)%CONTROL_SAMPLES;t->samples[pos]=(ControlSample){time,keys};t->count++;
}
uint8_t controls_step(ControlTimeline *t,uint32_t until,int *released){
 int jump=0;uint8_t jumpKeys=0;*released=0;
 while(t->count&&(int32_t)(until-t->samples[t->head].time)>=0){
  uint8_t keys=t->samples[t->head].keys;
  if((keys&JUMP)&&!(t->held&JUMP)){jump=1;jumpKeys=keys;}
  if(!(keys&JUMP)&&(t->held&JUMP))*released=1;
  t->held=keys;t->head=(t->head+1)%CONTROL_SAMPLES;t->count--;
 }
 if(jump)return (t->held&~(UP|DOWN|LEFT|RIGHT|JUMP))|(jumpKeys&(UP|DOWN|LEFT|RIGHT|JUMP));
 return t->held;
}
