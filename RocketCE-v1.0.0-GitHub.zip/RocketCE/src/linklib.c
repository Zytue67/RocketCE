#include "linklib.h"

#include <stdlib.h>
#include <string.h>
#include <time.h>

#define usb_transfer_data_t size_t
#include <usbdrvce.h>

#define DEFAULT_LANGID 0x0409
#ifndef ROCKET_LINK_HOST
_Static_assert(sizeof(wchar_t)==2,"USB strings require UTF-16");
_Static_assert(sizeof(usb_device_descriptor_t)==18,"USB device descriptor layout");
_Static_assert(sizeof(usb_interface_descriptor_t)==9,"USB interface layout");
#endif

#ifndef LINKLIB_KEY
# warning Please add -DLINKLIB_KEY="\"<unique string>\"" to the makefile CFLAGS
# define LINKLIB_KEY "LinkLib program compiled on " __DATE__ " at " __TIME__
#endif

/* These public USB header types have tail padding with this CEdev ABI.
 * Never serialize sizeof(usb_configuration_descriptor_t) / endpoint_t. */
typedef struct __attribute__((packed)) {
 uint8_t bLength,bDescriptorType;uint16_t wTotalLength;
 uint8_t bNumInterfaces,bConfigurationValue,iConfiguration,bmAttributes,bMaxPower;
} wire_configuration_t;
typedef struct __attribute__((packed)) {
 uint8_t bLength,bDescriptorType,bEndpointAddress,bmAttributes;
 uint16_t wMaxPacketSize;uint8_t bInterval;
} wire_endpoint_t;
_Static_assert(sizeof(wire_configuration_t)==9,"USB wire configuration must be 9 bytes");
_Static_assert(sizeof(wire_endpoint_t)==7,"USB wire endpoint must be 7 bytes");
/* The game owns timer 1 at 32768 Hz. Keep enumeration scheduling off
 * usbdrvce's timer-2/cycle-counter ABI and make it independently testable. */
#ifdef ROCKET_LINK_HOST
extern uint32_t link_test_clock(void);
#define link_now link_test_clock
#else
static uint32_t link_now(void){return (uint32_t)clock();}
#endif
#define LINK_RETRY_TICKS 32768UL
/* Reset returns before descriptor/address enumeration completes. Leave the
 * peer time to enter USB mode before resetting the port again. */
#define LINK_ENUMERATION_TICKS (5UL*LINK_RETRY_TICKS)
/* A single peer; never relocate memory while USB owns transfer callbacks. */
static struct state {
 uint8_t pending;
 struct {uint8_t self,count,ids[1];} devices;
 usb_device_t target;
 uint32_t due;
 uint16_t generation;
 uint8_t action;
 bool enumerating;
} storage,*state;
static link_status_t status;
link_status_t link_Status(void){return status;}
static const usb_string_descriptor_t key={
 .bLength=sizeof(L"" LINKLIB_KEY),.bDescriptorType=USB_STRING_DESCRIPTOR,.bString=L"" LINKLIB_KEY,
};
static void target(usb_device_t device){
 if(state->target==device)return;
 /* Pin the argument directly. Avoid a conditional call result here: the
  * CE backend emitted flag-clobbering zero setup and stored NULL for the
  * old device ? usb_RefDevice(device) : NULL expression. USB ref/unref
  * explicitly tolerate NULL, so both calls can be unconditional. */
 usb_RefDevice(device);
 usb_UnrefDevice(state->target);
 state->target=device;state->generation++;
}
static void fail(usb_error_t error,uint8_t step){status.error=error;status.step=step;status.stage=LINK_ERROR;}
static usb_error_t set_configuration(usb_device_t device){
 size_t length=usb_GetConfigurationDescriptorTotalLength(device,0),transferred=0;
 if(length<9||length>256)return USB_ERROR_FAILED;
 usb_configuration_descriptor_t *descriptor=malloc(length);
 if(!descriptor)return USB_ERROR_NO_MEMORY;
 usb_error_t error=usb_GetConfigurationDescriptor(device,0,descriptor,length,&transferred);
 if(error==USB_SUCCESS && transferred!=length)error=USB_ERROR_FAILED;
 if(error==USB_SUCCESS)error=usb_SetConfiguration(device,descriptor,transferred);
 free(descriptor);return error;
}
static usb_device_t find_device(uint8_t address){
 usb_device_t device=NULL;
 while((device=usb_FindDevice(NULL,device,USB_SKIP_HUBS|USB_SKIP_DISABLED)))
  if(usb_GetDeviceAddress(device)==address&&usb_GetDeviceData(device))return device;
 return NULL;
}
static usb_error_t transfer_handler(usb_endpoint_t endpoint,usb_transfer_status_t result,size_t transferred,size_t *data){
 (void)endpoint;*data=result==USB_TRANSFER_COMPLETED?transferred:0;
 if(state&&state->pending)state->pending--;
 return USB_SUCCESS;
}
static bool queue(uint8_t address,bool direction,void *buffer,size_t *length){
 if(!state){*length=0;return false;}
 /* Device FIFOs are selected by endpoint NUMBER, so IN/OUT must
  * not share number 1 when both transfers are outstanding. */
 bool in=((usb_GetRole()&USB_ROLE_DEVICE)!=0)^direction;
 uint8_t endpoint=in?(USB_DEVICE_TO_HOST|2):(USB_HOST_TO_DEVICE|1);
 size_t size=*length;*length=LINK_PENDING;
 usb_device_t device=find_device(address);
 usb_endpoint_t pipe=device?usb_GetDeviceEndpoint(device,endpoint):NULL;
 usb_error_t error=pipe?usb_ScheduleBulkTransfer(pipe,buffer,size,transfer_handler,length):USB_ERROR_NO_DEVICE;
 if(error!=USB_SUCCESS){*length=0;fail(error,direction?LINK_READ:LINK_WRITE);return false;}
 state->pending++;return true;
}
/* Callbacks only record work. Descriptor/configuration transfers run after
 * usb_HandleEvents returns, avoiding nested application handshakes. */
static usb_error_t event_handler(usb_event_t event,void *data,void *unused){
 (void)unused;if(!state)return USB_SUCCESS;
 switch(event){
 case USB_ROLE_CHANGED_EVENT:
  state->devices.self=(*(usb_role_t *)data&USB_ROLE_DEVICE)!=0;
  status.guest=state->devices.self;status.stage=LINK_WAIT;
  if(state->devices.self){state->action=0;target(NULL);}
  {usb_device_t peer=NULL;while((peer=usb_FindDevice(NULL,peer,USB_SKIP_HUBS|USB_SKIP_DISABLED)))usb_SetDeviceData(peer,NULL);}
  break;
 case USB_DEVICE_CONNECTED_EVENT:
  status.stage=LINK_ENUMERATE;
  target(data);state->action=1;state->due=link_now();break;
 case USB_DEVICE_ENABLED_EVENT:
  if(!(usb_GetRole()&USB_ROLE_DEVICE)){state->enumerating=false;target(data);state->action=2;state->due=link_now();}break;
 case USB_DEVICE_DISCONNECTED_EVENT:
  usb_SetDeviceData(data,NULL);status.stage=LINK_WAIT;
  if(state->target==data){target(NULL);state->action=0;}break;
 case USB_DEVICE_DISABLED_EVENT:
  usb_SetDeviceData(data,NULL);status.stage=LINK_WAIT;
  if(state->target==data){state->generation++;state->action=1;state->due=link_now()+(state->enumerating?LINK_ENUMERATION_TICKS:LINK_RETRY_TICKS);}break;
 case USB_HOST_CONFIGURE_EVENT:
  if(usb_GetRole()&USB_ROLE_DEVICE){
   const usb_configuration_descriptor_t *config=data;
   usb_device_t host=usb_FindDevice(NULL,NULL,USB_SKIP_HUBS|USB_SKIP_DISABLED);
   if(host&&config&&config->bConfigurationValue==1){usb_SetDeviceData(host,&storage);status.stage=LINK_PEER;status.error=0;}
   else if(host)usb_SetDeviceData(host,NULL);
  }break;
 default:break;
 }
 return USB_SUCCESS;
}
void link_Stop(void){
 if(state){usb_Cleanup();target(NULL);state=NULL;}
 status.stage=LINK_OFF;
}
bool link_Start(void) {
    static const usb_string_descriptor_t *strings[] = { &key };
    static const usb_string_descriptor_t langids = {
        .bLength = 2 + sizeof(uint16_t),
        .bDescriptorType = USB_STRING_DESCRIPTOR,
        .bString = {
            [0] = DEFAULT_LANGID,
        },
    };
    static struct __attribute__((packed,aligned(2))) {
        wire_configuration_t configuration;
        struct {
            usb_interface_descriptor_t interface;
            wire_endpoint_t endpoints[2];
        } interface0;
    } configuration1 = {
        .configuration = {
            .bLength = sizeof(configuration1.configuration),
            .bDescriptorType = USB_CONFIGURATION_DESCRIPTOR,
            .wTotalLength = sizeof(configuration1),
            .bNumInterfaces = 1,
            .bConfigurationValue = 1,
            .iConfiguration = 0,
            .bmAttributes = 0x80 | USB_BUS_POWERED | USB_NO_REMOTE_WAKEUP,
            .bMaxPower = 500 / 2,
        },
        .interface0 = {
            .interface = {
                .bLength = sizeof(configuration1.interface0.interface),
                .bDescriptorType = USB_INTERFACE_DESCRIPTOR,
                .bInterfaceNumber = 0,
                .bAlternateSetting = 0,
                .bNumEndpoints = sizeof(configuration1.interface0.endpoints) /
                                 sizeof(*configuration1.interface0.endpoints),
                .bInterfaceClass = USB_VENDOR_SPECIFIC_CLASS,
                .bInterfaceSubClass = 0,
                .bInterfaceProtocol = 0,
                .iInterface = 0,
            },
            .endpoints = {
                [0] = {
                    .bLength = sizeof(configuration1.interface0.endpoints[0]),
                    .bDescriptorType = USB_ENDPOINT_DESCRIPTOR,
                    .bEndpointAddress = USB_HOST_TO_DEVICE | 1,
                    .bmAttributes = USB_BULK_TRANSFER,
                    .wMaxPacketSize = 0x40,
                    .bInterval = 0,
                },
                [1] = {
                    .bLength = sizeof(configuration1.interface0.endpoints[1]),
                    .bDescriptorType = USB_ENDPOINT_DESCRIPTOR,
                    .bEndpointAddress = USB_DEVICE_TO_HOST | 2,
                    .bmAttributes = USB_BULK_TRANSFER,
                    .wMaxPacketSize = 0x40,
                    .bInterval = 0,
                },
            },
        },
    };
    _Static_assert(sizeof(configuration1)==32,"USB configuration tree must be 32 bytes");
    static const usb_configuration_descriptor_t *configurations[] = {
        (const usb_configuration_descriptor_t *)&configuration1.configuration,
    };
    static const usb_device_descriptor_t device = {
        .bLength = sizeof(device),
        .bDescriptorType = USB_DEVICE_DESCRIPTOR,
        .bcdUSB = 0x0200,
        .bDeviceClass = 0,
        .bDeviceSubClass = 0,
        .bDeviceProtocol = 0,
        .bMaxPacketSize0 = 0x40,
        .idVendor = 0x0451,
        .idProduct = 0xE008,
        .bcdDevice = 0x0220,
        .iManufacturer = 0,
        .iProduct = 0,
        .iSerialNumber = 0,
        .bNumConfigurations = sizeof(configurations) / sizeof(*configurations),
    };
    static const usb_standard_descriptors_t standard = {
        .device = &device,
        .configurations = configurations,
        .langids = &langids,
        .numStrings = sizeof(strings) / sizeof(*strings),
        .strings = strings,
    };

    if(state)return true;
    memset(&storage,0,sizeof(storage));state=&storage;
    status=(link_status_t){LINK_WAIT,2,0,LINK_INIT,0};
    usb_error_t error=usb_Init(event_handler,NULL,&standard,USB_DEFAULT_INIT_FLAGS);
    if(error!=USB_SUCCESS){link_Stop();fail(error,LINK_INIT);return false;}
    state->devices.self=(usb_GetRole()&USB_ROLE_DEVICE)!=0;status.guest=state->devices.self;
    return true;
}

bool link_QueueRead(uint8_t device, void *buffer, size_t *length) {
    return queue(device, true, buffer, length);
}

bool link_QueueWrite(uint8_t device, const void *buffer, size_t *length) {
    return queue(device, false, (void *)buffer, length);
}

bool link_Poll(void){
 if(!state)return false;
 usb_error_t error=usb_HandleEvents();
 if(error!=USB_SUCCESS){
  if(error==USB_ERROR_SYSTEM||error==USB_ERROR_NO_MEMORY){link_Stop();fail(error,LINK_EVENTS);return false;}
  fail(error,LINK_EVENTS);return false;
 }
 /* Recover pre-attached devices and connected/role events delivered in
  * either order. A cable attachment must never rely on one callback only. */
 if(!(usb_GetRole()&USB_ROLE_DEVICE)&&!state->target&&!state->action){
  usb_device_t device=usb_FindDevice(NULL,NULL,USB_SKIP_HUBS);
  if(device&&!usb_GetDeviceData(device)){
   target(device);state->action=(usb_GetDeviceFlags(device)&USB_IS_ENABLED)?2:1;state->due=link_now();status.stage=LINK_ENUMERATE;
  }
 }
 if(state->target&&state->action&&!(usb_GetRole()&USB_ROLE_DEVICE)&&
    (int32_t)(link_now()-state->due)>=0){
  usb_device_t device=usb_RefDevice(state->target);
  uint16_t generation=state->generation;uint8_t action=state->action;state->action=0;status.error=0;status.attempts++;
  if(action==1){state->enumerating=true;status.stage=LINK_ENUMERATE;status.step=LINK_RESET;error=usb_ResetDevice(device);if(error!=USB_SUCCESS)state->enumerating=false;}
  else{
   static usb_string_descriptor_t check={.bString=L"" LINKLIB_KEY};size_t transferred=0;
   status.stage=LINK_CHECK;status.step=LINK_ID;
   error=usb_GetStringDescriptor(device,1,DEFAULT_LANGID,&check,key.bLength,&transferred);
   if(error==USB_SUCCESS && (transferred!=key.bLength||memcmp(&check,&key,key.bLength))){
    status.stage=LINK_MISMATCH;
   }else if(error==USB_SUCCESS && state->target==device && generation==state->generation){
    status.step=LINK_CONFIG;error=set_configuration(device);
    if(error==USB_SUCCESS && state->target==device && generation==state->generation){
     usb_SetDeviceData(device,&storage);status.stage=LINK_PEER;status.error=0;
    }
   }
  }
  if(error!=USB_SUCCESS){
   fail(error,status.step);
   if(action==1&&state->target==device){state->action=1;state->due=link_now()+LINK_RETRY_TICKS;}
  }
  if(state->target==device && generation==state->generation && status.stage!=LINK_PEER){
   state->action=action;state->due=link_now()+((action==1&&error==USB_SUCCESS)?LINK_ENUMERATION_TICKS:LINK_RETRY_TICKS);
  }
  usb_UnrefDevice(device);
 }
 return state->pending!=0;
}
const link_devices_t *link_Devices(void){
 static const link_devices_t none={.self=0,.count=0};
 link_Poll();if(!state)return &none;
 state->devices.self=(usb_GetRole()&USB_ROLE_DEVICE)!=0;status.guest=state->devices.self;
 state->devices.count=0;usb_device_t device=NULL;
 while((device=usb_FindDevice(NULL,device,USB_SKIP_HUBS|USB_SKIP_DISABLED)))
  if(usb_GetDeviceData(device)){state->devices.ids[0]=usb_GetDeviceAddress(device);state->devices.count=1;break;}
 return (const link_devices_t *)&state->devices;
}
