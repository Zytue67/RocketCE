#ifndef NET_H
#define NET_H
#include "game.h"
#include "linklib.h"
#include <stdbool.h>
typedef struct {link_status_t usb;uint32_t sent,received;bool synced,roleConflict;uint32_t rawReceived,completedSent,rejected;unsigned lastRead;} net_status_t;
net_status_t net_status(uint32_t now);
void net_sample_input(uint8_t input);
bool net_start(void);
void net_stop(void);
void net_poll(Game *g,uint8_t input,uint32_t now);
int net_player(void);
bool net_ready(uint32_t now);
uint8_t net_input(uint32_t now);
#endif
