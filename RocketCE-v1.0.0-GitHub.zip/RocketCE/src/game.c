#include "game.h"
#include <string.h>
#include <stdlib.h>
const int16_t sine[256]={0,6,13,19,25,31,38,44,50,56,62,68,74,80,86,92,98,104,109,115,121,126,132,137,142,147,152,157,162,167,172,177,181,185,190,194,198,202,206,209,213,216,220,223,226,229,231,234,237,239,241,243,245,247,248,250,251,252,253,254,255,255,256,256,256,256,256,255,255,254,253,252,251,250,248,247,245,243,241,239,237,234,231,229,226,223,220,216,213,209,206,202,198,194,190,185,181,177,172,167,162,157,152,147,142,137,132,126,121,115,109,104,98,92,86,80,74,68,62,56,50,44,38,31,25,19,13,6,0,-6,-13,-19,-25,-31,-38,-44,-50,-56,-62,-68,-74,-80,-86,-92,-98,-104,-109,-115,-121,-126,-132,-137,-142,-147,-152,-157,-162,-167,-172,-177,-181,-185,-190,-194,-198,-202,-206,-209,-213,-216,-220,-223,-226,-229,-231,-234,-237,-239,-241,-243,-245,-247,-248,-250,-251,-252,-253,-254,-255,-255,-256,-256,-256,-256,-256,-255,-255,-254,-253,-252,-251,-250,-248,-247,-245,-243,-241,-239,-237,-234,-231,-229,-226,-223,-220,-216,-213,-209,-206,-202,-198,-194,-190,-185,-181,-177,-172,-167,-162,-157,-152,-147,-142,-137,-132,-126,-121,-115,-109,-104,-98,-92,-86,-80,-74,-68,-62,-56,-50,-44,-38,-31,-25,-19,-13,-6};
static int32_t clamp(int32_t v,int32_t a,int32_t b){return v<a?a:v>b?b:v;}
/* The CE's native unsigned is 24 bits. Most camera/contact inputs fit. */
static unsigned root_native(unsigned n){unsigned r=0,b=1u<<22;while(b>n)b>>=2;while(b){if(n>=r+b){n-=r+b;r=(r>>1)+b;}else r>>=1;b>>=2;}return r;}
int32_t root32(uint32_t n){if(n<=0xffffffUL)return root_native((unsigned)n);uint32_t r=0,b=1UL<<30;while(b>n)b>>=2;while(b){if(n>=r+b){n-=r+b;r=(r>>1)+b;}else r>>=1;b>>=2;}return r;}
static void kickoff(Game *g){int i;g->blastMask=0;memset(&g->ball,0,sizeof(g->ball));g->ball.y=BALL_RADIUS*Q;for(i=0;i<2;i++){memset(&g->car[i],0,sizeof(Car));g->car[i].b.z=(i?KICKOFF_Z:-KICKOFF_Z)*Q;g->car[i].angle=i?128:0;g->car[i].boost=g->freeplay?100:60;}g->phase=PH_KICKOFF;g->phaseTicks=90;}
void game_init(Game *g,int freeplay){memset(g,0,sizeof(*g));g->remaining=180*HZ;g->freeplay=freeplay;kickoff(g);}
/* Native Q8 basis; the overwhelmingly common upright case avoids tilt work. */
void car_basis(const Car *c,CarBasis *m){
 int sy=sn(c->angle),cy=cs(c->angle);
 if(!c->pitch&&!c->roll){*m=(CarBasis){cy,0,-sy,0,Q,0,sy,0,cy};return;}
 int sp=sn(c->pitch),cp=cs(c->pitch),sr=sn(c->roll),cr=cs(c->roll);
 int ux=-sy*sp/Q,uy=cp,uz=-cy*sp/Q;
 *m=(CarBasis){(cy*cr-ux*sr)/Q,-uy*sr/Q,(-sy*cr-uz*sr)/Q,
  (cy*sr+ux*cr)/Q,uy*cr/Q,(-sy*sr+uz*cr)/Q,sy*cp/Q,sp,cy*cp/Q};
}
static int approach(int value,int target,int step){if(value<target){value+=step;if(value>target)value=target;}else if(value>target){value-=step;if(value<target)value=target;}return value;}
static void car_step(Car *c,uint8_t input){
 Body *b=&c->b;int32_t oldX=b->x,oldZ=b->z;int grounded=b->y==0&&!c->pitch&&!c->roll;
 int pressed=(input&JUMP)&&!(c->previous&JUMP);
 int32_t forward=((int)b->vx*sn(c->angle)+(int)b->vz*cs(c->angle))/Q;
 int turn=(input&RIGHT?1:0)-(input&LEFT?1:0);
 int pitchInput=(input&DOWN?1:0)-(input&UP?1:0);
 if(c->resetLock)c->resetLock--;
 if(grounded){c->jumps=0;c->jumpAge=0;c->flipUnlimited=0;c->dodgeTicks=0;c->pitchVelocity=c->rollVelocity=0;}
 else if(c->jumpAge<255)c->jumpAge++;
 /* Tire steering follows remaining longitudinal speed, including coasting.
  * Lower speeds permit a tighter radius without an abrupt steering cutoff. */
 int speed=abs((int)forward),maximum=384;
 if(grounded){
  maximum=(input&SLIDE)?352:240-(int)clamp(speed/Q,0,12)*8;
  if(speed<Q)maximum=maximum*speed/Q;
 }
 int target=(input&SLIDE)&&!grounded?0:turn*maximum*(grounded&&forward<0?-1:1);
 int rate=approach(c->yawVelocity,target,48);c->yawVelocity=rate;
 int total=c->yawFraction+rate,whole=total>=0?total/256:-((-total+255)/256);
 c->angle+=whole;c->yawFraction=total-whole*256;
 if(!grounded&&!c->dodgeTicks){
  c->pitchVelocity=approach(c->pitchVelocity,pitchInput*2,1);
  c->rollVelocity=approach(c->rollVelocity,(input&SLIDE)?turn*4:0,1);
  c->pitch+=c->pitchVelocity;c->roll+=c->rollVelocity;
 }
 CarBasis m;car_basis(c,&m);
 if(pressed){
  if(grounded){b->vy=6*Q;c->jumps=1;c->jumpHeld=6;c->jumpAge=0;grounded=0;}
  else if(b->y<=24*Q&&abs((int)b->vy)<Q&&m.uy<180){
   /* One-button self-right when resting on the roof. */
   c->pitch=c->roll=0;c->pitchVelocity=c->rollVelocity=0;c->dodgeTicks=0;
   b->vy=4*Q;c->jumps=1;c->jumpHeld=0;c->jumpAge=0;car_basis(c,&m);
  }else if(c->jumps<2&&(c->flipUnlimited||c->jumpAge<=DODGE_WINDOW)){
   c->jumps=2;c->jumpHeld=0;c->flipUnlimited=0;
   int ahead=(input&UP?1:0)-(input&DOWN?1:0),side=turn;
   if(ahead||side){
    int scale=ahead&&side?181:Q;
    b->vx+=(m.fx*ahead+m.rx*side)*scale/Q*6;
    b->vy+=(m.fy*ahead+m.ry*side)*scale/Q*6;
    b->vz+=(m.fz*ahead+m.rz*side)*scale/Q*6;
    if(b->vy<2*Q&&b->y>8*Q)b->vy=2*Q;
    c->flipPitch=-ahead;c->flipRoll=side;c->dodgeTicks=DODGE_DURATION;
    c->pitchVelocity=-ahead*18*scale/Q;c->rollVelocity=side*18*scale/Q;
   }else {b->vx+=m.ux*6;b->vy+=m.uy*6;b->vz+=m.uz*6;}
  }
 }
 if(c->jumpHeld){if(input&JUMP){b->vy+=80;c->jumpHeld--;}else c->jumpHeld=0;}
 if(c->dodgeTicks){
  /* Dodge torque decays instead of prescribing a fixed one-turn animation.
   * Counter-pitch and air-roll can change the rotation during the dodge. */
  if(c->dodgeTicks<DODGE_DURATION-1){
   if((c->flipPitch<0&&pitchInput>0)||(c->flipPitch>0&&pitchInput<0)){
    c->pitchVelocity=approach(c->pitchVelocity,pitchInput*2,5);c->flipPitch=0;
   }else if(!c->flipPitch)c->pitchVelocity=approach(c->pitchVelocity,pitchInput*2,2);
   if(input&SLIDE)c->rollVelocity=approach(c->rollVelocity,turn*4,3);
   if(c->dodgeTicks<=8){c->pitchVelocity=approach(c->pitchVelocity,0,2);c->rollVelocity=approach(c->rollVelocity,0,2);}
  }
  c->pitch+=c->pitchVelocity;c->roll+=c->rollVelocity;c->dodgeTicks--;car_basis(c,&m);
 }
 if(grounded){
  /* Light drag plus rolling resistance, independent of throttle state.
   * Grip removes sideways slip; it does not erase forward momentum. */
  int rolling=(input&SLIDE)?1:3;
  b->vx=approach(b->vx-b->vx/256,0,rolling);
  b->vz=approach(b->vz-b->vz/256,0,rolling);
  int lateral=((int)b->vx*m.rx+(int)b->vz*m.rz)/Q,grip=(input&SLIDE)?4:80;
  b->vx-=lateral*m.rx/Q*grip/Q;b->vz-=lateral*m.rz/Q*grip/Q;
  int throttle=(input&UP?1:0)-(input&DOWN?1:0),accel=0;
  if(throttle){
   int along=(int)forward*throttle,cruise=(throttle>0?6:4)*Q;
   /* Opposite throttle brakes before reversing. The engine tapers at its
    * cruise speed; boost/dodge momentum above it is allowed to coast. */
   if(along<0)accel=throttle*160;
   else if(along<cruise)accel=throttle*(throttle>0?90:70)*(cruise-along)/cruise;
  }
  b->vx+=m.fx*accel/Q;b->vz+=m.fz*accel/Q;
 }
 if((input&BOOST)&&c->boost){b->vx+=m.fx*175/Q;b->vy+=m.fy*175/Q;b->vz+=m.fz*175/Q;c->boost--;}
 if((input&BRAKE)&&grounded){b->vx=(int)b->vx*200/Q;b->vz=(int)b->vz*200/Q;}
 int vx=b->vx/Q,vz=b->vz/Q;unsigned speed2=vx*vx+vz*vz;
 if(speed2>18*18){int speed=root32(speed2);if(speed>18){b->vx=(int)b->vx*18/speed;b->vz=(int)b->vz*18/speed;}}
 b->vy=clamp(b->vy-75,-18*Q,18*Q);b->x+=b->vx;b->y+=b->vy;b->z+=b->vz;
 int half=CAR_HEIGHT/2;
 int ex,ey,ez;
 if(!c->pitch&&!c->roll){ex=(abs(m.rx)*CAR_HALF_WIDTH+abs(m.fx)*CAR_HALF_LENGTH)/Q;ey=half;ez=(abs(m.rz)*CAR_HALF_WIDTH+abs(m.fz)*CAR_HALF_LENGTH)/Q;}
 else {ex=(abs(m.rx)*CAR_HALF_WIDTH+abs(m.ux)*half+abs(m.fx)*CAR_HALF_LENGTH)/Q;ey=(abs(m.ry)*CAR_HALF_WIDTH+abs(m.uy)*half+abs(m.fy)*CAR_HALF_LENGTH)/Q;ez=(abs(m.rz)*CAR_HALF_WIDTH+abs(m.uz)*half+abs(m.fz)*CAR_HALF_LENGTH)/Q;}
 int floor=ey-half;if(floor<0)floor=0;
 if(b->y<=floor*Q&&b->vy<=0){
  b->y=floor*Q;b->vy=0;
  if(m.uy>180){
   if(c->pitch||c->roll)c->angle=heading(m.fx,m.fz);c->pitch=c->roll=0;b->y=0;
   c->jumps=0;c->jumpHeld=0;c->jumpAge=0;c->flipUnlimited=0;c->dodgeTicks=0;c->restTicks=0;
   c->pitchVelocity=c->rollVelocity=0;
   ex=(abs(cs(c->angle))*CAR_HALF_WIDTH+abs(sn(c->angle))*CAR_HALF_LENGTH)/Q;ey=half;
   ez=(abs(sn(c->angle))*CAR_HALF_WIDTH+abs(cs(c->angle))*CAR_HALF_LENGTH)/Q;
  }else if(!c->dodgeTicks&&!(input&SLIDE)){
   /* Arcade landing assist: don't leave a completed flip perched on its nose.
    * MODE keeps manual air-roll recovery available. */
   if(c->restTicks<255)c->restTicks++;
   int p=(int8_t)c->pitch,r=(int8_t)c->roll;
   int ip=(int8_t)(c->pitch-128),ir=(int8_t)(c->roll-128);
   if(abs(ip)+abs(ir)<abs(p)+abs(r)){c->pitch=128+approach(ip,0,8);c->roll=128+approach(ir,0,8);}
   else {c->pitch=approach(p,0,8);c->roll=approach(r,0,8);}
   c->pitchVelocity=c->rollVelocity=0;
   if(c->restTicks>20){c->angle=heading(m.fx,m.fz);c->pitch=c->roll=0;b->y=0;c->jumps=0;c->restTicks=0;}
  }
 }else c->restTicks=0;
 int limitX=FIELD_X-ex,limitZ=FIELD_Z-ez,top=FIELD_HEIGHT-ey-half;
 int inGoal=abs((int)oldZ)>FIELD_Z*Q&&abs((int)oldX)<GOAL_WIDTH*Q;
 int mouth=abs((int)b->x)<=(GOAL_WIDTH-ex)*Q&&b->y+(half+ey)*Q<=GOAL_HEIGHT*Q;
 if(inGoal||mouth)limitZ=FIELD_Z+GOAL_DEPTH-ez;
 if(inGoal){limitX=GOAL_WIDTH-ex;top=GOAL_HEIGHT-ey-half;}
 if(b->y>top*Q){b->y=top*Q;b->vy=-abs((int)b->vy)/2;}
 /* Reflect only velocity into the wall. Cap the outward kick, leaving
  * along-wall momentum untouched, including after a boosted impact. */
 if(b->x>limitX*Q){b->x=limitX*Q;if(b->vx>0)b->vx=-clamp((int)b->vx/2,0,CAR_WALL_REBOUND);}
 else if(b->x<-limitX*Q){b->x=-limitX*Q;if(b->vx<0)b->vx=clamp(-(int)b->vx/2,0,CAR_WALL_REBOUND);}
 if(b->z>limitZ*Q){b->z=limitZ*Q;if(b->vz>0)b->vz=-clamp((int)b->vz/2,0,CAR_WALL_REBOUND);}
 else if(b->z<-limitZ*Q){b->z=-limitZ*Q;if(b->vz<0)b->vz=clamp(-(int)b->vz/2,0,CAR_WALL_REBOUND);}
 c->previous=input;
}
/* Sphere against a yaw-oriented car box. Broad phase avoids work at range. */
static void hit_ball(Car *c,Body *b){
 int dx=(b->x-c->b.x)/Q,wy=(b->y-c->b.y)/Q-CAR_HEIGHT/2,dz=(b->z-c->b.z)/Q;
 if(abs(dx)>64||abs(dz)>64||abs(wy)>64)return;
 CarBasis m;car_basis(c,&m);
 int lx=(dx*m.rx+wy*m.ry+dz*m.rz)/Q;
 int dy=(dx*m.ux+wy*m.uy+dz*m.uz)/Q;
 int lz=(dx*m.fx+wy*m.fy+dz*m.fz)/Q;
 int nx=lx-clamp(lx,-CAR_HALF_WIDTH,CAR_HALF_WIDTH);
 int ny=dy-clamp(dy,-CAR_HEIGHT/2,CAR_HEIGHT/2);
 int nz=lz-clamp(lz,-CAR_HALF_LENGTH,CAR_HALF_LENGTH);
 int d2=nx*nx+ny*ny+nz*nz;if(d2>=BALL_RADIUS*BALL_RADIUS)return;
 /* Three wheel contact patches restore a dodge, with a short debounce.
  * The CE car/ball proportions use a small contact tolerance. */
 if(!c->resetLock&&c->b.y>8*Q&&dy<-CAR_HEIGHT/2){
  int contacts=0;
  for(int sx=-1;sx<=1;sx+=2)for(int sz=-1;sz<=1;sz+=2){
   int wx=lx-sx*10,wz=lz-sz*13,yy=dy+CAR_HEIGHT/2;
   if(wx*wx+wz*wz+yy*yy<=(BALL_RADIUS+3)*(BALL_RADIUS+3))contacts++;
  }
  if(contacts>=3){c->jumps=1;c->flipUnlimited=1;c->jumpAge=0;c->resetLock=15;}
 }
 int d,penetration;
 if(d2){d=root32(d2);penetration=BALL_RADIUS-d;}
 else {
  int mx=CAR_HALF_WIDTH-abs(lx),my=CAR_HEIGHT/2-abs(dy),mz=CAR_HALF_LENGTH-abs(lz);
  nx=ny=nz=0;d=Q;
  if(my<=mx&&my<=mz){ny=dy<0?-Q:Q;penetration=BALL_RADIUS+my;}
  else if(mx<=mz){nx=lx<0?-Q:Q;penetration=BALL_RADIUS+mx;}
  else {nz=lz<0?-Q:Q;penetration=BALL_RADIUS+mz;}
 }
 int wx=(nx*m.rx+ny*m.ux+nz*m.fx)/Q;
 int worldY=(nx*m.ry+ny*m.uy+nz*m.fy)/Q;
 int wz=(nx*m.rz+ny*m.uz+nz*m.fz)/Q;
 b->x+=(int32_t)wx*penetration*Q/d;b->y+=(int32_t)worldY*penetration*Q/d;b->z+=(int32_t)wz*penetration*Q/d;
 int32_t rv=((b->vx-c->b.vx)*wx+(b->vy-c->b.vy)*worldY+(b->vz-c->b.vz)*wz)/d;
 if(rv<0){int32_t kick=ny<0?-rv*5/4:-rv*7/4;b->vx+=wx*kick/d;b->vy+=worldY*kick/d;b->vz+=wz*kick/d;}

}
/* Ball against the visible goal frame and rectangular pocket. Near posts,
 * use a radial contact normal instead of a shrunken invisible flat wall. */
static void goal_bounds(Body *b){
 int side=b->z<0?-1:1;
 if(abs((int)b->z)<=(FIELD_Z-BALL_RADIUS)*Q)return;
 if(abs((int)b->x)>=GOAL_WIDTH*Q||b->y>=GOAL_HEIGHT*Q){
  b->z=side*(FIELD_Z-BALL_RADIUS)*Q;if((int)b->vz*side>0)b->vz=-b->vz*210/Q;return;
 }
 if(abs((int)b->z)>FIELD_Z*Q){
  int edge=(GOAL_WIDTH-BALL_RADIUS)*Q;
  if(b->x>edge){b->x=edge;if(b->vx>0)b->vx=-b->vx*210/Q;}
  if(b->x<-edge){b->x=-edge;if(b->vx<0)b->vx=-b->vx*210/Q;}
  if(b->y>(GOAL_HEIGHT-BALL_RADIUS)*Q){b->y=(GOAL_HEIGHT-BALL_RADIUS)*Q;if(b->vy>0)b->vy=-b->vy*210/Q;}
  return;
 }
 for(int part=0;part<2;part++){
  int gap=part?GOAL_HEIGHT-(int)b->y/Q:GOAL_WIDTH-abs((int)b->x/Q),dz=abs((int)b->z/Q)-FIELD_Z;
  if(gap>=BALL_RADIUS)continue;int d2=gap*gap+dz*dz;if(d2>=BALL_RADIUS*BALL_RADIUS)continue;
  int d=root32(d2),nx=part?0:(b->x<0?gap:-gap),ny=part?-gap:0,nz=side*dz;
  if(!d){d=1;nx=ny=0;nz=-side;}
  int push=BALL_RADIUS-d;b->x+=nx*push*Q/d;b->y+=ny*push*Q/d;b->z+=nz*push*Q/d;
  int v=((int)b->vx*nx+(int)b->vy*ny+(int)b->vz*nz)/d;
  if(v<0){int impulse=-(int32_t)v*466/Q;b->vx+=nx*impulse/d;b->vy+=ny*impulse/d;b->vz+=nz*impulse/d;}
 }
}
/* One impulse per scored goal. Cosmetic trajectories use existing car state. */
static void goal_blast(Game *g){
 g->blastMask=0;
 for(int i=0;i<(g->freeplay?1:2);i++){
  Car *c=&g->car[i];int dx=(c->b.x-g->ball.x)/Q,dy=(c->b.y+CAR_HEIGHT/2*Q-g->ball.y)/Q,dz=(c->b.z-g->ball.z)/Q;
  if(abs(dx)>=BLAST_RADIUS||abs(dy)>=BLAST_RADIUS||abs(dz)>=BLAST_RADIUS)continue;
  unsigned d=root32((unsigned)(dx*dx+dy*dy+dz*dz));if(d>=BLAST_RADIUS)continue;
  if(!d){dz=g->ball.z>0?-1:1;d=1;}
  int force=(BLAST_RADIUS-(int)d)*14*Q/BLAST_RADIUS;
  c->b.vx+=dx*force/(int)d;c->b.vz+=dz*force/(int)d;c->b.vy+=(BLAST_RADIUS-(int)d)*9*Q/BLAST_RADIUS+2*Q;
  if(c->b.y==0)c->b.y=Q;
  c->pitchVelocity=i?3:-3;c->rollVelocity=dx<0?-4:4;c->jumpHeld=c->dodgeTicks=0;c->flipPitch=c->flipRoll=0;c->jumps=2;
  g->blastMask|=1u<<i;
 }
 g->ball.vx=g->ball.vy=g->ball.vz=0;
}
static void celebration_step(Game *g){
 for(int i=0;i<(g->freeplay?1:2);i++){
  Car *c=&g->car[i];int p=c->pitchVelocity,r=c->rollVelocity;car_step(c,0);
  if(g->blastMask&(1u<<i)){if(c->b.y>0){c->pitchVelocity=p;c->rollVelocity=r;}else g->blastMask&=~(1u<<i);}
 }
}
static const int16_t px[6]={-375,375,-375,375,-320,320},pz[6]={-575,-575,575,575,0,0};
void game_step(Game *g,uint8_t a,uint8_t b){int i,j;g->tick++;if(g->phase==PH_END)return;
 if(g->phase!=PH_PLAY){
  if(g->phase==PH_GOAL)celebration_step(g);
  if(g->phaseTicks)g->phaseTicks--;
  if(!g->phaseTicks){if(g->phase==PH_GOAL){if(!g->freeplay&&(g->overtime||(!g->remaining&&g->score[0]!=g->score[1])))g->phase=PH_END;else kickoff(g);}else g->phase=PH_PLAY;}return;
 }
 int32_t before[2][3]={{g->car[0].b.x,g->car[0].b.y,g->car[0].b.z},{g->car[1].b.x,g->car[1].b.y,g->car[1].b.z}};
 car_step(&g->car[0],a);if(!g->freeplay)car_step(&g->car[1],b);
 /* Equal-mass car bump. */
 if(!g->freeplay){Body *u=&g->car[0].b,*v=&g->car[1].b;int32_t dx=(v->x-u->x)/Q,dy=(v->y-u->y)/Q,dz=(v->z-u->z)/Q,d=(abs((int)dx)<34&&abs((int)dy)<34&&abs((int)dz)<34)?root32(dx*dx+dy*dy+dz*dz):34;if(d<34&&d){int32_t push=(34-d)*Q/2;u->x-=dx*push/d;u->z-=dz*push/d;v->x+=dx*push/d;v->z+=dz*push/d;int32_t rv=((v->vx-u->vx)*dx+(v->vz-u->vz)*dz)/d;if(rv<0){u->vx+=dx*rv/d;u->vz+=dz*rv/d;v->vx-=dx*rv/d;v->vz-=dz*rv/d;}}}
 Body *ball=&g->ball;ball->vy-=48;ball->vx=(int)ball->vx*255/Q;ball->vz=(int)ball->vz*255/Q;
 ball->vx=clamp(ball->vx,-MAX_BALL_SPEED*Q,MAX_BALL_SPEED*Q);ball->vy=clamp(ball->vy,-MAX_BALL_SPEED*Q,MAX_BALL_SPEED*Q);ball->vz=clamp(ball->vz,-MAX_BALL_SPEED*Q,MAX_BALL_SPEED*Q);
 int steps=1,cars=g->freeplay?1:2;
 /* Subdivide by relative travel, rather than always doing four contacts
  * merely because a car is nearby. Slow dribbling needs one contact pass. */
 int travel=abs((int)ball->vx);if(abs((int)ball->vy)>travel)travel=abs((int)ball->vy);if(abs((int)ball->vz)>travel)travel=abs((int)ball->vz);
 if(travel>20*Q)steps=4;else if(travel>8*Q)steps=2;
 for(i=0;i<cars;i++){
  Body *c=&g->car[i].b;int dx=(ball->x-c->x)/Q,dy=(ball->y-c->y)/Q,dz=(ball->z-c->z)/Q;
  if(abs(dx)<112&&abs(dy)<112&&abs(dz)<112){
   int relative=abs((int)(ball->vx-c->vx)),v=abs((int)(ball->vy-c->vy));if(v>relative)relative=v;v=abs((int)(ball->vz-c->vz));if(v>relative)relative=v;
   if(relative>20*Q)steps=4;else if(relative>8*Q&&steps<2)steps=2;
  }
 }
 int32_t after[2][3]={{g->car[0].b.x,g->car[0].b.y,g->car[0].b.z},{g->car[1].b.x,g->car[1].b.y,g->car[1].b.z}};
 for(int sub=1;sub<=steps;sub++){
  ball->x+=steps==1?ball->vx:steps==2?(int)ball->vx/2:(int)ball->vx/4;ball->y+=steps==1?ball->vy:steps==2?(int)ball->vy/2:(int)ball->vy/4;ball->z+=steps==1?ball->vz:steps==2?(int)ball->vz/2:(int)ball->vz/4;
  for(i=0;i<cars;i++){
   Car *c=&g->car[i];
   if(steps>1){c->b.x=before[i][0]+(steps==2?(int)(after[i][0]-before[i][0])*sub/2:(int)(after[i][0]-before[i][0])*sub/4);c->b.y=before[i][1]+(steps==2?(int)(after[i][1]-before[i][1])*sub/2:(int)(after[i][1]-before[i][1])*sub/4);c->b.z=before[i][2]+(steps==2?(int)(after[i][2]-before[i][2])*sub/2:(int)(after[i][2]-before[i][2])*sub/4);}
   hit_ball(c,ball);
   if(steps>1){c->b.x=after[i][0];c->b.y=after[i][1];c->b.z=after[i][2];}
  }
  /* Constant-time box constraints: no support frames or curved planes. */
  if(ball->y<BALL_RADIUS*Q){ball->y=BALL_RADIUS*Q;ball->vy=abs((int)ball->vy)*180/Q;if(ball->vy<100)ball->vy=0;}
  if(ball->y>(FIELD_HEIGHT-BALL_RADIUS)*Q){ball->y=(FIELD_HEIGHT-BALL_RADIUS)*Q;ball->vy=-abs((int)ball->vy)*210/Q;}
  if(abs((int)(ball->x/Q))>FIELD_X-BALL_RADIUS){ball->x=clamp(ball->x,-(FIELD_X-BALL_RADIUS)*Q,(FIELD_X-BALL_RADIUS)*Q);ball->vx=-ball->vx*210/Q;}
  goal_bounds(ball);
  if(abs((int)ball->z)>=(FIELD_Z+BALL_RADIUS)*Q&&abs((int)ball->x)<=(GOAL_WIDTH-BALL_RADIUS)*Q&&ball->y<=(GOAL_HEIGHT-BALL_RADIUS)*Q){i=ball->z>0?0:1;g->lastGoal=i;if(g->score[i]<99)g->score[i]++;g->phase=PH_GOAL;g->phaseTicks=GOAL_CELEBRATION;goal_blast(g);break;}
  int sx=ball->vx/Q,sy=ball->vy/Q,sz=ball->vz/Q;unsigned speed2=sx*sx+sy*sy+sz*sz;
  if(speed2>MAX_BALL_SPEED*MAX_BALL_SPEED){int speed=root32(speed2);ball->vx=(int)ball->vx*MAX_BALL_SPEED/speed;ball->vy=(int)ball->vy*MAX_BALL_SPEED/speed;ball->vz=(int)ball->vz*MAX_BALL_SPEED/speed;}
 }
 for(j=0;j<6;j++){if(g->pads[j])g->pads[j]--;else for(i=0;i<(g->freeplay?1:2);i++){Car *c=&g->car[i];int32_t dx=c->b.x/Q-px[j],dz=c->b.z/Q-pz[j];if(c->b.y<10*Q&&dx*dx+dz*dz<30*30&&c->boost<100){c->boost=100;g->pads[j]=8*HZ;break;}}}
 if(g->freeplay){g->car[0].boost=100;return;}
 if(g->remaining)g->remaining--;if(!g->remaining&&g->phase==PH_PLAY){if(g->score[0]==g->score[1])g->overtime=1;else g->phase=PH_END;}
}
/* Direction approximation avoids a 64-angle search per physics step. */
uint8_t heading(int dx,int dz){int x=abs(dx),z=abs(dz);if(!x&&!z)return 0;int a=x>z?64-32*z/x:32*x/z;if(dz<0)a=128-a;if(dx<0)a=256-a;return (uint8_t)a;}
uint8_t bot_input(Game *g,int who,int difficulty){if(g->phase!=PH_PLAY)return 0;Car *c=&g->car[who];int sign=who?-1:1;int32_t tx=g->ball.x/Q+g->ball.vx/Q*8,tz=g->ball.z/Q+g->ball.vz/Q*8-sign*55;
 if((g->ball.z-c->b.z)*sign<0){tz=g->ball.z/Q-sign*120;tx=g->ball.x/Q/2;}
 if(c->b.y==0&&!c->pitch&&!c->roll){
  int x=c->b.x/Q,z=c->b.z/Q,v=abs((int)c->b.vx)+abs((int)c->b.vz);
  int nearX=abs(x)>FIELD_X-75,nearZ=(abs(z)>FIELD_Z-75&&abs(x)>GOAL_WIDTH-32)||abs(z)>FIELD_Z+GOAL_DEPTH-55;
  int into=(nearX&&sn(c->angle)*(x<0?-1:1)>100)||(nearZ&&cs(c->angle)*(z<0?-1:1)>100);
  if(v<Q){if(c->botIdle<255)c->botIdle++;}else c->botIdle=0;
  if(!c->botEscape&&((into&&v<3*Q)||c->botIdle>40)){c->botEscape=90;c->botIdle=0;}
  if(c->botEscape){
   int reverse=c->botEscape>35;c->botEscape--;
   int h=heading(-x,-z)+(reverse?128:0),d=(uint8_t)(h-c->angle);if(d>127)d-=256;
   int forward=((int)c->b.vx*sn(c->angle)+(int)c->b.vz*cs(c->angle))/Q,turn=d>4?1:d<-4?-1:0;
   if(forward<0)turn=-turn;
   return (reverse?DOWN:UP)|(turn>0?RIGHT:turn<0?LEFT:0)|(!reverse&&abs(d)>35?SLIDE:0);
  }
 }else {c->botIdle=0;c->botEscape=0;}
 tx=clamp(tx,-(FIELD_X-50),FIELD_X-50);tz=clamp(tz,-(FIELD_Z+GOAL_DEPTH-35),FIELD_Z+GOAL_DEPTH-35);
 /* Aim ahead of the car's carried velocity, not just its current position. */
 int32_t dx=tx-c->b.x/Q-c->b.vx/Q*4,dz=tz-c->b.z/Q-c->b.vz/Q*4;int best=heading(dx,dz);
 int delta=(uint8_t)(best-c->angle);if(delta>127)delta-=256;uint8_t in=UP;if(delta>5)in|=RIGHT;if(delta<-5)in|=LEFT;
 if(abs(delta)>55)in=(delta>0?RIGHT:LEFT)|UP|SLIDE;
 int forward=((int)c->b.vx*sn(c->angle)+(int)c->b.vz*cs(c->angle))/Q;
 if(forward<0){uint8_t turn=in&(LEFT|RIGHT);in&=~(LEFT|RIGHT);if(turn&LEFT)in|=RIGHT;if(turn&RIGHT)in|=LEFT;}
 int vx=c->b.vx/Q,vz=c->b.vz/Q;
 if((abs(delta)>25&&vx*vx+vz*vz>4*4)||(dx*dx+dz*dz<220*220&&vx*vx+vz*vz>8*8))in|=BRAKE;
 if(difficulty&&abs(delta)<12&&dx*dx+dz*dz>400*400&&c->boost>15)in|=BOOST;
 int32_t bx=g->ball.x/Q-c->b.x/Q,bz=g->ball.z/Q-c->b.z/Q;if(difficulty&&bx*bx+bz*bz<65*65&&g->ball.y>24*Q&&g->ball.y<90*Q&&c->b.y==0)in|=JUMP;
 if(c->b.y>0||c->pitch||c->roll){
  /* Recover orientation before chasing height; never hold boost upward forever. */
  in=0;int p=(int8_t)c->pitch,r=(int8_t)c->roll;
  int ip=(int8_t)(c->pitch-128),ir=(int8_t)(c->roll-128);
  if(abs(ip)+abs(ir)<abs(p)+abs(r)){p=ip;r=ir;}
  if(p>3)in|=UP;if(p<-3)in|=DOWN;
  if(abs(r)>3)in|=SLIDE|(r>0?LEFT:RIGHT);
  if((c->pitch||c->roll)&&c->b.y<24*Q&&c->b.vy==0&&(g->tick%12==0))in|=JUMP;
 }

 return in;}
