#include "ui.h"
#include <graphx.h>
#include <stdio.h>
#include <string.h>
#ifndef ROCKET_UI_HOST
#include <ti/vars.h>
#include <compression.h>
#endif
#include "ui_assets.inc"
enum{BG=24,CARD,EDGE,INK,SOFT,ICE,GOLD,PULSE};
static const uint16_t colors[8]={0x0425,0x0849,0x10ce,0x7fff,0x4673,0x36df,0x7f60,0x7fff};
#ifndef ROCKET_UI_HOST
static const uint8_t *art[2];
static int titleDrawn;
static const uint8_t *load_art(const char *name,unsigned size,unsigned check){
 var_t *v=os_GetAppVarData(name,NULL);if(!v||v->size!=size)return NULL;
 const uint8_t *d=v->data;if(memcmp(d,"RCE1",4)||((unsigned)d[4]|(unsigned)d[5]<<8)!=size-8||((unsigned)d[6]|(unsigned)d[7]<<8)!=check)return NULL;
 uint16_t sum=0;for(unsigned i=8;i<size;i++)sum+=d[i];if(sum!=check)return NULL;return d+8;
}
#endif
void ui_init(void){gfx_SetPalette(colors,sizeof(colors),24);gfx_SetPalette(artPalette,sizeof(artPalette),64);
#ifndef ROCKET_UI_HOST
 titleDrawn=0;art[0]=load_art("RCETITLE",TITLE_SIZE,TITLE_CHECK);art[1]=load_art("RCEMENU",MENU_SIZE,MENU_CHECK);
#endif
}
static int backdrop(int which){
#ifdef ROCKET_UI_HOST
 host_bitmap(which?"../assets/menu.png":"../assets/title.png");return 1;
#else
 if(!art[which])return 0;zx7_Decompress(gfx_vbuffer,art[which]);return 1;
#endif
}
static void rect(int x,int y,int w,int h,int c){gfx_SetColor(c);gfx_FillRectangle(x,y,w,h);}
static void label(int x,int y,const char *s,int c){gfx_SetTextFGColor(c);gfx_PrintStringXY(s,x,y);}
static void middle(int y,const char *s,int c){label((320-gfx_GetStringWidth(s))/2,y,s,c);}
static void base(void){gfx_SetTextScale(1,1);gfx_FillScreen(BG);rect(0,0,4,240,ICE);rect(316,0,4,240,GOLD);for(int i=0;i<5;i++)rect(194+i*23,22+i*7,15,2,EDGE);rect(16,220,288,1,EDGE);}
static void badge(int x,int y,int c){rect(x,y,30,4,c);rect(x,y+4,4,19,c);rect(x+26,y+4,4,19,c);rect(x+4,y+23,22,4,c);rect(x+10,y+27,10,4,c);rect(x+9,y+9,12,8,INK);}
/* The reference logo appears immediately; only the prompt changes color. */
void ui_intro(unsigned frame){ui_title(frame*2);}
void ui_title(unsigned pulse){
 unsigned phase=pulse%64;if(phase>32)phase=64-phase;unsigned level=4+phase*27/32;
 uint16_t color=(level<<10)|(level<<5)|level;gfx_SetPalette(&color,2,PULSE);
#ifndef ROCKET_UI_HOST
 /* Palette animation affects the visible prompt directly. Decode artwork
  * only once; don't redraw or swap the screen just to change its brightness. */
 if(titleDrawn)return;titleDrawn=1;
#endif
 gfx_SetTextScale(1,1);if(!backdrop(0)){base();badge(145,45,ICE);gfx_SetTextScale(3,3);middle(100,"ROCKET CE",INK);gfx_SetTextScale(1,1);middle(185,"INSTALL RCETITLE + RCEMENU",SOFT);}
 rect(75,220,170,17,BG);middle(225,"ENTER TO START",PULSE);gfx_SwapDraw();
}
static const char *tips[]={
 "Press 2nd twice to double jump. Release it between presses.",
 "Add arrows to your second jump for a directional flip.",
 "Hold ALPHA to boost in the direction your car is facing.",
 "Hold MODE while steering to powerslide.",
 "In the air, hold MODE with Left or Right to roll.",
 "Press TRACE to switch between car cam and ball cam.",
 "Yellow boost pads refill your boost. Free Play has unlimited boost.",
 "Press GRAPH to brake. Opposite throttle slows you before reversing.",
 "Counter the pitch direction to cancel a front or back flip.",
 "Press ZOOM to switch between FAST and FINE detail."
};
#define TIP_COUNT (sizeof(tips)/sizeof(tips[0]))
static unsigned menuSelected,tickerOffset,tipsCycle,tipWidths[TIP_COUNT];
static void ticker(void){
 rect(0,224,320,16,BG);
 if(!tipsCycle)for(unsigned i=0;i<TIP_COUNT;i++){tipWidths[i]=gfx_GetStringWidth(tips[i]);tipsCycle+=tipWidths[i]+60;}
 unsigned offset=tickerOffset%tipsCycle;int x=12-(int)offset;
 for(unsigned i=0;i<TIP_COUNT*2&&x<320;i++){
  const char *s=tips[i%TIP_COUNT];unsigned width=tipWidths[i%TIP_COUNT];
  if(x+(int)width>=0){int at=x;for(;*s&&at<320;s++){char one[2]={*s,0};unsigned w=gfx_GetStringWidth(one);if(at>=0&&at+(int)w<=320)label(at,229,one,INK);at+=w;}}
  x+=width+60;
 }
}
void ui_menu(unsigned selected){static const char *names[]={"PLAY 1v1","FREE PLAY","CALCULATOR LINK","CONTROLS","EXIT"};static const char *tags[]={"Play a local match against the bot.","Practice with unlimited boost.","Connect two calculators via USB.","View driving and aerial controls.","Return to the calculator."};if(selected>4)selected=0;menuSelected=selected;gfx_SetTextScale(1,1);
 if(!backdrop(1)){base();rect(5,99,138,98,CARD);}
 label(12,85,"MAIN MENU",INK);
 for(unsigned i=0;i<5;i++){int y=100+i*19;if(i==selected){rect(7,y,135,17,ICE);rect(7,y,3,17,INK);}label(15,y+5,names[i],i==selected?BG:INK);}
 rect(7,201,300,13,BG);label(12,204,tags[selected],INK);
 ticker();gfx_SwapDraw();
#ifndef ROCKET_UI_HOST
 /* Seed both buffers once per selection; ticker updates touch only 16 rows. */
 gfx_Blit(gfx_screen);
#endif
}
void ui_menu_tick(uint32_t elapsed){tickerOffset=elapsed/1365;
#ifdef ROCKET_UI_HOST
 ui_menu(menuSelected);
#else
 gfx_SetTextScale(1,1);ticker();gfx_SwapDraw();
#endif
}
/* Static help: draw once, with no animation or gameplay work. */
static void control_row(int x,int y,const char *key,const char *action,int accent){
 rect(x,y,54,14,EDGE);label(x+4,y+3,key,accent);label(x+60,y+3,action,INK);
}
void ui_controls(void){
 base();gfx_SetTextScale(2,2);label(16,13,"CONTROLS",INK);gfx_SetTextScale(1,1);
 label(17,36,"LEARN THE MOVES. OWN THE FIELD.",SOFT);
 rect(14,54,143,88,CARD);rect(163,54,143,88,CARD);
 rect(14,54,3,88,ICE);rect(163,54,3,88,GOLD);
 label(23,61,"GROUND",ICE);label(172,61,"IN THE AIR",GOLD);
 control_row(22,76,"UP/DN","Drive",ICE);control_row(22,92,"L / R","Steer",ICE);
 control_row(22,108,"MODE","Slide",ICE);control_row(22,124,"GRAPH","Brake",ICE);
 control_row(171,76,"UP/DN","Pitch",GOLD);control_row(171,92,"L / R","Yaw",GOLD);
 label(172,111,"MODE + L/R: roll",INK);label(172,128,"ALPHA: nose boost",INK);
 rect(14,148,292,43,CARD);rect(14,148,3,43,ICE);
 label(23,155,"2nd  JUMP / DOUBLE JUMP",ICE);label(23,168,"Hold for height. Release between presses.",INK);
 label(23,180,"Second jump + arrows: directional flip",INK);
 label(17,198,"ALPHA: boost   TRACE: cam   ZOOM: detail",INK);
 label(17,210,"Opposite pitch cancels front/back flips.",SOFT);
 middle(228,"ENTER / CLEAR  RETURN TO MENU",ICE);gfx_SwapDraw();
}
void ui_link(net_status_t s,unsigned frame){
 static const char *stages[]={"USB OFF","WAITING FOR CABLE","DETECTING CALCULATOR","CHECKING GAME VERSION","SYNCING MATCH","OTHER GAME / VERSION","USB ERROR"};
 unsigned stage=s.usb.stage;if(stage>LINK_ERROR)stage=LINK_ERROR;
 char line[48];base();badge(16,14,ICE);gfx_SetTextScale(2,2);label(58,18,"CALCULATOR",INK);gfx_SetTextScale(1,1);label(59,39,"LINK  /  LOCAL 1v1",ICE);
 rect(16,58,288,91,CARD);label(27,68,s.roleConflict?"ROLE CONFLICT - REPLUG":stages[stage],stage>=LINK_MISMATCH||s.roleConflict?GOLD:ICE);
 label(27,85,s.usb.guest==2?"PLAYER: WAITING FOR USB":(s.usb.guest?"USB GUEST -> ORANGE":"USB HOST -> BLUE"),INK);
 snprintf(line,sizeof(line),"TX %lu  RX %lu  ERR %d/%u",(unsigned long)s.sent,(unsigned long)s.received,s.usb.error,s.usb.step);label(27,103,line,SOFT);
 static const char *steps[]={"INIT","RESET","GAME ID","CONFIG","EVENTS","READ","WRITE"};
 static const char *errors[]={"OK","IGNORE","SYSTEM","PARAM","QUEUE FULL","NO DEVICE","MEMORY","UNSUPPORTED","OVERFLOW","TIMEOUT","FAILED"};
 snprintf(line,sizeof(line),"%s: %s  #%u",steps[s.usb.step<=LINK_WRITE?s.usb.step:0],errors[s.usb.error>=0&&s.usb.error<=10?s.usb.error:10],s.usb.attempts);label(27,119,line,s.usb.error?GOLD:SOFT);
 snprintf(line,sizeof(line),"OUT %lu  IN %lu  BYTES %u",(unsigned long)s.completedSent,(unsigned long)s.rawReceived,s.lastRead);label(27,135,line,SOFT);
 for(unsigned i=0;i<4;i++)rect(259+i*9,140,5,4,i==(frame%4)?ICE:EDGE);
 label(20,156,"1  Open LINK on BOTH calculators.",INK);
 label(20,172,"2  Use a USB calculator link cable.",INK);

 label(20,200,stage==LINK_MISMATCH?"Install v1.0.0 on BOTH calculators.":"No RX? Replug cable, then ENTER retry.",GOLD);
 middle(228,"ENTER RETRY   /   CLEAR MENU",ICE);gfx_SwapDraw();
}
void ui_result(const Game *g,int player,int linked,unsigned selected,unsigned frame){int winner=g->score[0]>g->score[1]?0:1,win=winner==player,accent=win?ICE:GOLD;char s[32];base();
 if(frame<16){for(int i=0;i<16;i++){int x=18+(i*47)%284,y=28+(i*29+(int)frame*5)%157;rect(x,y,3,win?5:2,i%2?accent:EDGE);}}
 badge(145,21,accent);gfx_SetTextScale(2,2);middle(65,win?"VICTORY":"MATCH LOST",accent);gfx_SetTextScale(1,1);middle(89,winner?"ORANGE TAKES THE MATCH":"BLUE TAKES THE MATCH",SOFT);
 rect(58,108,204,36,CARD);snprintf(s,sizeof(s),"BLUE  %u   -   %u  ORANGE",g->score[0],g->score[1]);middle(122,s,INK);
 const char *first=linked&&player?"WAITING FOR BLUE HOST":"PLAY AGAIN";
 for(unsigned i=0;i<2;i++){int y=157+i*28;rect(57,y,206,23,i==selected?accent:CARD);middle(y+8,i?"RETURN TO MENU":first,i==selected?BG:INK);}
 middle(228,linked&&player?"HOST STARTS REMATCH  /  CLEAR: MENU":"UP/DOWN SELECT  ENTER CONFIRM  CLEAR MENU",SOFT);gfx_SwapDraw();
}
