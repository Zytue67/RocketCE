#ifndef UI_H
#define UI_H
#include "game.h"
#include "net.h"
void ui_init(void);
void ui_intro(unsigned frame);
void ui_title(unsigned pulse);
void ui_menu(unsigned selected);
void ui_controls(void);
void ui_link(net_status_t status,unsigned frame);
void ui_menu_tick(uint32_t elapsed);
void ui_result(const Game *g,int player,int linked,unsigned selected,unsigned frame);
#endif
