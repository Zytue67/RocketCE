#ifndef ROCKET_CONTROLS_H
#define ROCKET_CONTROLS_H
#include <stdint.h>
#define CONTROL_SAMPLES 32
typedef struct {uint32_t time;uint8_t keys;} ControlSample;
typedef struct {ControlSample samples[CONTROL_SAMPLES];uint8_t head,count,held,last;} ControlTimeline;
void controls_init(ControlTimeline *t,uint8_t keys);
void controls_sample(ControlTimeline *t,uint32_t time,uint8_t keys);
uint8_t controls_step(ControlTimeline *t,uint32_t until,int *released);
#endif
