#include "render.h"
#include <graphx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int x,y,z;} V;
#define MAX_POLYS 32
#define MAX_VERTS 8
_Static_assert(MAX_POLYS>=29,"Two cars, wheels, flames and ball must fit");
typedef struct {int16_t x[MAX_VERTS],y[MAX_VERTS];int depth;uint8_t n,color,layer,kind;} Poly;
static int viewSin,viewCos,pitchSin=90,pitchCos=240;static Poly *order[MAX_POLYS];
static void (*inputPoll)(void);
void render_set_poll(void (*callback)(void)){inputPoll=callback;}
static unsigned measuredFps,drawMs,simMs;static int rowStep=2;
void render_detail(int detail){rowStep=detail?1:2;}
void render_cost(unsigned draw,unsigned sim){drawMs=draw;simMs=sim;}
void render_fps(unsigned fps){measuredFps=fps;}
static uint8_t layer=2;static Poly polys[MAX_POLYS];static unsigned count;static int camx,camy,camz;static uint8_t yaw;static int initialized;static uint32_t lastCameraTick;
enum { SKY=0,TURF=1,TURF2=2,WALL=3,WHITE=4,BLUE=5,ORANGE=6,DARK=7,GLASS=8,BOOSTC=9,BALL=10,BALLD=11,PANEL=12,MUTED=13,LINE=14,BLUE_SIDE=15,ORANGE_SIDE=16,WALL2=17,WALL3=18 };
static const uint16_t palette[19]={0x0447,0x1169,0x158a,0x0cce,0x7fff,0x229f,0x7de4,0x0422,0x18ef,0x7f60,0x739c,0x4631,0x0865,0x4673,0x36d4,0x1197,0x50c1,0x10ef,0x08ad};
static uint16_t projectionScale[2048];static uint8_t projectionReady;
/* Q12 perspective scale: <=1 pixel error in the bounded arena. Native
 * multiplication handles the normal frustum; wide fallback handles outliers. */
static int perspective(int value,int depth){
 if(depth>=16&&depth<2048){int scale=projectionScale[depth];
  if(abs(value)<=depth*8)return (value*scale+2048)>>12;
  return ((int32_t)value*scale+2048)>>12;
 }
 if(depth>=2048&&depth<4096){int scale=(projectionScale[(depth+1)/2]+1)/2;return ((int32_t)value*scale+2048)>>12;}
 return (int32_t)value*180/depth;
}
#ifdef ROCKET_RENDER_TEST
int render_test_project(int value,int depth){return perspective(value,depth);}
#endif
void render_init(void){if(!projectionReady){for(int z=16;z<2048;z++)projectionScale[z]=(737280+z/2)/z;projectionReady=1;}gfx_SetPalette(palette,sizeof(palette),0);gfx_SetTextFGColor(WHITE);gfx_SetTextBGColor(PANEL);gfx_SetTextTransparentColor(PANEL);}
void render_reset(void){initialized=0;}
#ifdef ROCKET_RENDER_TEST
unsigned render_camera_heading(void){return yaw;}
int render_camera_x(void){return camx;}
int render_camera_z(void){return camz;}
#endif
static V transform(V v){int dx=v.x-camx,dz=v.z-camz,dy=v.y-camy;int depth=(dx*viewSin+dz*viewCos)/Q;V a={(dx*viewCos-dz*viewSin)/Q,(dy*pitchCos+depth*pitchSin)/Q,(depth*pitchCos-dy*pitchSin)/Q};return a;}
static void fill_polygon(const Poly *p);
static __attribute__((noinline)) int native_ratio(int value,int scale,int divisor){return value*scale/divisor;}
static int clip_axis(int a,int b,int t,int d){int delta=b-a;if(abs(delta)<=2047&&abs(t)<=4095)return a+native_ratio(delta,t,d);return a+(int32_t)delta*t/d;}
/* Near clipping is done in camera space; every final span is screen bounded. */
static void camera_polygon(const V *v,int n,uint8_t color){
 if(inputPoll)inputPoll();
 V w[MAX_VERTS];int k=n,dep=0,inside=0;if(count>=MAX_POLYS)return;
 for(int i=0;i<n;i++)inside+=v[i].z>=16;if(!inside)return;
 const V *clipped=v;
 if(inside!=n){k=0;clipped=w;
  for(int i=0;i<n;i++){int next=i+1;if(next==n)next=0;V a=v[i],b=v[next];int ia=a.z>=16,ib=b.z>=16;
   if(ia){if(k>=MAX_VERTS)return;w[k++]=a;}
   if(ia!=ib){if(k>=MAX_VERTS)return;int t=16-a.z,d=b.z-a.z;
    w[k++]=(V){clip_axis(a.x,b.x,t,d),clip_axis(a.y,b.y,t,d),16};}
  }
 }
 if(k<3)return;
 Poly *p=&polys[count];int minx=32767,maxx=-32767,miny=32767,maxy=-32767;
 for(int i=0;i<k;i++){int x=160+perspective(clipped[i].x,clipped[i].z),y=116-perspective(clipped[i].y,clipped[i].z);
  if(x<-30000||x>30000||y<-30000||y>30000)return;
  p->x[i]=x;p->y[i]=y;dep+=clipped[i].z;
  if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;
 }
 if(maxx<0||minx>319||maxy<27||miny>211)return;
 p->n=k;p->depth=dep/k;p->color=color;p->layer=layer;p->kind=0;if(layer<2)fill_polygon(p);else count++;
}
static void polygon(const V *world,int n,uint8_t color){V v[MAX_VERTS];for(int i=0;i<n;i++)v[i]=transform(world[i]);camera_polygon(v,n,color);}
static void span(int y,int left,int right,uint8_t color){
 if(y<27||y>211||right<0||left>319)return;
 if(left<0)left=0;if(right>319)right=319;
 if(left>right)return;gfx_SetColor(color);gfx_HorizLine_NoClip(left,y,right-left+1);
}
static int16_t rowLeft[185],rowRight[185];
/* Wide edge setup; incremental inner loops; bounded horizontal spans only. */
static void fill_polygon(const Poly *p){
 int step=rowStep==2&&p->layer<2?3:rowStep;
 int first=212,last=26;
 for(int i=0;i<p->n;i++){int y=p->y[i];if(y<first)first=y;if(y>last)last=y;}
 if(first<27)first=27;if(last>211)last=211;if(first>last)return;first=27+(first-27)/step*step;
 for(int y=first;y<=last;y+=step){rowLeft[y-27]=32767;rowRight[y-27]=-32767;}
 for(int i=0;i<p->n;i++){
  int j=i+1;if(j==p->n)j=0;int x0=p->x[i],y0=p->y[i],x1=p->x[j],y1=p->y[j];
  if(y0==y1)continue;
  if(y0>y1){int t=x0;x0=x1;x1=t;t=y0;y0=y1;y1=t;}
  int start=y0<first?first:y0,end=y1>last?last:y1;
  int offset=start-first;if(step==2)offset&=1;else if(step==3)offset%=3;else offset=0;
  if(offset)start+=step-offset;if(start>end)continue;
  int edgeX=x1-x0,edgeY=y1-y0;
  /* A bounded native-width division handles normal projected edges. Wide
   * fallback retains safety for extreme near-plane coordinates. */
  int32_t slope=abs(edgeX)<=32767?native_ratio(edgeX,256,edgeY):(int32_t)edgeX*256/edgeY;
  int32_t x=(int32_t)x0*256+slope*(start-y0);
  int32_t advance=slope*step;
  int xi=x>>8,fraction=x&255,whole=advance>>8,fracStep=advance&255;
  for(int y=start;y<=end;y+=step){
   if(xi<rowLeft[y-27])rowLeft[y-27]=xi;
   if(xi>rowRight[y-27])rowRight[y-27]=xi;
   xi+=whole;fraction+=fracStep;if(fraction>=256){xi++;fraction-=256;}
  }
 }
 gfx_SetColor(p->color);
 for(int y=first;y<=last;y+=step){
  if((y&15)==11&&inputPoll)inputPoll();
  int l=rowLeft[y-27],r=rowRight[y-27];if(l<0)l=0;if(r>319)r=319;
  if(l<=r){if(step==1)gfx_HorizLine_NoClip(l,y,r-l+1);else gfx_FillRectangle_NoClip(l,y,r-l+1,y+step>212?212-y:step);}
 }
}
static void fill_ball(const Poly *p){
 int cx=p->x[0],cy=p->y[0],r=p->x[1];int solid=p->kind!=1,color=p->kind==2?DARK:BOOSTC;int x=r,y=0,err=1-r;
 while(x>=y){
  span(cy+y,cx-x,cx+x,solid?color:y>r/3?BALLD:BALL);
  span(cy-y,cx-x,cx+x,solid?color:BALL);
  span(cy+x,cx-y,cx+y,solid?color:BALLD);
  span(cy-x,cx-y,cx+y,solid?color:WHITE);
  y++;if(err<0)err+=2*y+1;else{x--;err+=2*(y-x)+1;}
 }
 if(p->kind==1&&r>=4){int h=r/3;for(int yy=-h;yy<=h;yy++)span(cy+yy,cx-h,cx+h,BALLD);}
}
static void quad(int x0,int z0,int x1,int z1,int height,int color){V v[4]={{x0,height,z0},{x1,height,z0},{x1,height,z1},{x0,height,z1}};uint8_t old=layer;layer=(color==TURF||color==TURF2)?0:1;polygon(v,4,color);layer=old;}
static void wall(int x0,int z0,int x1,int z1,int h0,int h1,int color){V v[4]={{x0,h0,z0},{x1,h0,z1},{x1,h1,z1},{x0,h1,z0}};polygon(v,4,color);}
/* Rotate a basis vector without translating it. This lets tilted cars use
 * one local-to-camera matrix rather than two transforms per mesh vertex. */
static V camera_vector(int x,int y,int z){int d=(x*viewSin+z*viewCos)/Q;return (V){(x*viewCos-z*viewSin)/Q,(y*pitchCos+d*pitchSin)/Q,(d*pitchCos-y*pitchSin)/Q};}
static V mesh_point(V center,V right,V up,V forward,int x,int y,int z){return (V){center.x+(right.x*x+up.x*y+forward.x*z)/Q,center.y+(right.y*x+up.y*y+forward.y*z)/Q,center.z+(right.z*x+up.z*y+forward.z*z)/Q};}
/* One low-poly hatchback: flat hood, upright rear cabin, sloped windshield.
 * Mesh points are transformed once; only camera-facing surfaces are submitted. */
static void car(const Car *c,int team){
 static const int8_t local[14][3]={
  {-16,4,-25},{16,4,-25},{16,4,25},{-16,4,25},
  {-16,14,-25},{16,14,-25},{16,14,25},{-16,14,25},
  {-11,26,-20},{11,26,-20},{11,26,5},{-11,26,5},
  {-16,14,16},{16,14,16}};
 static const uint8_t faces[11][4]={
  {0,1,5,4},{1,2,6,5},{2,3,7,6},{3,0,4,7},
  {12,13,6,7},{4,5,9,8},{5,13,10,9},{12,13,10,11},
  {4,8,11,12},{8,9,10,11},{0,3,2,1}};
 int x=c->b.x/Q,y=c->b.y/Q,z=c->b.z/Q,a=c->angle,co=cs(a),si=sn(a);
 int tilted=c->pitch||c->roll;
 CarBasis basis;V right={0,0,0},up={0,0,0},forward={0,0,0},center={0,0,0};
 int rx,ry,rz;
 if(tilted){
  car_basis(c,&basis);
  right=camera_vector(basis.rx,basis.ry,basis.rz);up=camera_vector(basis.ux,basis.uy,basis.uz);forward=camera_vector(basis.fx,basis.fy,basis.fz);
  center=transform((V){x,y+CAR_HEIGHT/2,z});
  int dx=camx-x,dy=camy-y-CAR_HEIGHT/2,dz=camz-z;
  rx=(dx*basis.rx+dy*basis.ry+dz*basis.rz)/Q;
  ry=(dx*basis.ux+dy*basis.uy+dz*basis.uz)/Q+CAR_HEIGHT/2;
  rz=(dx*basis.fx+dy*basis.fy+dz*basis.fz)/Q;
 }else{rx=((camx-x)*co-(camz-z)*si)/Q;ry=camy-y;rz=((camx-x)*si+(camz-z)*co)/Q;}
 V v[14];for(int i=0;i<14;i++){
  if(tilted)v[i]=mesh_point(center,right,up,forward,local[i][0],local[i][1]-CAR_HEIGHT/2,local[i][2]);
  else v[i]=transform((V){x+(local[i][0]*co+local[i][2]*si)/Q,y+local[i][1],z+(local[i][2]*co-local[i][0]*si)/Q});
 }
 /* Outward face normals include the cabin slopes. Horizontal-only
  * visibility tests left holes whenever the camera looked down on the car. */
 static const int8_t normals[11][3]={{0,0,-1},{1,0,0},{0,0,1},{-1,0,0},
  {0,1,0},{0,5,-12},{12,5,0},{0,11,12},{-12,5,0},{0,1,0},{0,-1,0}};
 for(int i=0;i<11;i++){
  const int8_t *origin=local[faces[i][0]],*normal=normals[i];
  int facing=(rx-origin[0])*normal[0]+(ry-origin[1])*normal[1]+(rz-origin[2])*normal[2];
  if(facing<=0)continue;
  V f[4];for(int j=0;j<4;j++)f[j]=v[faces[i][j]];
  int color=i==10?DARK:(i==5||i==7)?GLASS:(i==4||i==9)?(team?ORANGE:BLUE):(team?ORANGE_SIDE:BLUE_SIDE);
  camera_polygon(f,4,color);
 }
 /* Two visible axle wheels are circular billboards rather than extra boxes. */
 for(int side=-1;side<=1;side+=2){
  int along=rz<0?-19:19;
  V w=tilted?mesh_point(center,right,up,forward,side*15,5-CAR_HEIGHT/2,along):transform((V){x+(side*15*co+along*si)/Q,y+5,z+(along*co-side*15*si)/Q});
  if(w.z<16||count>=MAX_POLYS)continue;
  int sx=160+perspective(w.x,w.z),sy=116-perspective(w.y,w.z),r=perspective(4,w.z);
  if(r<1)r=1;if(r>32)r=32;if(sx+r<0||sx-r>319||sy+r<27||sy-r>211)continue;
  Poly *p=&polys[count++];p->x[0]=sx;p->y[0]=sy;p->x[1]=r;p->depth=w.z;p->layer=4;p->kind=2;p->n=0;
 }
 if((c->previous&BOOST)&&c->boost&&count<MAX_POLYS){
  V w=tilted?mesh_point(center,right,up,forward,0,6-CAR_HEIGHT/2,-33):transform((V){x-33*si/Q,y+6,z-33*co/Q});
  if(w.z>=16){int sx=160+perspective(w.x,w.z),sy=116-perspective(w.y,w.z),r=perspective(6,w.z);if(r<1)r=1;if(r>32)r=32;
   if(sx+r>=0&&sx-r<=319&&sy+r>=27&&sy-r<=211){Poly *p=&polys[count++];p->x[0]=sx;p->y[0]=sy;p->x[1]=r;p->depth=w.z;p->layer=4;p->kind=3;p->n=0;}
  }
 }
}
static void ball(const Body *b){
 V v=transform((V){b->x/Q,b->y/Q,b->z/Q});if(v.z<16||count>=MAX_POLYS)return;
 int x=160+perspective(v.x,v.z),y=116-perspective(v.y,v.z),r=perspective(BALL_RADIUS,v.z);if(r<3)r=3;if(r>96)r=96;
 if(x+r<0||x-r>319||y+r<27||y-r>211)return;
 Poly *p=&polys[count++];p->x[0]=x;p->y[0]=y;p->x[1]=r;p->depth=v.z;p->kind=1;p->layer=4;p->n=0;
}
/* Static enclosure vertices are shared across adjacent strips. Transform each
 * needed vertex once; convex enclosure faces draw directly before objects. */
static void text(int x,int y,const char *s,int color){gfx_SetTextFGColor(color);gfx_PrintStringXY(s,x,y);}
static void center(int y,const char *s,int color){text((320-gfx_GetStringWidth(s))/2,y,s,color);}
void screen_message(const char *title,const char *sub,const char *foot){gfx_FillScreen(SKY);gfx_SetColor(PANEL);gfx_FillRectangle(14,60,292,125);gfx_SetTextScale(2,2);center(78,title,WHITE);gfx_SetTextScale(1,1);center(121,sub,MUTED);center(159,foot,BOOSTC);gfx_SwapDraw();}
/* Fixed-count, deterministic effect: no particle arrays or random state. */
static void goal_explosion(const Game *g){
 unsigned age=GOAL_CELEBRATION-g->phaseTicks;if(age>=BLAST_DURATION)return;
 V v=transform((V){g->ball.x/Q,g->ball.y/Q+18,g->ball.z/Q});if(v.z<16)return;
 int x=160+perspective(v.x,v.z),y=116-perspective(v.y,v.z);
 int radius=perspective(18+(int)age*5,v.z);if(radius<5)radius=5;if(radius>96)radius=96;
 if(x+radius+20<0||x-radius-20>319||y+radius+20<27||y-radius-20>211)return;
 int color=g->lastGoal?ORANGE:BLUE;
 if(age<8){gfx_SetColor(WHITE);gfx_FillCircle(x,y,radius<22?radius:22);}
 for(int ring=0;ring<2;ring++){
  int r=ring?radius*2/3:radius;gfx_SetColor(ring?color:age>30?color:BOOSTC);
  for(int i=0;i<12;i++){int a=i*256/12,b=(i+1)*256/12;gfx_Line(x+r*cs(a)/Q,y+r*sn(a)/Q,x+r*cs(b)/Q,y+r*sn(b)/Q);}
 }
 for(int i=0;i<8;i++){int a=i*32+(int)age,r=radius+8+(i&1)*7,px=x+r*cs(a)/Q,py=y+r*sn(a)/Q;
  if(px>=1&&px<=316&&py>=28&&py<=208){gfx_SetColor(i&1?color:BOOSTC);gfx_FillRectangle_NoClip(px,py,3,3);}
 }
}
void render_game(const Game *g,int player,int ballcam,const char *status){const Car *c=&g->car[player];int target=c->angle;if(ballcam){int dx=(g->ball.x-c->b.x)/Q,dz=(g->ball.z-c->b.z)/Q;target=heading(dx,dz);}if(!initialized){yaw=target;lastCameraTick=g->tick;initialized=1;}
 uint32_t dt=g->tick-lastCameraTick;lastCameraTick=g->tick;
 if(!ballcam)yaw=target;
 else {int delta=(uint8_t)(target-yaw);if(delta>127)delta-=256;int limit=dt>32?128:(int)dt*4;if(limit<1)limit=1;yaw+=delta>limit?limit:delta<-limit?-limit:delta;}
 viewSin=sn(yaw);viewCos=cs(yaw);
 int cx=c->b.x/Q,cz=c->b.z/Q;
 camx=cx-145*viewSin/Q;camz=cz-145*viewCos/Q;
 if(camx<-(FIELD_X-12))camx=-(FIELD_X-12);if(camx>FIELD_X-12)camx=FIELD_X-12;
 if(camz<-(FIELD_Z-12))camz=-(FIELD_Z-12);if(camz>FIELD_Z-12)camz=FIELD_Z-12;
 int dx=cx-camx,dz=cz-camz;
 /* A clamped camera no longer lies on the original chase ray. Aim it back
  * at the car (or ball), preventing sideways jumps and corner cutoffs. */
 if(camx!=cx-145*sn(yaw)/Q||camz!=cz-145*cs(yaw)/Q){
  int actual=heading(ballcam?g->ball.x/Q-camx:dx,ballcam?g->ball.z/Q-camz:dz);
  viewSin=sn(actual);viewCos=cs(actual);
 }
 int distance=root32((unsigned)(dx*dx+dz*dz));
 camy=90+c->b.y/Q+(145-distance)/2;if(camy>FIELD_HEIGHT-12)camy=FIELD_HEIGHT-12;
 int rise=camy-(c->b.y/Q+36);
 int length=root32((unsigned)(distance*distance+rise*rise));if(!length)length=1;
 pitchSin=rise*Q/length;pitchCos=distance*Q/length;
 if(g->phase==PH_GOAL){
  /* A stationary three-quarter view keeps the blast and launched cars in
   * frame instead of carrying the camera upward with the player's car. */
  camx=g->ball.x/Q+220;camz=(g->lastGoal?-1:1)*(FIELD_Z-430);camy=145;
  int gx=g->ball.x/Q-camx,gz=g->ball.z/Q-camz,h=heading(gx,gz);viewSin=sn(h);viewCos=cs(h);
  int d=root32((unsigned)(gx*gx+gz*gz)),r=camy-(g->ball.y/Q+22),l=root32((unsigned)(d*d+r*r));if(!l)l=1;pitchSin=r*Q/l;pitchCos=d*Q/l;
 }

 count=0;layer=0;gfx_SetColor(rowStep==2?WALL:SKY);gfx_FillRectangle(0,27,320,185);
 /* One floor polygon: floor is drawn before field markings and objects. */
 quad(-FIELD_X,-FIELD_Z,FIELD_X,FIELD_Z,0,TURF);
 quad(-(FIELD_X-2),-3,(FIELD_X-2),3,2,LINE);quad(-(FIELD_X-2),-(FIELD_Z-1),(FIELD_X-2),-(FIELD_Z-6),2,WHITE);quad(-(FIELD_X-2),(FIELD_Z-6),(FIELD_X-2),(FIELD_Z-1),2,WHITE);quad(-(FIELD_X-1),-FIELD_Z,-(FIELD_X-6),FIELD_Z,2,LINE);quad((FIELD_X-6),-FIELD_Z,(FIELD_X-1),FIELD_Z,2,LINE);
 /* Centre circle as a ring of short floor strips. */
 layer=1;for(int i=0;i<8;i++){V v[4]={{70*cs(i*32)/Q,2,70*sn(i*32)/Q},{70*cs((i+1)*32)/Q,2,70*sn((i+1)*32)/Q},{73*cs((i+1)*32)/Q,2,73*sn((i+1)*32)/Q},{73*cs(i*32)/Q,2,73*sn(i*32)/Q}};polygon(v,4,LINE);}
 /* FAST uses the enclosing wall color as the backdrop. The rectangular
  * floor already supplies the wall/floor boundary, so no giant wall fills
  * or wall vertex transforms are needed. FINE draws explicit wall faces. */
 layer=1;for(int side=-1;side<=1;side+=2){
  if(rowStep==1){
   wall(side*FIELD_X,-FIELD_Z,side*FIELD_X,FIELD_Z,0,FIELD_HEIGHT,WALL);
   wall(-FIELD_X,side*FIELD_Z,-GOAL_WIDTH,side*FIELD_Z,0,FIELD_HEIGHT,WALL);
   wall(GOAL_WIDTH,side*FIELD_Z,FIELD_X,side*FIELD_Z,0,FIELD_HEIGHT,WALL);
   wall(-GOAL_WIDTH,side*FIELD_Z,GOAL_WIDTH,side*FIELD_Z,GOAL_HEIGHT,FIELD_HEIGHT,WALL);
  }
  int col=side<0?BLUE:ORANGE;
  quad(-GOAL_WIDTH,side*FIELD_Z,GOAL_WIDTH,side*(FIELD_Z+GOAL_DEPTH),0,col);
  wall(-GOAL_WIDTH,side*(FIELD_Z+GOAL_DEPTH),GOAL_WIDTH,side*(FIELD_Z+GOAL_DEPTH),0,GOAL_HEIGHT,DARK);
  wall(-GOAL_WIDTH,side*FIELD_Z,-GOAL_WIDTH,side*(FIELD_Z+GOAL_DEPTH),0,GOAL_HEIGHT,WALL);
  wall(GOAL_WIDTH,side*FIELD_Z,GOAL_WIDTH,side*(FIELD_Z+GOAL_DEPTH),0,GOAL_HEIGHT,WALL);
  wall(-GOAL_WIDTH,side*FIELD_Z,GOAL_WIDTH,side*FIELD_Z,GOAL_HEIGHT,GOAL_HEIGHT+9,col);
  wall(-GOAL_WIDTH-5,side*FIELD_Z,-GOAL_WIDTH,side*FIELD_Z,0,GOAL_HEIGHT,col);
  wall(GOAL_WIDTH,side*FIELD_Z,GOAL_WIDTH+5,side*FIELD_Z,0,GOAL_HEIGHT,col);
 }
 static const int px[6]={-375,375,-375,375,-320,320},pz[6]={-575,-575,575,575,0,0};for(int i=0;i<6;i++)quad(px[i]-13,pz[i]-13,px[i]+13,pz[i]+13,3,g->pads[i]?DARK:BOOSTC);
 /* Objects stay in front of the enclosing arena, not its mean-depth planes. */
 /* Objects stay in front of the enclosing arena, not its mean-depth planes. */
 layer=4;car(&g->car[0],0);if(!g->freeplay)car(&g->car[1],1);if(g->phase!=PH_GOAL)ball(&g->ball);for(unsigned i=0;i<count;i++){Poly *key=&polys[i];unsigned j=i;
 while(j){Poly *prev=order[j-1];if(prev->layer<key->layer||(prev->layer==key->layer&&prev->depth>=key->depth))break;order[j]=prev;j--;}
 order[j]=key;}for(unsigned i=0;i<count;i++){Poly *p=order[i];gfx_SetColor(p->color);if(p->kind)fill_ball(p);else fill_polygon(p);}
 if(g->phase==PH_GOAL)goal_explosion(g);
 /* Fixed-size HUD: same viewport and background fills as the lean build. */
 gfx_SetColor(PANEL);gfx_FillRectangle(0,0,320,27);gfx_FillRectangle(0,212,320,28);
 gfx_SetColor(BLUE);gfx_FillRectangle(0,24,128,3);gfx_SetColor(ORANGE);gfx_FillRectangle(192,24,128,3);
 gfx_SetColor(DARK);gfx_FillRectangle(133,2,54,23);char s[80];
 text(10,9,g->freeplay?"TRAIN":"1v1",MUTED);text(55,9,"BLUE",BLUE);text(235,9,"ORANGE",ORANGE);
 gfx_SetTextScale(2,2);snprintf(s,sizeof(s),"%u",g->score[0]);text(101,5,s,WHITE);snprintf(s,sizeof(s),"%u",g->score[1]);text(194,5,s,WHITE);gfx_SetTextScale(1,1);
 unsigned seconds=(g->remaining+HZ-1)/HZ;snprintf(s,sizeof(s),"%u:%02u",seconds/60,seconds%60);center(9,g->freeplay?"FREE":g->overtime?"OT":s,WHITE);
 snprintf(s,sizeof(s),"BOOST %u",c->boost);text(8,217,s,BOOSTC);gfx_SetColor(DARK);gfx_FillRectangle(82,216,102,10);gfx_SetColor(BOOSTC);gfx_FillRectangle(83,217,c->boost,8);
 text(199,217,g->phase==PH_GOAL?"GOAL CAM":ballcam?"BALL CAM":"CAR CAM",g->phase==PH_GOAL||ballcam?BOOSTC:WHITE);text(270,217,rowStep==2?"FAST":"FINE",MUTED);
 snprintf(s,sizeof(s),"DRAW %ums SIM %ums",drawMs,simMs);text(8,231,s,MUTED);snprintf(s,sizeof(s),"%u.%u FPS",measuredFps/10,measuredFps%10);text(266,231,s,MUTED);
 /* Compact radar, normalized for arena dimensions. */
 gfx_SetColor(PANEL);gfx_FillRectangle(264,142,53,67);gfx_SetColor(MUTED);gfx_Rectangle(265,143,51,65);gfx_HorizLine(265,175,51);
 gfx_SetColor(ORANGE);gfx_HorizLine(281,143,19);gfx_SetColor(BLUE);gfx_HorizLine(281,207,19);
 gfx_SetColor(WHITE);gfx_FillCircle(290+(int32_t)(g->ball.x/Q)*24/FIELD_X,175-(int32_t)(g->ball.z/Q)*30/FIELD_Z,2);for(int i=0;i<(g->freeplay?1:2);i++){gfx_SetColor(i?ORANGE:BLUE);gfx_FillCircle(290+(int32_t)(g->car[i].b.x/Q)*24/FIELD_X,175-(int32_t)(g->car[i].b.z/Q)*30/FIELD_Z,2);}
 if(c->resetLock>8&&g->phase==PH_PLAY)center(64,"FLIP RESET",BOOSTC);
 if(g->phase==PH_KICKOFF){snprintf(s,sizeof(s),"%u",(g->phaseTicks+HZ-1)/HZ);gfx_SetColor(PANEL);gfx_FillRectangle(141,62,38,37);gfx_SetTextScale(3,3);center(70,s,WHITE);gfx_SetTextScale(1,1);}
 if(g->phase==PH_GOAL){gfx_SetColor(PANEL);gfx_FillRectangle(65,56,190,24);center(65,g->lastGoal?"ORANGE SCORES!":"BLUE SCORES!",g->lastGoal?ORANGE:BLUE);}
 if(status)center(40,status,BOOSTC);gfx_SwapDraw();}
