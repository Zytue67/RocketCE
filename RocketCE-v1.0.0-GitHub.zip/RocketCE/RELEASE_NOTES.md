# RocketCE v1.0.0

First public release of RocketCE: 3D car soccer for TI-84 Plus CE and Python Edition.

- Bot matches and unlimited-boost Free Play.
- Local two-player USB multiplayer with automatic player assignments.
- Jumping, double jumps, directional flips, aerial control, boost and powerslide.
- Goal celebrations, scoreboard, menus and a one-page controls guide.

Download **RocketCE-v1.0.0.zip**, extract it, and transfer all four calculator files using TI Connect CE. Launch ROCKETCE from Cesium. Setup links are in the README.

Both linked calculators need this version. Allow a few seconds for the initial connection. Startup and multiplayer gameplay have been tested on two physical calculators; performance varies with scene and detail setting.
